@include('admin.header')
<style>
    html {
        background: url("{{ URL::asset('images/login_bg1.jpg') }}") no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        height:100%;
    }
</style>
<body class="loginPageBg">
    <div class="loginPage">
        <div class="loginOverlay">
            <div class="loginBox">
                <div class="logo">
                    <img src="{{ URL::asset('images/logo.jpg') }}" />
                </div>
                <div class="loginForm">


                    <div class="form">

                        <div class="loginErrorMsgSec" style="height:30px;">
                            <div style="color: red; font-size: 13px; height: 30px;" id="errorMessage">

                                @if (count($errors) > 0)
                                  
                                        @foreach ($errors->all() as $error)
                                        {{ $error }}<br/>
                                        @endforeach
                                   
                                @endif

                            </div>
                        </div>


                        <form id="loginForm" action="{!! url('/password/reset') !!}" method="post" > 
                            <input type="hidden" name="_token" value="{!! csrf_token() !!}">

                            <input type="hidden" name="token" value="{{ $token }}">

                            <div class="formRow">

                                <input type="text" class="textBox" id="email" name="email" placeholder="Email" value="" />
                                 <div id="emailErrorMessage" class="errorMbox"></div>
                            </div>
                            <div class="formRow">

                                <input type="password" class="textBox" id="password"  name="password" value="" placeholder="Password" />
                                <div class="passwordHintText">Password must contain atleast 8 characters including 1 Capital Letter, 1 Small Letter, 1 Number & Special Characters (!@#$&*).</div>
                                 <div id="passwordErrorMessage" class="errorMbox"></div>
                            </div>


                            <div class="formRow">

                                <input type="password" class="textBox" id="password_confirmation"  name="password_confirmation" value="" placeholder="Confirm password" />
                                
                    
                                 <div id="password_confirmationErrorMessage" class="errorMbox"></div>
                            </div>


                            <div class="clear"></div>
                            <div class="formRow">

                                <input type="submit" value="Reset password" id="loginButton" class="btnBlue" />

                                <a  id="loginLoader"  href="{!! url('auth/login') !!}" class="btnBlue" style="display:none;">
                                    <div   align="center">
                                        <img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div></a>



                            </div>



                            <div class="clear">&nbsp;</div>

                        </form>

                    </div>



                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>


    <script>

        $(document).ready(function () {
            
        $('#email').focusout(function(){
            
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var emailaddress = $("#email").val();
                if (emailaddress == '') {
                    $("#emailErrorMessage").text('Please enter your email address.').show();
                    $('#email').addClass('errorTbox');
                    var error = 1;
                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#emailErrorMessage").text('Please enter a valid email address.').show();
                    $('#email').addClass('errorTbox');
                    var error = 1;
                }
                
                
        });
        
        $('#email').keydown(function(){
            $("#emailErrorMessage").hide();
            $('#email').removeClass('errorTbox');
        });
        $('#password').keydown(function(){
            $("#passwordErrorMessage").hide();
            $('#password').removeClass('errorTbox');
        });
        $('#password_confirmation').keydown(function(){
            $("#password_confirmationErrorMessage").hide();
            $('#password_confirmation').removeClass('errorTbox');
        });
            

            $("#loginForm").submit(function () {
                
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var passwordReg = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{8,}$/;
                var emailaddress = $("#email").val();
                var password = $("#password").val();
                var password_confirmation = $("#password_confirmation").val();


                $('#loginButton').hide();
                $('#loginLoader').show();

                if (emailaddress == '') {
                   
                     $("#emailErrorMessage").text('Please enter your email address.').show();
            $('#email').addClass('errorTbox');
            
                      var error = 1;
                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#emailErrorMessage").text('Please enter a valid email address.').show();
                    $('#email').addClass('errorTbox');
                      var error = 1;
                      
                } 
                if (password == '') {
                    $("#passwordErrorMessage").text('Please enter password.').show();
                    $('#password').addClass('errorTbox');
                    var error = 1;
                }
                if (!password.match(passwordReg) && password != '') {
                    $("#passwordErrorMessage").text('Password must contain atleast 8 characters including 1 Capital Letter, 1 Small Letter, 1 Number and Special Characters (!@#$&*).').show();
                    $('#password').addClass('errorTbox');
                    var error = 1;
                }
                if (password_confirmation == '') {
                    $("#password_confirmationErrorMessage").text('Please enter confirm password.').show();
                    $('#password_confirmation').addClass('errorTbox');
                    var error = 1;
                }
                if (password != password_confirmation && password != '' && password_confirmation != '' ) {
                    $("#password_confirmationErrorMessage").text('Password does not match.').show();
                    $('#password_confirmation').addClass('errorTbox');
                    var error = 1;
                }


                if (error == 1) {
                    $('#loginButton').show();
                    $('#loginLoader').hide();
                    return false;
                }else{
                    return true;
                }
                
                
            });
        });


    </script>

</body>
</html>
