<form method="POST" action="{!! url('/password/email') !!}">
    {!! csrf_field() !!}

    <div>
        Email
        <input type="email" name="email" value="">
    </div>

    <div>
        <button type="submit">
            Send Password Reset Link
        </button>
    </div>
</form>