<!-- resources/views/emails/password.blade.php -->


<table width="100%" border="0" align="center" cellpadding="15" cellspacing="0" bgcolor="#F4F4F4">
 <tr>
     <td bgcolor="#80a6b6" align="center"><img src="http://52.27.43.23/tenfive/email/email_logo.png" /></td>
    </tr>
 <tr>
     <td>
         <table width="500" border="0" cellspacing="0" cellpadding="15" align="center" bgcolor="#FFFFFF">
  <tr>
    <td align="left" valign="middle" style="font-size:24px;">Hi, User</td>
  </tr>
  <tr>
    <td align="left" valign="middle">We guess you have forgotten your password. Don't panic, you can reset your password by using the below button.</td>
  </tr>
  <tr>
    <td align="left" valign="middle"><a href="{!! url('password/reset/'.$token) !!}" style="padding:10px 20px; background-color:#335463; border:0px; color:#FFF; font-size:16px; cursor:pointer; text-decoration:none;" target="_blank">Reset Password</a></td>
  </tr>
  <tr>
    <td align="left" valign="middle">Thanks<br />
Support Team</td>
  </tr>
  <tr>
    <td align="center" valign="middle"><a href="#" style="cursor:pointer; color:#000;" target="_blank">Terms</a> | <a href="#" style="cursor:pointer; color:#000;" target="_blank">Privacy</a></td>
  </tr>
          </table>

        </td>
    </tr>
</table>