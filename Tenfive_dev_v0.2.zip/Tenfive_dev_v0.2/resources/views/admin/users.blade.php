@extends('admin.template')

@section('header')
@include('admin.header')

@stop

@section('_header')
@include('admin._header')
@stop


@section('_left-menu')
@include('admin._left-menu-main')
@stop


@section('_content')
<div class="rightSec">
    <div class="rightBoxSec">
        <div class="btnSec">
            <span class="headingMain1">{{trans('global.UserList') }}</span>
            <a onclick="hideAndShow('sampleHideShow');" class="floatRight addBtn">{{trans('global.AddUser') }}</a>
            <div class="clear"></div>
        </div>
        <div id="usersList" class="rowBox">
            
            <div style="display: none;" id="loadmoreUserCount">{{ $user_count }}</div>
            
            @foreach($users as $user) 
            <div class="rowSec" id="userInformation_{{ $user->id }}">
                
                <div class="detailsSec">
                    <div class="name" id="userName_{{ $user->id }}"> {{ $user->full_name }} </div>
                    <!-- if the user is Super Admin -->
                    @if($user->role_type == 1)  
                        <div class="active">SUPER ADMIN</div>
                    @endif
                    <div class="details">
                        <div id="userEmail_{{ $user->id }}">{{ $user->email }}</div>
                    </div>
                </div>
                
                @if($user->role_type >= Auth::user()->role_type)  
                
                  
                <div class="optionSec">
                    <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            <li><a onclick="editUser({{ $user->id }});">Edit user details</a></li>
                            <li><a onclick="changePassword({{ $user->id }});">Change password</a></li>
                            @if($user->role_type != 1) 
                            <li><a onclick="deleteUser({{ $user->id }})">Delete</a></li>
                             @endif
                        </ul>
                    </div>
                </div>
                  
                
                @endif
                
                
                <div class="clear"></div>
            </div>
            @endforeach


            <div class="clear"></div>
        </div>
        <div class="clear">&nbsp;</div>
<!--        <div align="center" id="loadmoreUsersLoader" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->

             <a  id="loadmoreUsersLoader"  class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #f7f7f7">
                            <!-- <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> -->
    <div class="loader1">Loading...</div>
            </a>
        </div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
</div>

<!--Create Account Box Start-->
<div id="sampleHideShow" style="display:none" align="center">
    <div class="popUpSec">
        <div class="popUpBoxSmall">
            <div class=" headingMain popUpHead">{{trans('global.CreateNewUser') }}</div>
            <div class="formSec fontBold600">
                <div style="color: red; font-size: 13px;" id="errorMessage" class="errorMessageDiv"></div>
         <form id="storeUserForm" class="formReset"  />
                   
                <div class="rows ">
                   {{trans('global.FullName') }}
                    <input type="text" id='full_name'  placeholder=" {{trans('global.FullName') }}" class="popupTbox" />
                    <div id="full_nameErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                    
         <div class="rows">
                      {{trans('global.Email') }}
                    <input type="text" id="email" placeholder=" {{trans('global.Email') }}"  class="popupTbox"/>
                    <div id="emailErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
         </div>
                <div class="rows">
                     {{trans('global.Password') }}
                    <input type="password" id="password"  placeholder="{{trans('global.Password') }}" class="inputBox popupTbox" />
                    <div class="passwordHintText fontBoldNormal">{{trans('global.passwprdvalidation') }}</div>
                    <div id="passwordErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                <div class="rows">
                       {{trans('global.ConfirmPassword') }}
                    <input type="password" id="verify_password"  placeholder="{{trans('global.ConfirmPassword') }}" class="inputBox popupTbox" />
                     <div id="verify_passwordErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                <div class="clear"></div>
                <div class="cols2">
                    <a onclick="hideAndShow('sampleHideShow');" class="floatLeft btnLightGray linkBtn">{{trans('global.Cancel') }}</a>
                </div>
                <div class="cols2">

                    <input id="storeUser"  type="submit"  value="{{trans('global.CreateUser') }}" class="floatRight bgBlue linkBtn">
                    <!--<a href="#"  class="floatRight bgBlue linkBtn">{{trans('global.CreateUser') }}</a>-->    

                    <div style="display: none;" id="storeUserLoader" align="center">
                        <div class="loader">Loading...</div>
                    </div>
                </div>
                <div class="clear"></div>

                </form>

            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>
<!--Create Account Box End-->







<!--Edit Account Box Start-->
<div id="editUser" style="display:none" align="center">
    <div class="popUpSec">
        <div class="popUpBoxSmall">
            <div class=" headingMain popUpHead">{{trans('global.EditUser') }}</div>
            <div class="formSec fontBold600">
                
                <div style="color: red; font-size: 13px;" id="errorMessageEditUser" class="errorMessageDiv"></div>
                
                <form id="editUserForm" class="formReset">
                    
                <div id="editUserId" style="display: none;"></div>
                <div class="rows">
                    {{trans('global.FullName') }}
                    <input type="text" id='editUserName' placeholder="{{trans('global.FullName') }}" class="popupTbox" />
                    <div id="editUserNameErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                <div class="rows">
                    {{trans('global.Email') }}
                    <input type="text" id="editUserEmail" placeholder=" {{trans('global.Email') }}" class="popupTbox" />
                     <div id="editUserEmailErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
               
                <div class="clear"></div>
                <div class="cols2">
                    <a onclick="hideAndShow('editUser');" class="floatLeft btnLightGray linkBtn">{{trans('global.Cancel') }}</a>
                </div>
                <div class="cols2">
                    <!--<a href="#" id="updateUserButton" onclick="updateUser();" class="floatRight bgBlue linkBtn">Save</a>-->
                    <input id="updateUserButton"  type="submit"  value="Save" class="floatRight bgBlue linkBtn">
                    
                    <div align="center" id="updateUserLoader" style="display: none;">
                        <!--<img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->
                        <div class="loader">Loading...</div>
                    </div>
                </div>
                <div class="clear"></div>
                
                </form>


            </div>
            
            
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!--Edit Account Box End--> 

<!-- Change Password Box Start  -->
<div id="changePassword" style="display:none" align="center">
    <div class="popUpSec">
        <div class="popUpBoxSmall">
            <div class=" headingMain popUpHead">{{trans('global.Changepassword') }}</div>
            <div class="formSec fontBold600">
                
                <div style="color: red; font-size: 13px;" id="errorMessageChangePassword" class="errorMessageDiv"></div>
                
                <form id="changePasswordForm" class="formReset">
                    
                <div id="changePasswordUserId" style="display: none;"></div>
                <div class="rows">
                    {{trans('global.Newpassword') }}
                 
                    <input type="password" id='newpassword' placeholder=" {{trans('global.Password') }}"  class="popupTbox"/>
                    <div class="passwordHintText fontBoldNormal">{{trans('global.passwprdvalidation') }}</div>
                    <div id="newpasswordErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                
                <div class="rows">
                      {{trans('global.ConfirmPassword') }}
                    <input type="password" id="confirm_new_password" placeholder=" {{trans('global.ConfirmPassword') }}"  class="popupTbox"/>
                    <div id="confirm_new_passwordErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                </div>
                
                <div class="clear"></div>
                
                <div class="cols2">
                    <a  onclick="hideAndShow('changePassword');" class="floatLeft btnLightGray linkBtn">{{trans('global.Cancel') }}</a>
                </div>
                
                <div class="cols2">
                    <!--<a id="changePasswordButton" onclick="updatePassword();" href="#" class="floatRight bgBlue linkBtn">Save</a>-->
                  
                    <input id="changePasswordButton"  type="submit"  value="Save" class="floatRight bgBlue linkBtn">
                    
                    <div align="center" id="changePasswordLoader" style="display: none;">
                       <!--<img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->
                        <div class="loader">Loading...</div>
                    </div>

                </div>
                <div class="clear"></div>
                    
                </form>

            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!-- Change Password Box End --> 


<script type="text/javascript">
    
    
    
    
    
    //Add user functionality
    $(document).ready(function () {
        
        
    $('#full_name').keydown(function(){
        $("#full_nameErrorMessage").hide();
        $('#full_name').removeClass('errorTbox');
    });
    
    $('#email').keydown(function(){
        $("#emailErrorMessage").hide();
        $('#email').removeClass('errorTbox');
    });
    
    $('#email').focusout(function(){
            
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var emailaddress = $("#email").val();
                if (emailaddress == '') {
                    $("#emailErrorMessage").text('{{trans('global.Pleaseenteryouremailaddress') }}').show();
                    $('#email').addClass('errorTbox');
                    var error = 1;
                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#emailErrorMessage").text('{{trans('global.Pleaseentervalidemailaddress') }}').show();
                    $('#email').addClass('errorTbox');
                    var error = 1;
                }
                
                
        });
    
    $('#password').keydown(function(){
        $("#passwordErrorMessage").hide();
        $('#password').removeClass('errorTbox');
    });
    
     $('#verify_password').keydown(function(){
        $("#verify_passwordErrorMessage").hide();
        $('#verify_password').removeClass('errorTbox');
    });
    
    
    
    
    $('#editUserName').keydown(function(){
        $("#editUserNameErrorMessage").hide();
        $('#editUserName').removeClass('errorTbox');
    });
    
    $('#editUserEmail').keydown(function(){
        $("#editUserEmailErrorMessage").hide();
        $('#editUserEmail').removeClass('errorTbox');
    });
    
    $('#editUserEmail').focusout(function(){
            
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var emailaddress = $("#editUserEmail").val();
                if (emailaddress == '') {
                    $("#editUserEmailErrorMessage").text('{{trans('global.Pleaseenteryouremailaddress') }}').show();
                    $('#editUserEmail').addClass('errorTbox');
                    var error = 1;
                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#editUserEmailErrorMessage").text('{{trans('global.Pleaseentervalidemailaddress') }}').show();
                    $('#editUserEmail').addClass('errorTbox');
                    var error = 1;
                }
                
                
        });
    
    
    
    $('#newpassword').keydown(function(){
        $("#newpasswordErrorMessage").hide();
        $('#newpassword').removeClass('errorTbox');
    });
    
     $('#confirm_new_password').keydown(function(){
        $("#confirm_new_passwordErrorMessage").hide();
        $('#confirm_new_password').removeClass('errorTbox');
    });
        
        
        
        
        
        $('#storeUserForm').submit(function (e) {
            
            $('#storeUserLoader').show();
            $('#storeUser').hide();
            
            e.preventDefault();
            var error = 0;
            var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            //var passwordReg = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
            var passwordReg = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{8,}$/; 
            var full_name = $('#full_name').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var verify_password = $('#verify_password').val();
            if(full_name == ''){
                $("#full_nameErrorMessage").text('{{trans('global.Pleaseentername') }}').show();
                $('#full_name').addClass('errorTbox');
                var error = 1;
            }
            if(email == '') {
                $("#emailErrorMessage").text('{{trans('global.Pleaseenteryouremailaddress') }}').show();
                 $('#email').addClass('errorTbox');
                var error = 1;
             }
             if(!emailReg.test(email)) {
                $("#emailErrorMessage").text('{{trans('global.Pleaseentervalidemailaddress') }}').show();
                $('#email').addClass('errorTbox');
                 var error = 1;
             }
             if( password == '') {
                $("#passwordErrorMessage").text('{{trans('global.Pleaseenterpassword') }}').show();
                  $('#password').addClass('errorTbox');
                var error = 1;
            }
            if(!password.match(passwordReg) && password != '') {
           // $("#errorMessage").text('Password should be more than 6 characters').show();
                $("#passwordErrorMessage").text('{{trans('global.passwprdvalidationinusers') }}').show();
                $('#password').addClass('errorTbox');
                var error = 1;
            }
            if(verify_password == '') {
                $("#verify_passwordErrorMessage").text('{{trans('global.Pleaseenterconfirmpassword') }}').show();
                $('#verify_password').addClass('errorTbox');
                var error = 1;
            }
            if(password != verify_password ){
                $("#verify_passwordErrorMessage").text('{{trans('global.Passworddoesnotmatch') }}').show();
                $('#verify_password').addClass('errorTbox');
                var error = 1;
            }
            
            
            if(error == 1){  $('#storeUserLoader').hide();
                                $('#storeUser').show(); return false; }
            
           $("#errorMessage").hide();   
           
            var full_name = $('#full_name').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var verify_password = $('#verify_password').val();
            
            var emailValidationData = "email=" + email + "&user_id=0";
            var userAddingData = "full_name=" + full_name + "&email=" + email + "&password=" + password + "&verify_password=" + verify_password;
            
            $.ajax({
                url: "{!! url('user/emailValidation') !!}",
                type: "post",
                data: emailValidationData
            }).done(function(emailValidationResult){
                var res = $.parseJSON(emailValidationResult);
                
                if(res.status_id == 0){
                        $.ajax({
                        url: "{!! url('user/store') !!}",
                        type: "post",
                        data: userAddingData
                        }).done(function(result){
                          
                        var res = $.parseJSON(result); 
                       
                        if(res.result.length > 0){
                                $('#storeUserLoader').hide();
                                $('#storeUser').show();
                                $('#storeUserForm')['0'].reset();
                                hideAndShow('sampleHideShow');
                                $('#usersList').prepend(res.html);
                        }else{
                                $('#storeUserLoader').hide();
                                $('#storeUser').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : '{{trans('global.Useraddingfailed') }}',
                                  autoclose : 'true',
                                });
                        }
                        
                        
                        })
                        .fail(function() {
                                $('#storeUserLoader').hide();
                                $('#storeUser').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                        });
                }else if(res.status_id == 1){
                      $('#storeUserLoader').hide();
                      $('#storeUser').show();
                      modal({
			type  : 'info',
			title : '{{trans('global.Warning') }}',
			text  : '{{trans('global.Emailalreadyexist') }}',
                        autoclose : 'true',
                      });
                }
            })
            .fail(function(){
                      $('#storeUserLoader').hide();
                      $('#storeUser').show();
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
            
            
        });
    });
    
    //Loadmore users functionality
    
    if($('#loadmoreUserCount').text() == 10){
        var isLoadingData = true;
    }else{
        var isLoadingData = false;
    }
    
    $(window).scroll(function(){
       if( isLoadingData == true){
             if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                    isLoadingData = false;
                    var limit_value = 10;
                    var offset_value = $('#loadmoreUserCount').text();
                    loadMoreUsers(limit_value,offset_value);
             }
       }
    });
    
    function loadMoreUsers(limit_value,offset_value){
        
        $('#loadmoreUsersLoader').show();
        var data = "limit_value=" + limit_value + "&offset_value=" + offset_value;
            $.ajax({
                url: "{!! url('user/loadmore') !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreUsersLoader').hide();
                var res = $.parseJSON(result);
                if(res.user_count > 0){
                    $('#usersList').append(res.html);
                    var availableUserCount = $('#loadmoreUserCount').text();
                    var totalCount = parseInt(availableUserCount) + parseInt(res.user_count);
                    $('#loadmoreUserCount').text(totalCount);
                    isLoadingData = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
        
    }
    
    //display edit user form
    function editUser(userId){
        hideAndShow('editUser');
        var userName = $('#userName_'+userId).text();
        var userEmail = $('#userEmail_'+userId).text();
        $('#editUserName').val(userName);
        $('#editUserEmail').val(userEmail);
        $('#editUserId').text(userId);
    }
    
    //update user calling
    
     $(document).ready(function () {
   // function updateUser(){
        $('#editUserForm').submit(function (e) {
            
        $('#updateUserLoader').show();
        $('#updateUserButton').hide();
        
        e.preventDefault();
        var error = 0;
        var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        var userId = $('#editUserId').text();
        var userName = $('#editUserName').val();
        var userEmail = $('#editUserEmail').val();
        
           
            if(userName == ''){
                $("#editUserNameErrorMessage").text('{{trans('global.Pleaseentername') }}').show();
                $('#editUserName').addClass('errorTbox');
                var error = 1;
            }
            if(userEmail == '') {
                $("#editUserEmailErrorMessage").text('{{trans('global.Pleaseenteryouremailaddress') }}').show();
                $('#editUserEmail').addClass('errorTbox');
                var error = 1;
            }
            if(!emailReg.test(userEmail) && userEmail != '') {
                $("#editUserEmailErrorMessage").text('{{trans('global.Pleaseentervalidemailaddress') }}').show();
                $('#editUserEmail').addClass('errorTbox');
                var error = 1;
            }
        
        
         if(error == 1){    
             $('#updateUserLoader').hide();
             $('#updateUserButton').show(); 
             return false; 
         }
        
            $("#errorMessageEditUser").hide();   
        
        var userUpdatingData = "user_id=" + userId + "&full_name=" + userName + "&email=" + userEmail;
        var emailValidationData = "email=" + userEmail + "&user_id=" + userId;
            $.ajax({
                url: "{!! url('user/emailValidation') !!}",
                type: "post",
                data: emailValidationData
            }).done(function(emailValidationResult){
                    
                    var res = $.parseJSON(emailValidationResult);
                    if(res.status_id == 0){        
                            $.ajax({
                                url: "{!! url('user/update') !!}",
                                type: "post",
                                data: userUpdatingData
                            }).done(function(result){
                                
                                 var res = $.parseJSON(result); 
                                 
                                if(res.result.length > 0){
                                        $('#updateUserLoader').hide();
                                        $('#updateUserButton').show();
                                        hideAndShow('editUser');
                                         $('#editUserForm')['0'].reset();
                                        $('#userInformation_'+userId).html(res.html);
                                }else{
                                        $('#updateUserLoader').hide();
                                        $('#updateUserButton').show();
                                        modal({
                                          type  : 'info',
                                          title : '{{trans('global.Warning') }}',
                                          text  : '{{trans('global.Userupdatefailed') }}',
                                          autoclose : 'true',
                                        });
                                }
                           
                            })
                            .fail(function(){
                                $('#updateUserLoader').hide();
                                $('#updateUserButton').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                            });
                    } else if(res.status_id == 1){
                                $('#updateUserLoader').hide();
                                $('#updateUserButton').show();
                                modal({
                                    type  : 'info',
                                    title : 'Warning',
                                    text  : '{{trans('global.Emailalreadyexist') }}',
                                    autoclose : 'true',
                                });
                    }        
             })
            .fail(function(){
                      $('#updateUserLoader').hide();
                      $('#updateUserButton').show();
                      modal({
			type  : 'error',
			title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
   // }
   
      });
      
    });
    
    
    //server side email validation 
    function validateEmail(email){
        
            var emailValidationData = "email=" + email;
            $.ajax({
                url: "{!! url('user/emailValidation') !!}",
                type: "post",
                data: emailValidationData
            }).done(function(emailValidationResult){
                var res = $.parseJSON(emailValidationResult);
            })
            .fail(function(){
                      $('#storeUserLoader').hide();
                      $('#storeUser').show();
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
           
        
    }
    
    //display edit password form
    function changePassword(userId){
        hideAndShow('changePassword');
        $('#changePasswordUserId').text(userId);
    }

    //update password calling
    $(document).ready(function () {
        $('#changePasswordForm').submit(function (e) {
       // function updatePassword(){
       e.preventDefault();
       $('#changePasswordButton').hide();
       $('#changePasswordLoader').show();
       var error  = 0;
       var passwordReg = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{8,}$/; 
       var userId = $('#changePasswordUserId').text();
       var newpassword = $('#newpassword').val();
       var confirm_new_password = $('#confirm_new_password').val();
       
            if( newpassword == '') {
                $("#newpasswordErrorMessage").text('{{trans('global.Pleaseenterpassword') }}').show();
                $('#newpassword').addClass('errorTbox');
                var error = 1;
            }
            if(!newpassword.match(passwordReg) && newpassword != '' ) {
                $("#newpasswordErrorMessage").text('{{trans('global.passwprdvalidationinusers') }}').show();
                $('#newpassword').addClass('errorTbox');    
                var error = 1;
            }
            if(confirm_new_password == '') {
                $("#confirm_new_passwordErrorMessage").text('{{trans('global.Pleaseenterconfirmpassword') }}').show();
                $('#confirm_new_password').addClass('errorTbox');    
                var error = 1;
            }
            if(newpassword != confirm_new_password && newpassword != '' && confirm_new_password != ''  ){
                $("#confirm_new_passwordErrorMessage").text('{{trans('global.Passworddoesnotmatch') }}').show();
                 $('#confirm_new_password').addClass('errorTbox');  
                var error = 1;
            }
       
       
        if(error == 1){    
             $('#changePasswordLoader').hide();
             $('#changePasswordButton').show(); 
             return false; 
        }
       
       $("#errorMessageChangePassword").hide();
       
       var userUpdatingData = "user_id=" + userId + "&password=" + newpassword;
       
        $.ajax({
            url: "{!! url('user/updatepass') !!}",
            type: "post",
            data: userUpdatingData
        }).done(function(emailValidationResult){
            
            $('#changePasswordButton').show();
            $('#changePasswordLoader').hide();
            hideAndShow('changePassword');
             $('#changePasswordForm')['0'].reset();

        })
        .fail(function(){
            $('#changePasswordButton').show();
            $('#changePasswordLoader').hide();
            modal({
              type  : 'error',
              title : '{{trans('global.Error') }}',
              text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
              autoclose : 'true',
            });
        });
       
        
    //}
    
        });
   });
    
    //delete User
    function deleteUser(userId){
        
           
			modal({
				type  : 'confirm',
				title : '{{trans('global.Confirm') }}',
				text  : '{{trans('global.Areyousureyouwanttodeleteuser') }}',
				callback: function(result){ 
                                    if(result == true){
                                            $('#userInformation_' + userId).slideUp('slow').remove('slow');
                                            var userdeletingData = "user_id=" + userId;
                                            $.ajax({
                                            url: "{!! url('user/destroy') !!}",
                                            type: "post",
                                            data: userdeletingData
                                            }).done(function(emailValidationResult){


                                            })
                                            .fail(function(){
                                            modal({
                                            type  : 'error',
                                            title : 'Error',
                                            text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                            autoclose : 'true',
                                            });
                                            });
                                    }
                                }
			});
		
                    
                    
    }
    
</script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
</script>
@stop




