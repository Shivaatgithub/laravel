@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
     @include('admin._left-menu-event')
@stop


@section('_content')

    
    
    
      
    <div class="rightSec">
        	<div class="rightBoxSec">
                
                
                <div class="boxHeading">
                    <div class="filterSec filterExhibitSec exhibitFilterSelect">                                
<!--                        <select id="dropselection" Name="dropdownexhibit" class="cs-select cs-skin-border" >
                            <option   selected="selected" value="0">{{trans('global.AllExhibits') }}</option>
                            <option   value="1">{{trans('global.SponsoredExhibits') }}</option>
                            <option   value="2">{{trans('global.NonSponsoredExhibits') }}</option>
                           
                        </select>-->
                        <dl class="dropdown">
                            <dt class="textLeft" ><a><span>{{trans('global.AllExhibits') }}</span></a></dt>
                            <dd class="textLeft">
        <ul style="display: none;">
            <li><a onclick="filterExhibit(0)" >{{trans('global.AllExhibits') }}</a></li>
            <li><a onclick="filterExhibit(1)" >{{trans('global.SponsoredExhibits') }}</a></li>
            <li><a onclick="filterExhibit(2)" >{{trans('global.NonSponsoredExhibits') }}</a></li>
        </ul>
    </dd>
</dl>
                    </div>
                    <div class="linkSec marginT10">
                        <a onclick="hideAndShowAddScheduleForm('addExhibitsBtn');" class="bgBlue addExhibitBtn">{{trans('global.AddExhibit') }} </a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                
  
                <div style="display: none;" id="loadmoreexhibitCount">{{ $exhibits_count }}</div>
                <div class="rowBox" id="exhibitsList">
                       
 
                    @if($exhibits_count>0)
                       @foreach($exhibits as $exhibit) 
                       
                <div class="rowSec" id="exhibitInformation_{{ $exhibit->id }}">
                    
                    <div class="exhibitSec" onclick="editExhibit({{ $exhibit->id }},0)">
                        <div class="exhibitImg">
<!--                           <div class="placeholderLoaderBg"> 
                                        <div class="loader">Loading...</div>
                                    </div>-->
                             @if($exhibit->photo_thumb =='') 
                               <img src="{{ URL::asset('images/Placeholder Exhibit.png') }}" />
                                    @endif
                                    
                                        @if($exhibit->photo_thumb !='') 
<!--                                        <div class="croppedImgSec" style="background-image:url({{trans('global.s3filepath').$exhibit->photo_thumb }});">
</div>-->

                    <div class="centerFocuseDiv placeHolderImg80" style="background-image:url('{{ trans('global.s3filepath').$exhibit->photo_thumb }}'); background-size: cover;
    " ></div>         
                                    @endif
                              
                        </div>
                        <div class="details">
                           
                            <div class="name" >{{ $exhibit->name }}</div>
                            
                      @if($exhibit->is_sponsored == 1) 
                     <div class="active">{{trans('global.Sponsored') }}</div>
                      @endif
                          
                        </div>
                    </div>
                   
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            <li><a onclick="editExhibit({{ $exhibit->id }},1)">{{trans('global.Edit') }}</a></li>     
                            <li><a onclick="deleteExhibit({{ $exhibit->id }})">{{trans('global.Delete') }}</a></li>  
            
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                  @endforeach
               @else
                 
                         <div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>
                 
                    @endif
                
               
                 
            </div>
            <div class="clear"></div>
            
            
            
            
            
                <div class="clear">&nbsp;</div>
<!--                <div align="center" id="loadmoreExhibitloader" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div>-->
                
                <a  id="loadmoreExhibitloader"  class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #f7f7f7">
                            <!-- <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> -->
    <div class="loader1">Loading...</div>
            </a>
            </div>
            <div class="clear"></div>
        </div>


<!--Add exhibit Box Start-->
    <div id="addExhibitsBtn" style="display:none" align="center" >
           
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead">{{trans('global.CreateNewExhibit') }}
                  <form id="storeexhibitForm" class="formReset formResetPopup"  />
                
    
                  <div class="popUpBtnSec">
                      <a onclick="hideAndShow('addExhibitsBtn');" class="btnCancel">{{trans('global.Cancel') }}</a>
                     <input id="storeExhibit"  type="submit"  value="{{trans('global.Save') }}" class="btnSave forBtnLink">
               <button class="btnLoading" style="display: none; background-color: #e6e6e6" id="storeExbibitLoader">
<div class="loader">Loading...</div>
</button>
         <div class="clear"></div>
                </div>
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">
 
                    <div class="formBoxSec">
                       
                      <div style="color: red; font-size: 13px;" id="errorMessage" class="errorMessageDiv"></div>
                    	<div class="gridRowsSec fontBold600">
                         <div class="error_msg" id="allfields_error">{{trans('global.Allfieldsrequired') }}</div>
                        	<div class="span10 sl_span10">
                         <div class="placeHolder120">
                                   
                                 <input type="hidden" name="logoThumbnail" id="thumbnail_fileElem" value="" />
                                <input type="hidden" name="logoName" id="file_fileElem" value="" />
                            	{{trans('global.ExhibitsPhoto') }}
                                  <div class="logoBg">
                                    <input class="addExhibitclass" type="file" accept="image/*" name="eventLogo" id="fileElem" multiple onchange="uploadImage(this)">
                                <span id="fileSelect">
                                    
                                    <!--<img id="image_fileElem" class="borderLightGray" src="{{ URL::asset('images/Placeholder Exhibit.png') }}" />-->
            <div id="image_fileElem" class="centerFocuseDiv borderLightGray placeHolderImg120" style="background-image: url('{{ URL::asset('images/Placeholder Exhibit.png') }}'); background-size: cover;
    " ></div> 
                                    
                                    <div class="linkSec">
                                        <div class="imgSec"><img  src="{{ URL::asset('images/camera-icon.png') }}" /></div><div class="containt"> {{trans('global.Upload') }}</div>
                                    </div>
                                </span>
                                     <div  class="error_msg_map" id="fileElem_error" > 	{{trans('global.Pleaseselectlogo') }}</div>
                                    <div  class="progressbar"  id="progressdiv_fileElem" ></div>
                                </div>
                            </div>
                           
                            <div class="widthLes120">
                                
                            	<div class="span10 sl_span10">
                               	{{trans('global.ExhibitName') }}
                                <input class="addExhibitclass" type="text" id="exhibit_name" onkeyup="javascript:capFirst(this);" placeholder="{{trans('global.ExhibitName') }}" />
                                  <div class="error_msg" id="exhibit_name_error" >{{trans('global.Pleaseenterexhibitname') }}</div>
                                </div>
                                
                                <div class="span10 sl_span10">
                                {{trans('global.Description') }}
                                <textarea class="directionBox addExhibitclass" onkeyup="javascript:capFirst(this);" id="description" name="description"  placeholder="{{trans('global.Description') }}"></textarea>
                                 <div class="error_msg" id="description_error" >{{trans('global.Pleaseenterdescrption') }}</div>
                               
                                </div>
                            
                            </div>
                                     <div class="clear"></div>
                                </div>
                            
                           
                            
                            
                            <div class="span4 sl_span10">
                             {{trans('global.iBeaconUUID') }}
                            <input class="addExhibitclass" id="ibeacon_uuid" type="text" placeholder="{{trans('global.iBeaconUUID') }}"  />
                                  <div class="error_msg" id="ibeacon_uuid_error" >{{trans('global.Pleaseenteruuid') }}</div>
                            </div>
                            
                            <div class="span6 sl_span10">
                            	<div class="span5 sl_span10">
                                {{trans('global.iBeaconMajorValue') }}
                                <input class="addExhibitclass" id="ibeacon_major_value" type="text" placeholder="{{trans('global.iBeaconMajorValue') }}"/>
                                         <div class="error_msg" id="ibeacon_major_value_error" >{{trans('global.Pleaseentermajorvalue') }}</div>
                                </div>
                                <div class="span5 sl_span10">
                                     {{trans('global.iBeaconMinorValue') }}
                                     <input class="addExhibitclass" id="ibeacon_minor_value" type="text" placeholder="{{trans('global.iBeaconMinorValue') }}" />
                                     <div class="error_msg" id="ibeacon_minor_value_error" >{{trans('global.PleaseenterMinorvalue') }}</div>
                                </div>
                            </div>
                            
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span10 sl_span10">
                                {{trans('global.iBeaconAlertText') }}
                            <input class="addExhibitclass" id="ibeacon_alert_text" onkeyup="javascript:capFirst(this);" type="text" placeholder="{{trans('global.iBeaconAlertText') }}" />
                             <div class="error_msg" id="ibeacon_alert_text_error" >{{trans('global.Pleaseenteralerttext') }}</div>
                            </div>
                            
                            <div class="span10 sl_span10">
                            <div class="checkBoxLiveStreamSec">
                            <input  id="is_sponsored" type="checkbox" name="checkboxG1"  class="css-checkbox" /><label for="is_sponsored" class="css-label fontBold600">{{trans('global.SponsoredExhibit') }}</label>
                           
                            </div>
                            </div>
                            
                           
                            <div class="clear"></div>
                            
                            
                            
                            
                            
                        </div>
                    
                    <div class="clear"></div>
                    
                        
                    </div>
                </form>
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<!--Add Schedules Box End--> 




 <!--Edit Exhibit Box Start-->
    <div id="editExhibitsBox" style="display:none" align="center" >
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead"> {{trans('global.ExhibitDetails') }}
                   <form id="editExhibitForm" class="formReset formResetPopup"  />
                   <div id="editExhibitId" style="display: none;"></div>
                <div class="popUpBtnSec">
                <a id="updatecandeditbutton" onclick="hideAndShow('editExhibitsBox');" class="btnCancel">{{trans('global.Cancel') }}</a>
                 <input id="updateExhibitbutton"  type="submit"  value="{{trans('global.Save') }}" class="btnSave forBtnLink">
                 <input id='updateExhibitbuttonEdit' type="button" onclick='enableAllEditFields()'  value="{{trans('global.Edit') }}" class="btnSave forBtnLink">
              
                 <button class="btnLoading" style="display: none; background-color: #e6e6e6" id="updatestoreExbibitLoader">
<div class="loader">Loading...</div>
</button>
                  <div class="clear"></div>
                </div>
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">
        <div class="error_msg" id="allfields_error1">{{trans('global.Allfieldsrequired') }}</div>

        <div class="popupLoaderBgSec" style="display: none">

<div class="loaderImgSec"><div class="loader">Loading...</div> </div>
<!--<img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->
</div>
                    <div class="formBoxSec" id="editpopupbox">
                        
                        
                        
                        
                     
                        <div style="color: red; font-size: 13px;" id="editerrorMessage" class="editerrorMessageDiv"></div>
                    
                    	<div class="gridRowsSec fontBold600">
                            	<div class="span10 sl_span10">
                        <div class="placeHolder120">
                            <input type="hidden" name="logoThumbnail" id="thumbnail_fileElem1" value="" />
                            <input type="hidden" name="logoName" id="file_fileElem1" value="" />
                            	{{trans('global.ExhibitsPhoto') }}
                                  <div class="logoBg">
                                    <input class="editExhibitclass" type="file" accept="image/*" name="eventLogo" id="fileElem1" multiple onchange="uploadImage(this)">
                                <span id="fileSelect1">
                                   
                               <!--<img id="image_fileElem1" class="borderLightGray" src="{{ URL::asset('images/Placeholder Exhibit.png') }}" />-->
                                   
                             
                                    <div id="image_fileElem1" class="centerFocuseDiv borderLightGray placeHolderImg120" style="background-image: url('{{ URL::asset('images/Placeholder Exhibit.png') }}');background-size: cover;"></div>
                                    <div class="linkSec Selector">
                                        <div class="imgSec"><img  src="{{ URL::asset('images/camera-icon.png') }}" /></div><div class="containt"> {{trans('global.Upload') }}</div>
                                    </div>
                                </span>
                                    <div  class="error_msg_map" id="fileElem1_error" > 	{{trans('global.Pleaseselectlogo') }}</div>
                                    <div  class="progressbar"  id="progressdiv_fileElem1" ></div>
                                </div>
                                    
                                
                            </div>
                            
                            <div class="widthLes120">
                            
                            	<div class="span10 sl_span10">
                            	{{trans('global.ExhibitName') }}
                                <input class="editExhibitclass" type="text" onkeyup="javascript:capFirst(this);" id="editExhibitname" placeholder="{{trans('global.ExhibitName') }}"  />
                                  <div class="error_msg" id="editExhibitname_error" >{{trans('global.Pleaseenterexhibitname') }}</div>
                                </div>
                                
                                <div class="span10 sl_span10">
                                {{trans('global.Description') }}
                                 
                                <textarea class="directionBox editExhibitclass " id="editDescrption" onkeyup="javascript:capFirst(this);" placeholder="{{trans('global.Description') }}" ></textarea>
                                

                                     <div class="error_msg" id="editDescrption_error" >{{trans('global.Pleaseenterdescrption') }}</div>
                                </div>
                            
                            </div>
                            <div class="clear"></div>
                                </div>
                            
                            
                            
                            <div class="span4 sl_span10">
                             {{trans('global.iBeaconUUID') }}
                            <input class="editExhibitclass" type="text" id="editUUID" placeholder=" {{trans('global.iBeaconUUID') }}"   />
                             <div class="error_msg" id="editUUID_error" >{{trans('global.Pleaseenteruuid') }}</div>
                            </div>
                            
                            <div class="span6 sl_span10">
                            	<div class="span5 sl_span10">
                                       {{trans('global.iBeaconMajorValue') }}
                                <input class="editExhibitclass" type="text" id="ediiMajorval" placeholder="{{trans('global.iBeaconMajorValue') }}" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validateintegers(this);"  />
                                <div class="error_msg" id="ediiMajorval_error" >{{trans('global.Pleaseentermajorvalue') }}</div>
                                </div>
                                <div class="span5 sl_span10">
                                {{trans('global.iBeaconMinorValue') }}
                                <input class="editExhibitclass" type="text" id="editMinorvalue" placeholder="{{trans('global.iBeaconMinorValue') }}" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validateintegers(this);" />
                                 <div class="error_msg" id="editMinorvalue_error" >{{trans('global.PleaseenterMinorvalue') }}</div>
                                </div>
                            </div>
                            
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span10 sl_span10">
                            {{trans('global.iBeaconAlertText') }}
                            <input class="editExhibitclass" type="text" id="ediAlerttext" onkeyup="javascript:capFirst(this);" placeholder="{{trans('global.iBeaconAlertText') }}"  />
                              <div class="error_msg" id="ediAlerttext_error" >{{trans('global.Pleaseenteralerttext') }}</div>
                            </div>
                            
                            <div class="span10 sl_span10">
                            <div class="checkBoxLiveStreamSec">
                                <input id="editIs_sponsored" type="checkbox" name="checkboxG1"  class="css-checkbox editExhibitclass"  /><label for="editIs_sponsored" class="css-label fontBold600">  {{trans('global.SponsoredExhibit') }}</label>
                            </div>
                            </div>
                            
                           
                            <div class="clear"></div>
                            
                            
                            
                            
                            
                        </div>
                        
                    </form>
                    
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<!--Edit Schedules Box End--> 
<!--Loder  Box start--> 
<div id="loaderbox" style="display:none" align="center">
        <div class="eventPopUpSec">
         <div class="eventPopUpBox">
                    <div class="eventPopUpHead"><div id="loaderBoxHeading">  </div>
                
                
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                        
                        
                        
                        <div class="popupLoaderBgSec" style="display: block">

<div class="loaderImgSec"><div class="loader">Loading...</div> </div>
</div>
                            

                        
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                 
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<!--Loder  Box End--> 
 <input type="hidden" name="filterselectedvalue" id="dropdown_selectedvalue" value="0" />
  
@stop

@section('_scripts')



    <script>

        
         function showLoadingBox(heading){
          $('#loaderBoxHeading').text(heading);
           hideAndShow('loaderbox');
      }
 
        
        
function hideAndShowAddScheduleForm(id)
{
 $('#'+id).toggle();
        $('.formReset')['0'].reset();
        $('.errorMessageDiv').hide();
        $('.popupErrorMessageDiv').hide();
        $('.popupTbox').removeClass('errorTbox');
        $('.error_msg').hide();
        $('.error_msg_map').hide();
        $('#error_msg_div').html('');
       var defaultImage = "{{ URL::asset('images/Placeholder%20Exhibit.png')}}";
       $('#image_fileElem').css("background", "url("+ defaultImage +")no-repeat");
       
}
  
        
              $(document).ready(function() {
  $(window).keydown(function(event){
//    if(event.keyCode == 13) {
//      event.preventDefault();
//      return false;
//    }
  });
});
$(document).keypress(function (e) {
  if(e.which == 13 && e.target.nodeName != "TEXTAREA") return false;
});

//for Tab Start
 function uploadImage(input){
              
    var file = input.files;
    var id = input.id;
    
   // alert(id);
    
    console.log(file);
    var formData = new FormData();
    formData.append('image',file[0]);
    $.ajax({
    url: "{!! url('user/s3upload') !!}",
    type: "post",
    data: formData,
    contentType: false,
    cache: false,
    processData:false,
    xhr: function() {
        var xhr = $.ajaxSettings.xhr();
        if (xhr.upload) {
        xhr.upload.addEventListener('progress', function(evt) {
        var percent = (evt.loaded / evt.total) * 100;
        var count = 0;
        var count = percent.toFixed();
       // console.log(count);
        $("#progressdiv_"+id).fadeIn('slow');
		$("#progressdiv_"+id).text(count + '%');
		$("#progressdiv_"+id).width(count + '%');
        }, false);
        }
        return xhr;
    }
    }).done(function(result){
         $("#progressdiv_"+id).fadeOut('slow');
        $("#progressdiv_"+id).text('');
        $("#progressdiv_"+id).width('0%');
       var res = $.parseJSON(result);
       //$('#image_'+id).attr('src',res.ThumbnailPath);
       
       $('#image_'+id).css("background", "url("+ res.ThumbnailPath +") no-repeat");
       $('#thumbnail_'+id).val(res.ThumbnailUrl);
       $('#file_'+id).val(res.FileUrl);
    })
    .fail(function(){
        $("#progressdiv_"+id).fadeOut('slow');
        $("#progressdiv_"+id).text('');
        $("#progressdiv_"+id).width('0%');
        modal({
        type  : 'error',
        title : '{{trans('global.Error') }}',
        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
        autoclose : 'true',
        });
    });
}

   $(document).ready(function () {
        $('#storeexhibitForm').submit(function (e) {
               
            $('#storeExbibitLoader').show();
            $('#storeExhibit').hide();
            e.preventDefault();
            
             $(":text.addExhibitclass,:checkbox.addExhibitclass, select.addExhibitclass, textarea.addExhibitclass").keypress(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error').hide();
              //  }
             });
        
        $(":file ").change(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error').hide();
              //  }
        });     
        var error = 0;
                 var i = 0;
                        $(":text.addExhibitclass, :file.addExhibitclass , :checkbox.addExhibitclass, select.addExhibitclass, textarea.addExhibitclass").each(function() {
                                if($(this).val() === ""){
                                error = 1;
                                i++;
                                var errorid = this.id+'_error';
                                $('#'+errorid).show();

                                }
                        });
                
                        if(i == 7){
                            $('#allfields_error').show();
                            error = 1;
                        }
                        if(error == 1){    
                            // $('#addEventLoader').hide();
                            // $('#addEventButton').show(); 
                            $('#storeExbibitLoader').hide();
                            $('#storeExhibit').show();
                             return false; 
                        }
            //var error = 0;
           
             var event_id='{{$event_id}}';
             
             var exhibit_name = $('#exhibit_name').val();
             var description = $('#description').val();
             var exhibit_photo = $('#file_fileElem').val();
            var exhibit_thumb = $('#thumbnail_fileElem').val();
            var is_sponsored = $('#is_sponsored').is(':checked');
          
           // var is_sponsored = $('#is_sponsored').val();
            var ibeacon_uuid = $('#ibeacon_uuid').val();
            var ibeacon_major_value = $('#ibeacon_major_value').val();
            var ibeacon_minor_value = $('#ibeacon_minor_value').val();
            var ibeacon_alert_text = $('#ibeacon_alert_text').val();
            
          
//           if(error == 1){  $('#storeExbibitLoader').hide();
//           $('#storeExhibit').show(); return false; }
            
           $("#errorMessage").hide();   
           
          
            var exhibitAddingData = "exhibit_name=" + encodeURIComponent(exhibit_name) +
             "&description=" +encodeURIComponent(description) + "&exhibit_photo="+exhibit_photo+"&exhibit_thumb="+exhibit_thumb+
             "&is_sponsored=" +is_sponsored +
             "&ibeacon_uuid=" +encodeURIComponent(ibeacon_uuid)+ "&ibeacon_major_value=" + ibeacon_major_value
             + "&ibeacon_minor_value=" + ibeacon_minor_value
             + "&ibeacon_alert_text=" +encodeURIComponent(ibeacon_alert_text)+ "&event_id=" + event_id;
     
     
     //var exhibitAddingData = $( this ).serializeArray();
            
     
                        $.ajax({
                        url: "{!! url('exhibits/store') !!}",
                        type: "post",
                        data: exhibitAddingData
                        }).done(function(result){
                          
                        var res = $.parseJSON(result); 
                       
                        if(res.result.length > 0){
                                $('#storeExbibitLoader').hide();
                                $('#storeExhibit').show();
                                $('#storeexhibitForm')['0'].reset();
                                hideAndShow('addExhibitsBtn');
                                $('#nodatafound').remove();
                                $('#exhibitsList').prepend(res.html);
                        }else{
                                $('#storeExbibitLoader').hide();
                                $('#storeExhibit').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : 'Exhibit adding faild',
                                  autoclose : 'true',
                                });
                        }
                        
                        
                        })
                        .fail(function() {
                                $('#storeExbibitLoader').hide();
                                $('#storeExhibit').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                        });
                
            })
            
            
            
        });
   


//delete exhibit
   function deleteExhibit(exhibitid){
     
			modal({
				type  : 'confirm',
				title : '{{trans('global.Confirm') }}',
				text  : 'Are you sure want to delete this exhibit?',
				callback: function(result){ 
                                    if(result == true){
                                        $('#exhibitInformation_' + exhibitid).slideUp('slow').remove();
                                            
                                            //$('#scheduleDiv_' + scheduleId).remove();
                                                var exhibitdata = $('#exhibitsList').text().trim().length;
                                                if(exhibitdata == 0){
                                                $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                                                }
                                         
                                            var exhibitdeletingData = "exhibit_id=" + exhibitid;
                                         
                                            $.ajax({
                                            url: "{!! url('exhibits/destroy') !!}",
                                            type: "post",
                                            data: exhibitdeletingData
                                            }).done(function(emailValidationResult){
//                     
 
                                            })
                                            .fail(function(){
                                            modal({
                                            type  : 'error',
                                            title : '{{trans('global.Error') }}',
                                            text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                            autoclose : 'true',
                                            });
                                            });
                                    }
                                }
			});
		
                    
                    
    }

 //Load more functionality
      var isLoadingData = true;
    $(window).scroll(function(){
       if( isLoadingData == true){
             if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                    isLoadingData = false;
                    var limit_value = 10;
                    var offset_value = $('#loadmoreexhibitCount').text();
                   // alert(offset_value);
                    loadMoreUsers(limit_value,offset_value);
             }
       }
    });
    
    //Load more
    function loadMoreUsers(limit_value,offset_value){
        
        //var selected_value= $('#dropselection').val();
  var selected_value = $('#dropdown_selectedvalue').val();
  
        $('#loadmoreExhibitloader').show();
        var data = "limit_value=" + limit_value + "&offset_value=" + offset_value + "&selected_value=" + selected_value;
      
            $.ajax({
                url: "{!! url('exhibits/loadmore/'.$event_id) !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreExhibitloader').hide();
                var res = $.parseJSON(result);
               
                if(res.exhibits_count > 0){
                  
                    $('#exhibitsList').append(res.html);
                    var availableParkingCount = $('#loadmoreexhibitCount').text();
                    var totalCount = parseInt(availableParkingCount) + parseInt(res.exhibits_count);
                    $('#loadmoreexhibitCount').text(totalCount);
                    isLoadingData = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
                        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
        
    }
    
    //Update exhibit
 $(document).ready(function () {
   
        $('#editExhibitForm').submit(function (e) {
            
        $('#updatestoreExbibitLoader').show();
        $('#updateExhibitbutton').hide();
        
        e.preventDefault();
        var exhibit_id = $('#editExhibitId').text();
        var event_id='{{$event_id}}';
        var exhibit_name = $('#editExhibitname').val();
        var description = $('#editDescrption').val();
        var exhibit_photo = $('#file_fileElem1').val();
        var exhibit_thumb = $('#thumbnail_fileElem1').val();
        var is_sponsored = $('#editIs_sponsored').is(':checked');
 
        var ibeacon_uuid = $('#editUUID').val();
        var ibeacon_major_value = $('#ediiMajorval').val();
        var ibeacon_minor_value = $('#editMinorvalue').val();
        var ibeacon_alert_text = $('#ediAlerttext').val();
       
 $(":text.editExhibitclass,:checkbox.editExhibitclass, select.editExhibitclass, textarea.editExhibitclass").keypress(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error1').hide();
              //  }
             });
        
        $(":file").change(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error1').hide();
              //  }
        });     
        var error = 0;
                 var i = 0;
                        $(":text.editExhibitclass,:checkbox.editExhibitclass, select.editExhibitclass, textarea.editExhibitclass").each(function() {
                                if($(this).val() === ""){
                                error = 1;
                                i++;
                                var errorid = this.id+'_error';
                                $('#'+errorid).show();

                                }
                        });
                       
                  if(exhibit_id == 0){ 
                            $(":file.editExhibitclass").each(function() {
                                    if($(this).val() === ""){
                                    error = 1;
                                    i++;
                                    var errorid = this.id+'_error';
                                    $('#'+errorid).show();

                                    }
                            });
                       }
                      
                        if(i == 7){
                            $('#allfields_error1').show();
                            error = 1;
                        }
                        if(error == 1){    
                            // $('#addEventLoader').hide();
                            // $('#addEventButton').show(); 
                            $('#updatestoreExbibitLoader').hide();
                            $('#updateExhibitbutton').show();
                             return false; 
                        }
       // var error = 0;     
      
   
//         if(error == 1){    
//             $('#updatestoreExbibitLoader').hide();
//             $('#updateExhibitbutton').show(); 
//             return false; 
//         }
        
            $("#editerrorMessage").hide();         
             var editExhibitData = "exhibit_name=" + encodeURIComponent(exhibit_name) +
             "&description=" + encodeURIComponent(description) + "&exhibit_photo="+exhibit_photo+"&exhibit_thumb="+exhibit_thumb+
             "&is_sponsored=" +is_sponsored +
             "&ibeacon_uuid=" + encodeURIComponent(ibeacon_uuid) + "&ibeacon_major_value=" + ibeacon_major_value
             + "&ibeacon_minor_value=" + ibeacon_minor_value
             + "&ibeacon_alert_text=" + encodeURIComponent(ibeacon_alert_text)+ "&event_id=" + event_id+"&exhibit_id=" + exhibit_id;
     
    // var editExhibitData = $( this ).serializeArray();
      
                            $.ajax({
                                url: "{!! url('exhibits/update') !!}",
                                type: "post",
                                data: editExhibitData
                            }).done(function(result){
                                
                                 var res = $.parseJSON(result); 
                              
                                if(res.result.length > 0){
                                      
                                        $('#updatestoreExbibitLoader').hide();
                                        $('#updateExhibitbutton').show();
                                        hideAndShow('editExhibitsBox');
                                        $('#editExhibitForm')['0'].reset();
//                                        var url = window.location.href; 
                                           //window.location.href='url';
                                           document.location.reload(true);
                                       // $('#exhibitInformation_'+exhibit_id).html(res.html);
                                }else{
                                        $('#updatestoreExbibitLoader').hide();
                                        $('#updateExhibitbutton').show();
                                        modal({
                                          type  : 'info',
                                          title : '{{trans('global.Warning') }}',
                                          text  : 'exhibits not updated',
                                          autoclose : 'true',
                                        });
                                }
                           
                            })
                            .fail(function(){
                                $('#updatestoreExbibitLoader').hide();
                                $('#updateExhibitbutton').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                            });
    })
      
    });
    
    
    function enableAllEditFields(){
        
        $(":text.editExhibitclass,:checkbox.editExhibitclass,textarea.editExhibitclass").each(function() {
                    $(this).attr("disabled",false);
            });
            $(":file.editExhibitclass").each(function() {
                    $(this).attr("disabled",false);
                    $('.Selector').show();
                    
                    $('#updateExhibitbutton').show();
                    $('#updateExhibitbuttonEdit').hide();
                   // alert($(this).id);
            });
    }
   
//display edit user form
    function editExhibit(exhibitid,edit_flag){
      
        $('#editExhibitForm')['0'].reset(); 
 
       // $('#editpopupbox').css({'display':'none'});
       // $('.popupLoaderBgSec').css({'display':'block'});
       showLoadingBox("Exhibit Details");
        
//       
//            $("#updateExhibitbuttonEdit").css("display", "none");
//                $("#updatecandeditbutton").css("display", "none");
       
        if(edit_flag == 0){
            
            $('#updateExhibitbutton').hide();
            $('#updateExhibitbuttonEdit').show();
             
            $(":text.editExhibitclass,:checkbox.editExhibitclass,textarea.editExhibitclass").each(function() {
                    $(this).attr("disabled",true);
            });
            $(":file.editExhibitclass").each(function() {
                    $(this).attr("disabled",true);
                    $('.Selector').hide();
            });
            
        }else{
             $('#updateExhibitbutton').show();
             $('#updateExhibitbuttonEdit').hide();
             enableAllEditFields();
        }
        //
        
     
         hideAndShow('editExhibitsBox');

      // $(".pageLoaderBgSec").css({ 'display': "block" });
       var data = "exhibit_id=" + exhibitid ;
      
            $.ajax({
                url: "{!! url('exhibits/edit') !!}",
                type: "post",
                data: data
            }).done(function(result){
                            var res = $.parseJSON(result);

                            $('#editExhibitname').val(res.name);
                            $('#editDescrption').val(res.description);

                            if(res.photo_thumb!='')
                            {        
                                
                           // $('#image_fileElem1').attr("src","{{trans('global.s3filepath')}}"+res.photo_thumb); 
                            $('#image_fileElem1').css("background", "url({{trans('global.s3filepath')}}"+ res.photo_thumb +")");
                            }
                            else      
                            {
                             var defaultImage = "{{ URL::asset('images/Placeholder Exhibit.png')}}";
                             $('#image_fileElem1').css("background", "url("+ defaultImage +") no-repeat");
                           // $('#image_fileElem1').attr("src","{{ URL::asset('images/Placeholder Exhibit.png') }}");
                           // $('#image_fileElem1').css("background", "url("+ {{ URL::asset('images/Placeholder Exhibit.png') }} +")");
                             
                            
                            
                            }
                            $('#editExhibitId').text(res.id);
                            if(res.is_sponsored==1)
                            {
                            $('#editIs_sponsored').attr('checked', true); // Checks it
                            }
                            else
                            { 
                            $('#editIs_sponsored').attr('checked', false);
                            }
                            $('#editUUID').val(res.ibeacon_uuid);
                            $('#ediiMajorval').val(res.ibeacon_major_value);
                            $('#editMinorvalue').val(res.ibeacon_minor_value);
                            $('#ediAlerttext').val(res.ibeacon_alert_text);
                            $('#thumbnail_fileElem1').val(res.photo_thumb);
                            $('#file_fileElem1').val(res.photo);
                           
                            //  $(".pageLoaderBgSec").css({ 'display': "none" });
                            showLoadingBox("Exhibit Details");
                              $('#editpopupbox').css({'display':'block'});
//                             $('.popupLoaderBgSec').css({'display':'none'});

            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
                        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });


    }



<!--For Edit and Save End-->

document.querySelector('#fileSelect').addEventListener('click', function(e) {
     
  var fileInput = document.querySelector('#fileElem');
  //click(fileInput); // Simulate the click with a custom event.
  
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

document.querySelector('#fileSelect1').addEventListener('click', function(e) {
 
  var fileInput1 = document.querySelector('#fileElem1');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput1.click(); // Or, use the native click() of the file input.
}, false);

  
                            
                                $(document).ready(function () {
  //called when key is pressed in textbox
  $("#ibeacon_major_value,#ibeacon_minor_value,#ediiMajorval,#editMinorvalue ").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
      
               return false;
    }
   });
});
                               

//     function validateintegers(xxxxx) {
//      
//	 var maintainplus = '';
// 	var numval = xxxxx.value
// 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
// 	//curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
//      curphonevar = numval.replace(/[\\A-Za-z!"£$%^&\-\)\(*+_={};:'@#~,.Š\/<>\" "\?|`¬\]\[]/g,'');
//      
//      
// 	xxxxx.value = maintainplus + curphonevar;
// 	var maintainplus = '';
// 	xxxxx.focus;
//}   

//filter exhibit
//$(document).ready( function ()
//{  
//	 $('#dropselection').change(function()
//	  {  
//        //  $("#filterloader").css({ 'display': "block" });
//          var selected_value= $('#dropselection').val();
//           $('#loadmoreexhibitCount').html(0);
//           
//             var data = "selected_value=" + selected_value +"&limit_value=" + 10 + "&offset_value=" + 0 ;  
//               var imagesoure="{{URL::asset('images/loader_trans1.GIF')}}";
//             
//               $('#exhibitsList').html('<div id="filterloader" class="exhibitSec" style="text-align:center; padding:20px 10px;" ><img src='+imagesoure+'/></div>'); 
//            $.ajax({
//                url: "{!! url('exhibits/filter/'.$event_id) !!}",
//                type: "post",
//                data: data
//            }).done(function(result){
//                $('#loadmoreExhibitloader').hide();
//                var res = $.parseJSON(result);
//           
//                if(res.exhibits_count > 0){
//              
//                $('#exhibitsList').html(res.html);  
//                  
//                    var totalCount =parseInt(res.exhibits_count);
//                   // alert(totalCount);
//                  $('#loadmoreexhibitCount').html(totalCount);
//           
//                    isLoadingData = true;
//                  //  $("#filterloader").css({ 'display': "none" });
//                }
//                else
//                {
//                      $('#filterloader').hide();
//                      $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>'); 
//                }
//                    
//                
//            })
//            .fail(function() {
//               
//                      modal({
//			type  : 'error',
//		        title : '{{trans('global.Error') }}',
//                        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
//                        autoclose : 'true',
//                      });
//               
//            });
//        
//	});
//         
//});
   
   function filterExhibit(selected_value)
   {
      
      $('#dropdown_selectedvalue').val(selected_value);
       //var selected_value= $('#dropselection').val();
           $('#loadmoreexhibitCount').html(0);
           
             var data = "selected_value=" + selected_value +"&limit_value=" + 10 + "&offset_value=" + 0 ;  
             
               //var imagesoure="{{URL::asset('images/loader_trans1.GIF')}}";
             
               $('#exhibitsList').html('<div id="filterloader" class="exhibitSec" style="text-align:center; padding:20px 10px;" >  <div class="loader2">Loading...</div></div>'); 
            $.ajax({
                url: "{!! url('exhibits/filter/'.$event_id) !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreExhibitloader').hide();
                var res = $.parseJSON(result);
           
                if(res.exhibits_count > 0){
              
                $('#exhibitsList').html(res.html);  
                  
                    var totalCount =parseInt(res.exhibits_count);
                   // alert(totalCount);
                  $('#loadmoreexhibitCount').html(totalCount);
           
                    isLoadingData = true;
                  //  $("#filterloader").css({ 'display': "none" });
                }
                else
                {
                      $('#filterloader').hide();
                      $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>'); 
//                     if(selected_value==0) 
//                     {
//                      $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Noexhibitsfound') }}</div>'); 
//                     }
//                     else if(selected_value==1)
//                     {
//                         $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nosponseredexhibitsfound') }}</div>');   
//                     }
//                     else if(selected_value==2)
//                     {
//                           $('#exhibitsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nononsponseredexhibitsfound') }}</div>'); 
//                     }
                }
                    
                
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
                        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
   }
   
</script>
<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
    
 
</script>

<script>

                                            var dropdowns = $(".dropdown");

                                        // Onclick on a dropdown, toggle visibility
                                            dropdowns.find("dt").click(function () {
                                                dropdowns.find("dd ul").hide();
                                                $(this).next().children().toggle();
                                            });

                                        // Clic handler for dropdown
                                            dropdowns.find("dd ul li a").click(function () {
                                                var leSpan = $(this).parents(".dropdown").find("dt a span");

                                                // Remove selected class
                                                $(this).parents(".dropdown").find('dd a').each(function () {
                                                    $(this).removeClass('selected');
                                                });

                                                // Update selected value
                                                leSpan.html($(this).html());

                                                // If back to default, remove selected class else addclass on right element
                                                if ($(this).hasClass('default')) {
                                                    leSpan.removeClass('selected')
                                                }
                                                else {
                                                    leSpan.addClass('selected');
                                                    $(this).addClass('selected');
                                                }

                                                // Close dropdown
                                                $(this).parents("ul").hide();
                                            });

                                        // Close all dropdown onclick on another element
                                            $(document).bind('click', function (e) {
                                                if (!$(e.target).parents().hasClass("dropdown"))
                                                    $(".dropdown dd ul").hide();
                                            });


                                            function showRecoveryPopup() {

                                                $('#recoverydiv').bPopup();

                                            }




                                        </script>

@stop

