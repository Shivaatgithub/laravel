@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
  @include('admin._left-menu-main')
@stop


@section('_content')
  <div class="rightSec">
        	<div class="rightBoxSec">
                
                
                <div class="boxHeading">
                {{trans('global.Advertisements') }}
                    <div class="linkSec">
                        <a onclick="hideAndShow('addAdvertisementsBtn');" class="bgBlue">{{trans('global.AddNewAdvertisement') }} </a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                
                <div class="rowBox">
                <div class="rowSec">
                    <a onclick="hideAndShow('editAdvertisementsBox');">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad</div>
                            <div>http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    </a>
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">{{trans('global.Edit') }}</a></li>
                        <li><a href="#">{{trans('global.Delete') }}</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="rowSec">
                    <div class="exhibitSec">
                        <div class="exhibitImg">
                            <img src="images/Image Placeholder Exhibit List.png" />
                        </div>
                        <div class="details">
                            <div class="name">Sponsor Name</div>
                            <div>Exhibit Ad, http://rowerairshow/sponsorname.html</div>
                        </div>
                    </div>
                    
                    <div class="optionSec">
                    
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a href="#">Edit</a></li>
                        <li><a href="#">Delete</a></li>
                        </ul>
                        </div>

                    
                    </div>
                    <div class="clear"></div>
                    
                </div>
                <div class="clear"></div>
            </div>
            
            
            
            
            
            
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
  <div id="addAdvertisementsBtn" style="display:none" align="center">
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead">{{trans('global.CreateNewAdvertisements') }}
                
                <div class="popUpBtnSec">
                <a onclick="hideAndShow('addAdvertisementsBtn');" class="btnCancel">{{trans('global.Cancel') }}</a>
                <a href="#" class="btnSave">{{trans('global.Save') }}</a>
                </div>
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                    
                    	<div class="gridRowsSec">
                        
                        	<div class="span4 sl_span10">
                            	{{trans('global.AdvPhoto') }}
                                <div class="logoBg">
                                <input type="file" id="fileElem" multiple onchange="handleFiles(this.files)">
                                <button id="fileSelect">
                                <img src="images/Image Placeholder Add.png" />
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="images/camera-icon.png" /></div><div class="containt">{{trans('global.Upload') }}</div>
                                    </div>
                                </button>
                                </div>
                            </div>
                            
                            
                            
                            <div class="spanW-T-6 sl_span10">
                            	<div class="span10 sl_span10">               
                            	{{trans('global.SponsorName') }}
                            <input type="text" placeholder="{{trans('global.SponsorName') }}" />
                            </div>
                            <div class="clear"></div>
                            <div class="span10 sl_span10">
                         	{{trans('global.ADLocation') }}
                            <select class="cs-select cs-skin-border">
                                <option value="" disabled selected>{{trans('global.ExhibitBanner') }}r</option>
                                <option>{{trans('global.EventOpeningAd') }}</option>
                            </select>
                            </div>
                            <div class="span10 sl_span10">
                           {{trans('global.ADFormat') }}
                            <select class="cs-select cs-skin-border">
                                <option> {{trans('global.Image') }}</option>
                                <option> {{trans('global.Video') }}</option>
                            </select>
                            </div>
                            <div class="clear"></div>
                            </div>
                               <div class="clear"></div>
                            
                            
                            
                            
                            <div class="span5 sl_span10">
                               {{trans('global.SelectEvent') }}
                            <select class="cs-select cs-skin-border">
                                <option>{{trans('global.EventName') }}</option>
                            </select>
                            </div>
                            <div class="span5 sl_span10">
                          {{trans('global.SelectExhibit') }}
                            <select class="cs-select cs-skin-border">
                                <option>{{trans('global.ExhibitName') }}</option>
                            </select>
                            </div>
                            <div class="clear"></div>
                                <div class="span10 sl_span10">
                                 {{trans('global.ADURL') }}
                                	<input type="text" placeholder=" {{trans('global.URL') }}" />
                                </div>
                            
                            <div class="clear"></div>
                            
                        </div>
                    
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<!--Add Schedules Box End--> 





 <!--Edit Schedules Box Start-->
    <div id="editAdvertisementsBox" style="display:none" align="center">
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead">Advertisements Details
                
                <div class="popUpBtnSec">
                <a onclick="hideAndShow('editAdvertisementsBox');" class="btnCancel">Cancel</a>
                <a href="javascript:;" id="editSchedulesBtn" class="btnSave">Edit</a>
                </div>
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                    <form id="advertisementsForm">
                    	<div class="gridRowsSec">
                        
                        	<div class="span4 sl_span10">
                            	Exhibits Photo
                                <div class="logoBg">
                                <input type="file" id="fileElem1" multiple onchange="handleFiles(this.files)">
                                <button id="fileSelect1" disabled="disabled">
                                <img src="images/Image Placeholder Exhibit List.png" />
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="images/camera-icon.png" /></div><div class="containt">Upload</div>
                                    </div>
                                </button>
                                </div>
                            </div>
                            
                            <div class="spanW-T-6 sl_span10">
                            
                            	<div class="span10 sl_span10">
                                Sponsor Name
                                <input type="text" placeholder="Sponsor Name" disabled="disabled" />
                                </div>
                                <div class="clear"></div>
                                <div class="span10 sl_span10">
                                AD-Location                                
                                <select class="cs-select cs-skin-border" disabled="disabled">
                                    <option>Exhibit Banner</option>
                                    <option>Event - Opening Ad</option>
                                </select>
                                </div>
                                <div class="span10 sl_span10">
                                AD-Format                                
                                <select class="cs-select cs-skin-border" disabled="disabled">
                                    <option>Image</option>
                                    <option>Video</option>
                                </select>
                                </div>
                                <div class="clear"></div>
                            
                            </div> 
                            <div class="clear"></div>                           
                            <div class="span5 sl_span10">
                            Select Event                                
                            <select class="cs-select cs-skin-border" disabled="disabled">
                                <option>Event Name</option>
                            </select>
                            </div>
                            <div class="span5 sl_span10">
                            Select Exhibit                                
                            <select class="cs-select cs-skin-border" disabled="disabled">
                                <option>Exhibit Name</option>
                            </select>
                            </div>
                            <div class="clear"></div>
                                <div class="span10 sl_span10">
                                AD-URL
                                	<input type="text" placeholder="URL" disabled="disabled" />
                                </div>
                            
                            <div class="clear"></div>
                            
                        </div>
                    </form>
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<!--Edit Schedules Box End--> 
        
            
@stop

@section('_scripts')
  <script type="text/javascript" >
<!--Validations For Phone Text Box Start-->
function contact()
{
	var d=document.cont;
if(d.phone.value=="* Phone Number")
	{
		alert("Enter Your Phone");
		d.phone.focus();
		return false;
	}
	
	if(d.comments.value=="* Comments")
	{
		alert("Enter Your Comments");
		d.comments.focus();
		return false;
	}
	
	return true;
}

function validatephone(xxxxx) {
	 var maintainplus = '';
 	var numval = xxxxx.value
 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
 	curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
 	xxxxx.value = maintainplus + curphonevar;
 	var maintainplus = '';
 	xxxxx.focus;
}
<!--Validations For Phone Text Box End-->



<!--For Edit and Save Start-->
$(document).ready(function() {
	$('a#editSchedulesBtn').click(function() {
		
		var eventStatus = $('#editSchedulesBtn').html();
		 if(eventStatus == 'Edit'){		
		$('#advertisementsForm input[type=text] ').attr("disabled",false);	
		$('#advertisementsForm input[type=checkbox] ').attr("disabled",false);
		$('#advertisementsForm button').attr("disabled",false);
		$('#advertisementsForm .files').attr("disabled",false);
		$('#advertisementsForm textarea ').attr("disabled",false);
		$('#advertisementsForm select ').attr("disabled",false);
		$('#editSchedulesBtn').html("Save");
		}
		else if(eventStatus == 'Save'){		
		$('#advertisementsForm input[type=text] ').attr("disabled",true);
		$('#advertisementsForm input[type=checkbox] ').attr("disabled",true);
		$('#advertisementsForm button').attr("disabled",true);
		$('#advertisementsForm .files').attr("disabled",true);
		$('#advertisementsForm textarea ').attr("disabled",true);
		$('#advertisementsForm select ').attr("disabled",true);
		$('#editSchedulesBtn').html("Edit");
		}
		 
	});
});

<!--For Edit and Save End-->
document.querySelector('#fileSelect').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);


document.querySelector('#fileSelect1').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem1');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);
$(document).ready(function()
{
	$('#date').bootstrapMaterialDatePicker
	({
		time: false
	});
	$('#end-date').bootstrapMaterialDatePicker
	({
		time: false
	});

	$('#time').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});
});
(function() {
		[].slice.call( document.querySelectorAll( 'select.cs-select' ) ).forEach( function(el) {	
			new SelectFx(el);
		} );
	})();
</script>
@stop

