<div id="sampleHideShow1" style="display:none" class="mobAlphaBg">
   <div class="leftBar1">
         <div class="brandName">
                <a href="{!! url('/') !!}"><div class="logo"></div></a>
                Menu
            </div>
        <div class="closeIcon" onclick="hideAndShow('sampleHideShow1');"></div>
            <div class="clear"></div>
        <ul>
            
            <li class="events">
                <a href="{!! url('events') !!}" class="<?php if($active == 1){ echo 'select'; } ?>">
                    <span class="icon"></span>{{trans('global.Events') }}
                </a>
            </li>
             <li class="parking">
                 <a href="{!! url('parking') !!}" class="parking <?php if($active == 2){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Parking') }}
                 </a>
             </li>
             <li class="advertisements">
                 <a href="{!! url('advertisements') !!}" class="advertisements <?php if($active == 3){ echo 'select'; } ?> ">
                     <span class="icon"></span>{{trans('global.Advertisements') }}
                 </a>
             </li>
             <li class="users">
                <a href="{!! url('users') !!}" class="users <?php if($active == 4){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Users') }}
                </a>
             </li>
<!--             <li class="notifications">
                 <a href="{!! url('sendnotification') !!}" class="notifications <?php if($active == 5){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.PushMessage') }}
                 </a>
             </li>-->
        </ul>
    </div>
    <div class="closeDiv" onclick="hideAndShow('sampleHideShow1');"></div>
    <div class="clear"></div>
</div>

<div class="leftBar">
    <ul>
       <li class="events">
           <a href="{!! url('events') !!}" class="<?php if($active == 1){ echo 'select'; } ?>">
               <span class="icon"></span>{{trans('global.Events') }}
           </a>
       </li>
             <li class="parking">
                 <a href="{!! url('parking') !!}" class="<?php if($active == 2){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Parking') }}
                 </a>
             </li>
             <li class="advertisements">
                 <a href="{!! url('advertisements') !!}" class="<?php if($active == 3){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Advertisements') }}
                 </a>
             </li>
             <li class="users">
                 <a href="{!! url('users') !!}" class="<?php if($active == 4){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Users') }}
                 </a>
             </li>
<!--             <li class="notifications">
                 <a href="{!! url('sendnotification') !!}" class="<?php if($active == 5){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.PushMessage') }}
                 </a>
             </li>-->
    </ul>
</div>