
@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
    @include('admin._left-menu-main')
@stop


@section('_content')
<script>
// This example displays an address form, using the autocomplete feature
// of the Google Places API to help users fill in the information.

var placeSearch, autocomplete;
var componentForm = {
  //street_number: 'short_name',
  //route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  //country: 'long_name',
  postal_code: 'short_name'
};

function initialize() {
  // Create the autocomplete object, restricting the search
  // to geographical location types.
  autocomplete = new google.maps.places.Autocomplete(
      /** @type {HTMLInputElement} */(document.getElementById('autocomplete')),
      { types: ['geocode'] });
  // When the user selects an address from the dropdown,
  // populate the address fields in the form.
  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    fillInAddress();
  });
}

// [START region_fillform]
function fillInAddress() {
  // Get the place details from the autocomplete object.
    var place = autocomplete.getPlace();
    var lat = place.geometry.location.lat();
    var lng = place.geometry.location.lng();
    $('#eventLatitude').val(lat);
    $('#eventLongitude').val(lng);
    
    for (var component in componentForm) {
  document.getElementById(component).value = '';
    //document.getElementById(component).disabled = false;
  }
	

  // Get each component of the address from the place details
  // and fill the corresponding field on the form.
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
    }
  }
}
// [END region_fillform]

// [START region_geolocation]
// Bias the autocomplete object to the user's geographical location,
// as supplied by the browser's 'navigator.geolocation' object.
function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = new google.maps.LatLng(
          position.coords.latitude, position.coords.longitude);
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
// [END region_geolocation]



$( document ).ready(function() {
  initialize();
});

    </script>
    <div class="rightSec">
        	<div class="rightBoxSec">
            	<div class="headingMain">{{trans('global.Events') }}</div>
                
                    
                <div class="btnSec">
                	<a href="javascript:;" id="eventActive" class="floatLeft active">{{trans('global.Active') }}</a>
                    <a href="javascript:;" id="eventArchived" class="floatLeft">{{trans('global.Archived') }}</a>
                    <a href="{!! url('create/event') !!}" class="floatRight addBtn" id="addEventBtn">{{trans('global.AddEvent') }}</a>
                    <div class="clear"></div>
                    <div style="display: none;" id="activeSection">1</div>
                </div>
                <div class="rowBox" id="eventActiveSec">
                <!-- curent event-->
               
                    @foreach($currentEvent as $event) 
                        @include('admin.__partial_event')
                     @endforeach
                     
                     
                <!-- active events-->
                <div style="display: none;" id="loadmoreActiveEventsCount">{{ $activeEventsCount or '0' }}</div>
                <div id='activeEventsList'>
                    
                    
                    
                        @foreach($activeEvents as $event) 
                           @include('admin.__partial_event')
                        @endforeach
                        
                    @if($activeEventsCount == 0 && $currentEventCount == 0)
                            @include('admin.__partial_nodatafound')
                    @endif   
                   
                </div>     
                <div class="clear"></div>
            </div>
            
            
            
            <div class="rowBox" id="eventArchivedSec" style="display:none">
                 <!-- archive events--> 
                  <div style="display: none;" id="loadmoreArchiveEventsCount">{{ $archiveEventsCount or '0' }}</div>
                 <div id='archiveEventsList'>
                
                 @if($archiveEventsCount > 0)
                     
                        @foreach($archiveEvents as $event) 
                           @include('admin.__partial_event')
                        @endforeach
                 
                 @else
                 
                            @include('admin.__partial_nodatafound')
                 
                 @endif
                 
                 </div>
                 
                <div class="clear"></div>
            </div>
            
            
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            
            
<!--             <div align="center" id="loadmoreActiveEvents" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->

                  <a  id="loadmoreActiveEvents"  class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #f7f7f7">
                            <!-- <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> -->
    <div class="loader1">Loading...</div>
            </a>
        </div>
            
            
        </div>

       

@stop

@section('_scripts')
    <script>
//for Tab Start

$(document).ready(function() {
    $('a#eventActive').click(function() {
                $('#activeSection').text(1);
		 $("#eventActiveSec").show();
		 	 $("#eventArchivedSec").hide();
			  $("#eventActive").addClass("active")
			  $("#eventArchived").removeClass("active");
		 	 	$("#addEventBtn").show();
    });
	
	$('a#eventArchived').click(function() {
            $('#activeSection').text(2);
		 $("#eventArchivedSec").show();
		 	 $("#eventActiveSec").hide();
			  $("#eventArchived").addClass("active")
			  $("#eventActive").removeClass("active");
		 	 	$("#addEventBtn").hide();
    });
});

//for Tab End

 function changeEventStatus(eventId,status){
     

     $('#event_'+eventId).remove();
     //$('#loadmoreUsersLoader').show();
     
        var data = "event_id=" + eventId + "&is_status=" + status;
            $.ajax({
                url: "{!! url('status/event') !!}",
                type: "post",
                data: data
            }).done(function(result){
                
               var res = $.parseJSON(result);
               if(res.event_count > 0){
                 
                   if(status == 0 ){
                       
                       //add to archive
                       //document.location.reload(true);
                       
                       $('#nodatafound').remove();
                           var activedata = $('#activeEventsList').text().trim().length;
                        if(activedata == 0){
                     ///$('#activeEventsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                      }
                    $('#archiveEventsList').prepend(res.html);
                   }else if(status ==1 ){
                      // document.location.reload(true);
                       //add to active
                      // alert( $("#activeEventsList").is(':empty') );
                      // alert( $("#archiveEventsList").is(':empty') );
                       
                    //   var activedata = $('#activeEventsList').text().trim().length;
                    //   alert(activedata);
                       
                        var archivedata = $('#archiveEventsList').text().trim().length;
                        if(archivedata == 0){
                     $('#archiveEventsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                      }
                        $('#activeEventsList').prepend(res.html);
                       
                   }
                   
               }
                
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
            
            
 
 }
 function deleteEvent(eventId){
     

            
            
            
            modal({
				type  : 'confirm',
				title : 'Confirm',
				text  : 'Are you sure you want to delete event?',
				callback: function(result){ 
                                    if(result == true){
                                            var data = "event_id=" + eventId;
                                           // $('#event_'+eventId).slideUp('slow').remove('slow');
                                            
                                             $('#event_'+eventId).slideUp('slow').remove();
                                                
                                              var activeEventsdata = $('#activeEventsList').text().trim().length;
                                              
                                              var archiveEventsdata = $('#archiveEventsList').text().trim().length;
                                              
                    if(activeEventsdata == 0){
                    $('#activeEventsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                    }
                if(archiveEventsdata == 0){
                    $('#archiveEventsList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                    }
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            $.ajax({
                                            url: "{!! url('delete/event') !!}",
                                            type: "post",
                                            data: data
                                            }).done(function(result){
                                            })
                                            .fail(function() {

                                            modal({
                                            type  : 'error',
                                            title : '{{trans('global.Error') }}',
                                            text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                            autoclose : 'true',
                                            });

                                            });
                                    }
                                }
			});
            
            
            
            
            
            
 
 }
 
 function editEvent(eventId){
     
        
    window.location.href= "{!! url('edit/event/') !!}"+'/'+ eventId +'/1';
 
 }
 
 function makeAsCurrentEvent(eventId){
     
     
     var data = "event_id=" + eventId + "&is_status=1";
            $.ajax({
                url: "{!! url('current/event') !!}",
                type: "post",
                data: data
            }).done(function(result){
                
               if(result == 1){
                   window.location.href="{!! url('events') !!}"
               }
                
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
 
 }
 
    var isLoadingActiveEvents = true;
    var isLoadingArchiveEvents = true;
    
    
    $(document).ready(function () {
                $(window).scroll(function(){
                    
                        var activeSection = $('#activeSection').text();
                       // alert(activeSection);
                      
                      if( isLoadingActiveEvents == true && activeSection == 1){
                            if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                                   isLoadingActiveEvents = false;
                                   var limit_value = 5;
                                   var offset_value = $('#loadmoreActiveEventsCount').text();
                                   loadMoreActiveEvents(limit_value,offset_value);
                            }
                      }
                      
                      if( isLoadingArchiveEvents == true && activeSection == 2){
                            if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                                   isLoadingArchiveEvents = false;
                                   var limit_value = 5;
                                   var offset_value = $('#loadmoreArchiveEventsCount').text();
                                   loadMoreArchiveEvents(limit_value,offset_value);
                            }
                      }
                      
                      
                      
                   });
     });
     
     function loadMoreActiveEvents(limit_value,offset_value){
         
           $('#loadmoreActiveEvents').show();
           
           var data = "limit_value=" + limit_value + "&offset_value=" + offset_value;
            $.ajax({
                url: "{!! url('active_events/loadmore') !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreActiveEvents').hide();
                var res = $.parseJSON(result);
                if(res.events_count > 0){
                    $('#activeEventsList').append(res.html);
                    var availableEventsCount = $('#loadmoreActiveEventsCount').text();
                    var totalCount = parseInt(availableEventsCount) + parseInt(res.events_count);
                    $('#loadmoreActiveEventsCount').text(totalCount);
                    isLoadingActiveEvents = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
         
         
     }
     
     
     function loadMoreArchiveEvents(limit_value,offset_value){
         
           $('#loadmoreActiveEvents').show();
           
           var data = "limit_value=" + limit_value + "&offset_value=" + offset_value;
            $.ajax({
                url: "{!! url('archive_events/loadmore') !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreActiveEvents').hide();
                var res = $.parseJSON(result);
                if(res.events_count > 0){
                    $('#archiveEventsList').append(res.html);
                    var availableEventsCount = $('#loadmoreArchiveEventsCount').text();
                    var totalCount = parseInt(availableEventsCount) + parseInt(res.events_count);
                    $('#loadmoreArchiveEventsCount').text(totalCount);
                    isLoadingArchiveEvents = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
			text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
       
     }
     
     
     
 
</script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
</script>

@stop
