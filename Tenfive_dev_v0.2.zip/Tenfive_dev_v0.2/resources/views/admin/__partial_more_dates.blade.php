<div id="dateSection{{$indexvalue}}" style="float:left;width: 100%;" >
<div class="span3 sl_span6">
                                Start date
                                <input type="text"  name='activityDateTime[{{$indexvalue}}][startDate]' class="eventtimings  dontallowinput dontcheck" id='addStartDate{{$indexvalue}}' placeholder="Start date"  >
                                 <div class="error_msg_map" id="addStartDate{{$indexvalue}}_error" >Date required</div>
                                </div>
                                <div class="span2 sl_span4">
                                Start time
                                <input type="text"  name='activityDateTime[{{$indexvalue}}][startTime]' class="eventtimings  dontallowinput dontcheck" id='addStartTime{{$indexvalue}}' placeholder="Start time" >
                                <div class="error_msg_map" id="addStartTime{{$indexvalue}}_error" >Start time required</div>
                                </div>
                                <div class="span3 sl_span6">
                                End time
                                <input type="text"  name='activityDateTime[{{$indexvalue}}][endTime]' class="eventtimings  dontallowinput dontcheck"  id='addEndTime{{$indexvalue}}' placeholder="End time" >
                                <div class="error_msg_map" id="addEndTime{{$indexvalue}}_error" >End time required</div>
                                </div>
                                <div class="span2 sl_span4">
                                <div class="scheduleDeleteBtnSec">
                                <input type="button"  onclick="removeDate('{{$indexvalue}}')" value="{{trans('global.Delete') }}" class="btnDelete floatRight buttonsPaddingSec" />
                                </div>
                                </div>
<script>
    
    $(document).ready(function()
    {
        $('#addStartDate{{$indexvalue}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
        $('#addStartTime{{$indexvalue}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
        $('#addEndTime{{$indexvalue}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
        
	$('#addStartDate{{$indexvalue}}').bootstrapMaterialDatePicker
	({
		time: false,
                minDate: new Date(),
                format : 'MM-DD-YYYY'
	});
	$('#addStartTime{{$indexvalue}}').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});
        $('#addEndTime{{$indexvalue}}').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});
    });
    </script>
</div>