@foreach($parkings as $parking) 
            <div class="rowSec" id="parkingInformation_{{ $parking->id }}">
                <div class="detailsSec" onclick="editParking({{ $parking->id }},0)">
                    <div class="name" id="parkingText_{{ $parking->id }}">{{ $parking->message }}</div>
                    <div class="details">
                        <div id="parkingdate_{{ $parking->id }}">{{ date("M d Y - h:i:s",($offset)+($parking->last_modifed_on/1000)) }}</div>
                    </div>
                </div>
                <div class="optionSec">
                    <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            <li><a onclick="editParking({{ $parking->id }},1);">Edit</a></li>
                          
                            <li><a onclick="deleteParking({{ $parking->id }})">Delete</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
 @endforeach


