<script>
    $(document).ready(function () {
//    var cacheValue = $.cookie('noTenFiveCache');
//    
//    alert(cacheValue);
//    if(cacheValue == '1'){
//        var location = "{!! url('auth/login') !!}";
//        window.location.href = location;
//    }

        CheckingSeassion();
        function CheckingSeassion() {
           // alert();
            $.ajax({
                type: "POST",
                url: "{!! url('auth/secure') !!}",
                data: {},
                success: function (response) {
                    if (response==0) {
                        
                        modal(
			{
				 type       : 'primary', //Type of Modal Box (alert | confirm | prompt | success | warning | error | info | inverted | primary)
				 title      : 'Warning', //Modal Title
				 text       : 'Your session got expired! Please login again.', //Modal HTML Content
                		 size       : 'normal', //Modal Size (normal | large | small)
				 buttons    : [
					{
		                        	text: 'OK', //Button Text
		                        	val: 'ok', //Button Value
		                		eKey: true, //Enter Keypress
		                        	addClass: 'btn-light-blue btn-square', //Button Classes (btn-large | btn-small | btn-green | btn-light-green | btn-purple | btn-orange | btn-pink | btn-turquoise | btn-blue | btn-light-blue | btn-light-red | btn-red | btn-yellow | btn-white | btn-black | btn-rounded | btn-circle | btn-square)
		                        	onClick: function(dialog){
		                            		console.log(dialog);
		                            		//alert('Look in console!');
                                                        document.location.href="{!! url('auth/login') !!}";
		                            		return true;
		                        	}
                    			},
			         ],
				 center     : true, //Center Modal Box?
				 autoclose  : false, //Auto Close Modal Box?
				 callback   : null, //Callback Function after close Modal (ex: function(result){alert(result);})
				 onShow     : function(e){console.log(e);}, //After show Modal function
				 closeClick : false, //Close Modal on click near the box
                 		 closable   : false, //If Modal is closable
				 theme      : 'modal-theme-xenon', //Modal Custom Theme
				 background : 'rgba(0,0,0,0.99)', //Background Color, it can be null
				 zIndex     : 1050, //z-index
				 buttonText : {ok:'OK',yes:'Yes',cancel:'Cancel'},
				 template   : '<div class="modal-box"><div class="modal-title"></div><div class="modal-text"></div><div class="modal-buttons"></div></div>',
				 _classes   : {box:'.modal-box', title:'.modal-title', content:'.modal-text', buttons:'.modal-buttons', closebtn:'.modal-close-btn'}
			}
			);
		
                        //document.location.href="{!! url('auth/login') !!}";
                    }
                    else
                    {
                    $("body").removeClass("hide");
                    }
                },
                failure: function (msg) {
                    alert(msg);
                }
            });
        }
    
});




</script>
<div class="headerSec">
        <div class="innBodySec">
        <div class="mobMenuIcon" onclick="hideAndShow('sampleHideShow1');" style="z-index:999;"></div>
        
            <div class="brandName">
                <a href="{!! url('/') !!}"><div class="logo"></div>
                 {{trans('global.LOGO') }}</a>
                <div class="clear"></div>
            </div>
            
            <div class="topUserNameSec">
                {{ Auth::user()->full_name }} <br />
                <a href="{!! url('auth/logout') !!}" class="logout">{{trans('global.Signout') }}</a>
            </div>
            
            <div class="clear"></div>
        </div>
        
      <div class="clear"></div>
    </div>