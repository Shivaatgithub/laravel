@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
    @include('admin._left-menu-event')
@stop


@section('_content')
   <div class="rightSec">
        	
            <div class="addEventMainPage">
                <div class="boxHeading">
                    {{trans('global.AddEvents') }}
                    <div class="linkSec">
                        <a href="#" class="floatLeft bgWhite"> {{trans('global.Cancel') }}</a>
                        <a href="#" class="floatRight bgBlue"> {{trans('global.Save') }}</a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                    
                    
                <div class="addEventPage">
                    <div class="gridRowsSec">
                            <div class="span2  md_span5 sl_span4">
                                {{trans('global.EventLogo') }}
                                <div class="logoBg">
                                <input type="file" id="fileElem" multiple onchange="handleFiles(this.files)">
                                <button id="fileSelect">
                               <img src="images/Logo Placeholder.png" />
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="images/camera-icon.png" /></div><div class="containt"> {{trans('global.Upload') }}</div>
                                    </div>
                                </button>
                                </div>
                            </div>
                            <div class="span8 md_span5 sl_span6">
                            <div class="eventNameField">
                                {{trans('global.EventName') }}
                            <input type="text" placeholder="   {{trans('global.FullName') }}" />
                            </div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span4 sl_span6">
                               {{trans('global.StartDate') }}
                            <input type="text" id="date" placeholder=" {{trans('global.Date') }}">
                            </div>
                            <div class="span2 sl_span4">
                             {{trans('global.StartTime') }}
                            <input type="text" id="time" placeholder="  {{trans('global.Time') }}">
                            </div>
                            <div class="span4 sl_span6">
                             {{trans('global.EndDate') }}
                            <input type="text" id="end-date" placeholder=" {{trans('global.EndDate') }}">
                            </div>
                            
                            
                            <div class="clear"></div>
                            <div class="span10">{{trans('global.Location') }}</div>
                            <div class="span2half sl_span5">
                            <input type="text" placeholder="{{trans('global.StreetAddress') }}" />
                            </div>
                            <div class="span2half sl_span5">
                            <input type="text" placeholder="{{trans('global.City') }}" />
                            </div>
                            <div class="span2half sl_span5">
                            <input type="text" placeholder="{{trans('global.State') }}" />
                            </div>
                            <div class="span2half sl_span5">
                            <input placeholder="{{trans('global.Zip') }}" type="text" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validatephone(this);" value="" />
                            </div>
                            <div class="clear"></div>
                            
                            
                            <div class="span10">
                            {{trans('global.WebsiteURL') }}
                            <input type="text" placeholder="   {{trans('global.WebsiteURL') }}" />
                            </div>
                            <div class="span10">
                               {{trans('global.FacebookURL') }}
                            <input type="text" placeholder=" {{trans('global.FacebookURL') }}" />
                            </div>
                            <div class="span10">
                             {{trans('global.TwitterURL') }}
                            <input type="text" placeholder=" {{trans('global.TwitterURL') }}" />
                            </div>
                            
                           <div class="clear"></div>
                           
                            <div class="span6 md_span10 sl_span10">
                             {{trans('global.Directions') }}
                            <textarea placeholder="{{trans('global.TextDirections')}}" class="directionBox"></textarea>
                            </div>
                            <div class="span2 md_span5 sl_span5">
                            {{trans('global.ExhibitMap') }}
                                <div class="logoBg">
                                <input type="file" id="fileElem1" multiple onchange="handleFiles(this.files)">
                                <button id="fileSelect1">
                                <img src="images/Map Placeholder.png" />
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="images/camera-icon.png" /></div><div class="containt">  {{trans('global.Upload') }}</div>
                                    </div>
                                </button>
                                </div>
                            </div>
                            
                            <div class="span2 md_span5 sl_span5">
                               {{trans('global.ParkingMap') }}
                                <div class="logoBg">
                                <input type="file" id="fileElem2" multiple onchange="handleFiles(this.files)">
                                <button id="fileSelect2">
                                     <img src="images/Map Placeholder.png" />
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="images/camera-icon.png" /></div><div class="containt">{{trans('global.Upload') }}</div>
                                    </div>
                                </button>
                                </div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            <div class="span5 sl_span5">
                            {{trans('global.LostChildSupport') }}
                            <input placeholder="{{trans('global.PhoneNumber') }}" type="text" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validatephone(this);" value="" />
                            </div>
                            <div class="span5 sl_span5">
                            {{trans('global.EmergencyNumber') }}
                            <input placeholder="{{trans('global.PhoneNumber') }}" type="text" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validatephone(this);" value="" />
                            </div>
                            <div class="span10">
                            {{trans('global.GuestServicestextinfo') }}
                            <textarea placeholder="{{trans('global.GuestServicestextinfo') }}"></textarea>
                            </div>
                            
                            <div class="clear"></div>
                            
                            
                            
                            
                            
                        </div>
                        <div class="clear"></div>
                </div>
                    
                <div class="clear"></div>
            	</div>
              
            	<div class="clear"></div>
            
            </div>
 
        
            
@stop

@section('_scripts')
  <script type="text/javascript" >
function contact()
{
	var d=document.cont;
if(d.phone.value=="* Phone Number")
	{
		alert("{{trans('global.EnterYourPhone')}}");
		d.phone.focus();
		return false;
	}
	
	if(d.comments.value=="* Comments")
	{
		alert("Enter Your Comments");
		d.comments.focus();
		return false;
	}
	
	return true;
}

function validatephone(xxxxx) {
	 var maintainplus = '';
 	var numval = xxxxx.value
 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
 	curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
 	xxxxx.value = maintainplus + curphonevar;
 	var maintainplus = '';
 	xxxxx.focus;
}

document.querySelector('#fileSelect').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

document.querySelector('#fileSelect1').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem1');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

document.querySelector('#fileSelect2').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem2');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

$(document).ready(function()
{
	$('#date').bootstrapMaterialDatePicker
	({
		time: false
	});
	$('#end-date').bootstrapMaterialDatePicker
	({
		time: false
	});

	$('#time').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});
});
</script>
@stop

