 @foreach($users as $user) 
            <div class="rowSec" id="userInformation_{{ $user->id }}">
                <div class="detailsSec">
                    <div class="name" id="userName_{{ $user->id }}">{{ $user->full_name }}</div>
                    
                     <!-- if the user is Super Admin -->
                    @if($user->role_type == 1)  
                        <div class="active">SUPER ADMIN</div>
                    @endif
                    
                    <div class="details">
                        <div id="userEmail_{{ $user->id }}">{{ $user->email }}</div>
                    </div>
                </div>
                
                  @if($user->role_type >= Auth::user()->role_type) 
                  
                <div class="optionSec">
                    <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            <li><a onclick="editUser({{ $user->id }});">Edit user details</a></li>
                            <li><a onclick="changePassword({{ $user->id }});">Change password</a></li>
                            @if($user->role_type != 1) 
                            <li><a onclick="deleteUser({{ $user->id }})">Delete</a></li>
                            @endif
                        </ul>
                    </div>
                </div>
                  
                   @endif
                  
                <div class="clear"></div>
            </div>
 @endforeach

