@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
    @include('admin._left-menu-event')
@stop


@section('_content')
<script>
var placeSearch, autocomplete;
function initialize() {
    autocomplete = new google.maps.places.Autocomplete(
      (document.getElementById('addActivityAddress')),
        { types: ['geocode'] });
    google.maps.event.addListener(autocomplete, 'place_changed', function() {
      fillInAddress();
    });
}
function fillInAddress() {
    var place = autocomplete.getPlace();
    var lat = place.geometry.location.lat();
    var lng = place.geometry.location.lng();
    $('#addActivityLatitude').val(lat);
    $('#addActivityLongitude').val(lng);
}

function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = new google.maps.LatLng(
          position.coords.latitude, position.coords.longitude);
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
$( document ).ready(function() {
  initialize();
});

    </script>
    <style>
        .error_msg_map{
        color:red;
        display: none;
        margin-bottom: 10px;
        font-size:12px;
        margin-top: -13px;
    }
    
    
    
    .pageLoaderBgSec {
 position:fixed;
 z-index:999;
 width:100%;
 height:100%;
 top:0px;
 left:0px;
 background-color: rgba(0,0,0,0.5);
 }
 
 
.pageLoaderBgSec .loaderImgSec {
 width:60px;
 height:60px;
 text-align:center;
 margin:24% auto 0 auto;
 }
        </style>
        
        <div class="pageLoaderBgSec" style="display: none">

<div class="loaderImgSec"> <img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div>

</div>
    
   <div class="rightSec">
        	<div class="rightBoxSec">
                
                    <script>
                    //var addArray = [];
                    var addArray = [1];
                    function hideAndShowAddScheduleForm(id)
{
    addArray = [1];
    console.log(addArray);
	$('#'+id).toggle();
        $('.formReset')['0'].reset();
        $('.errorMessageDiv').hide();
        $('.popupErrorMessageDiv').hide();
        $('.popupTbox').removeClass('errorTbox');
        $('.error_msg').hide();
        $('.error_msg_map').hide();
        $('#moreDates').html('');
        var defaultImage = "{{ URL::asset('images/Performer_Placeholder.png')}}";
        $('#error_msg_div').html('');
       // $('#image_fileElem').src()
       // $('#image_fileElem').attr('src',defaultImage);
        $('#image_fileElem').css("background", "url("+ defaultImage +") no-repeat");
        
        $('#moreDatesButton_add').hide();
        //var addArray = null;
         //alert(addArray.length);
}
                    
                    </script>
                
                <div class="boxHeading">
                   {{trans('global.EventSchedulesList') }}
                    <div class="linkSec">
                        
                        <a  onclick="hideAndShowAddScheduleForm('addSchedulesBtn');" class="bgBlue">{{trans('global.AddEventSchedules') }} </a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                
                 <div style="display: none;" id="loadmoreScheduleCount">{{ $schdulesCount }}</div>
                <div class="rowBox" id="schedulesList">
                    @if($schdulesCount > 0) 
                                @foreach($schedules as $schedule) 
                                @include('admin.__partial_schedule')
                                 @endforeach
                    @else
                            @include('admin.__partial_nodatafound')
                    @endif
            </div>
                 <div class="clear"></div>
            
            <div class="clear">&nbsp;</div>
<!--        <div align="center" id="loadmoreSchedulesLoader" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />
        </div>-->
<!--<a  id="loadmoreSchedulesLoader"  href="{!! url('auth/login') !!}" class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #F7F7F7">
                             <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> 
    <div class="loader" style="background-color: #F7F7F7">Loading...</div>
            </a>-->
            
            <a  id="loadmoreSchedulesLoader"  class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #f7f7f7">
    <div class="loader1">Loading...</div>
            </a>
            
            
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
 
        <!--Add Schedules Box Start-->
        <form class="formReset" method="post" id="addScheduleForm">
    <div id="addSchedulesBtn" style="display:none" align="center">
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead">{{$event->name }} - New Schedule 
                <div  class="formReset formResetPopup">
                <div class="popUpBtnSec">
                <a onclick="hideAndShow('addSchedulesBtn');" class="btnCancel">{{trans('global.Cancel') }}</a>
                
                
                <!--<a href="#"  class="btnSave">{{trans('global.Save') }}</a>-->
                <input type="submit" class="forBtnLink" value="{{trans('global.Save') }}" id="addScheduleButton" />
<!--                <div align="center" id="addScheduleLoader" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />
            <div class="loader">Loading...</div>
        </div>-->
                
<!--                <a  id="addScheduleLoader"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor btnLoaderAdjust" style="display:none; background-color: #e6e6e6">
                <div class="loader">Loading...</div>
            </a>-->

<!--<a  id="addScheduleLoader"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor updateScheduleLoader" style="display:none; background-color: #e6e6e6;float:right;">
                <div class="loader">Loading...</div>
            </a>-->
             <a id="addScheduleLoader"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor floatRight" style="display:none; background-color: #e6e6e6; margin: -2px 0px 0px 10px;
    padding: 4px 21px 4px 21px;">
                <div class="loader">Loading...</div>
            </a>   
                
                </div>
                <div class="clear"></div>
                    
                </div>
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                        
                            
                            
                    	<div class="gridRowsSec fontBold600">
                            <input type="hidden" name="event_id" value="{{ $event_id }}" />
                        	<div class="span5 sl_span10">
                            	{{trans('global.ActivityName') }}
                                
                                <input type="text" id="addActivityName" class="adding" onkeyup="javascript:capFirst(this);" name="activityName" placeholder="{{trans('global.ActivityName') }}" />
                                <div class="error_msg_map" id="addActivityName_error" >Name required</div>
                                
                            </div>
                            <div class="span5 sl_span10">
                            <div class="checkBoxLiveStreamSec">
                                <input type="checkbox" value="0" name="isAvailableForLiveStream" id="checkboxG1" class="css-checkbox" />
                            <label for="checkboxG1" class="css-label"> {{trans('global.AvailableforLiveStream') }}</label>
                            </div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            <div id="dateSection1" >
                           <div class="span3 sl_span6">
                          Start date
                          
                          <input type="text" class="adding eventtimings dontallowinput" name="activityDateTime[1][startDate]" id="addStartDate1" placeholder="Start date">
                          <div class="error_msg_map" id="addStartDate1_error" >Date required</div>
                          
                          <div></div>
                            </div>
                            <div class="span2 sl_span4">
                            Start time
                              <input type="text" class="adding eventtimings dontallowinput" name="activityDateTime[1][startTime]" id="addStartTime1" placeholder="Start time">
                              <div class="error_msg_map" id="addStartTime1_error" >Start time required</div>
                            </div>
                            <div class="span3 sl_span6">
                            End time
                            <input type="text" class="adding eventtimings dontallowinput" name="activityDateTime[1][endTime]" id="addEndTime1" placeholder="End time">
                             <div class="error_msg_map" id="addEndTime1_error" >End time required</div>
                            </div>
                                
                            <!--                            
                                <div class="span2 sl_span4">
                                <div class="scheduleDeleteBtnSec">
                                <input type="button"  onclick="removeDate(1)" value="{{trans('global.Delete') }}" class="btnDelete floatRight" />
                                </div>
                                <div class="clear"></div>
                                </div>
                            -->
                            <div class="clear"></div>
                            </div>
                            
                            <div id="moreDates" style="width:100%;">
                             
                                
                               
                            </div>
                            
                            <div class="clear"></div>
                            <div class="span5 sl_span10">
                            <div class="checkBoxSec">
                                <input type="checkbox" value="0" name="isMultiDayActive" id="checkboxG2" class="css-checkbox" />
                            <label for="checkboxG2" class="css-label"> {{trans('global.MultiDayActivity') }}</label>
                            <div class='error_msg_map' id='isMultiDayActive_error'>Please un check for single day activity. </div>
                            </div>
                            </div>
                            <div class="span5 sl_span10">
                            <div class="scheduleAddMoreBtnSec">
                               
                                <input type="button" style="display: none" id="moreDatesButton_add" onclick="addMoreDates()" value="{{trans('global.Addmoredatetime') }}" class="btnAddMore floatRight buttonsPaddingSec" />
<!--                                <a  id="moreDatesButtonLoader_add"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor" style="display:none; background-color: #e6e6e6; float: right;">
                <div class="loader">Loading...</div>
            </a>-->
<a  id="moreDatesButtonLoader_add"  href="{!! url('auth/login') !!}" class="btnBlue addDateMoreLoad floatRight" style="display:none;">
                <div class="loader">Loading...</div>
            </a>  
<!--<a  id="moreDatesButtonLoader_add"  href="{!! url('auth/login') !!}" class="btnBlue  descripLoadingButtons" style="display:none; background-color: #e6e6e6;float:right; width: 72%;">
                <div class="loader">Loading...</div>
            </a>-->
                              
                                
                                
                            </div>
                            </div>
                                                        
                            <div class="clear"></div>
                            
                            <div class="span10 sl_span10">{{trans('global.Location') }}
                            
                            <input type="hidden" id="addActivityLatitude" name="activityLatitude" class="adding" placeholder="{{trans('global.Address') }}" />
                            <input type="hidden" id="addActivityLongitude" name="activityLongitude" class="adding" placeholder="{{trans('global.Address') }}" />
                            <input type="text" id="addActivityAddress" name="activityAddress" class="adding" placeholder="{{trans('global.Address') }}" />
                            <div class="error_msg_map" id="addActivityAddress_error" >Address required</div>
                            </div>
                            <div class="span10 sl_span10">
                            {{trans('global.Description') }}<textarea id="addActivityDescription" onkeyup="javascript:capFirst(this);" name="activityDescription"  placeholder="{{trans('global.Description') }}" class="directionBox adding"></textarea>
                            <div class="error_msg_map" id="addActivityDescription_error" >Description required</div>
                            </div>
                            
                            <div class="clear"></div>
                            <div class="span10 sl_span10">
<!--                            <div class="span2half md_span4 sl_span10">-->
<div class="placeHolder120">
                            {{trans('global.PerformerPhoto')}}
                                <div class="logoBg">
                                    <input type="hidden" id="file_fileElem" name="performerPhoto" >
                                    <input type="hidden" id="thumbnail_fileElem" name="performerPhotoThumb" >
                                    
                                <input type="file" accept="image/*" id="fileElem" class="adding" multiple onchange="uploadImage(this)">
                                <span id="fileSelect">
                                
<!--                                    <img id="image_fileElem" src="{{ URL::asset('images/Performer_Placeholder.png')}}" />-->
                                 <div id="image_fileElem" class="centerFocuseDiv borderLightGray placeHolderImg120" style="background-image: url('{{ URL::asset('images/Performer_Placeholder.png')}}'); background-size: cover;
   "></div>
                                
                                    <div class="linkSec">
                                        <div class="imgSec"><img src="{{ URL::asset('images/camera-icon.png') }}" /></div><div class="containt"> {{trans('global.Upload')}}</div>
                                    </div>
                                </span>
                                <div class="progressbar" id="progressdiv_fileElem" ></div>
                                <div  id="error_msg_div_fileElem" style="color:red;  margin-bottom: 10px;font-size:12px;" ></div>
                                <div class="error_msg_map" id="fileElem_error" >Photo required</div>
                                </div>
                            </div>
                            
                            
                            <div class="widthLes120 fontBoldNormal">
                            <div class="textRed">**{{trans('global.ImageProperties')}}**</div>
                            <ol style="margin-left:15px;">
                            <li>{{trans('global.Smallestdimensionscedule')}}</li>
                            <li>{{trans('global.largestdimensioscedule')}}</li>
                            <li>{{trans('global.recomendedration')}}</li>
                            <li>{{trans('global.filesizeshouldbescedule')}}</li>
                            <li>{{trans('global.imagefileshouldbescedule')}}</li>
                            <li>{{trans('global.subjectshouldbescedule')}}</li>
                            </ol>
                            </div>
                            <div class="clear"></div>
                            </div>
                            
                            <div class="clear"></div>
                            <div class="span5 sl_span10">{{trans('global.PerformerName')}}
                                <input type="text" name="performerName" id="addPerformerName" onkeyup="javascript:capFirst(this);" class="adding" placeholder="{{trans('global.PerformerName')}}" />
                                <div class="error_msg_map" id="addPerformerName_error" >Performer name required</div>
                            </div>
                            <div class="span5 sl_span10">{{trans('global.TypeofAircraft')}}
                                <input type="text" name="airCraftType" id="addAirCraftType" class="adding" placeholder="{{trans('global.TypeofAircraft')}}" />
                                <div class="error_msg_map" id="addAirCraftType_error" >Aircraft type required</div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span10 sl_span10">
                           {{trans('global.WebsiteURL')}}
                           <input type="text" id="addActivityWebUrl" name="WebUrl" onChange="webUrl(this)" class="adding" placeholder="{{trans('global.WebsiteURL')}}" />
                           <div class="error_msg_map" id="addActivityWebUrl_error" >Website url required</div>
                            </div>
                            <div class="span10 sl_span10">
                              {{trans('global.FacebookURL')}}
                              <input type="text" id="addActivityFbUrl" name="FbUrl" onChange="webUrl(this)" class="adding" placeholder="  {{trans('global.FacebookURL')}}" />
                              <div class="error_msg_map" id="addActivityFbUrl_error" >Facebook url required</div>
                            </div>
                            <div class="span10 sl_span10">
                              {{trans('global.TwitterURL')}}
                              <input type="text" id="addActivityTwitterUrl" name="TwitterUrl" onChange="webUrl(this)" class="adding"  placeholder="  {{trans('global.TwitterURL')}}" />
                              <div class="error_msg_map" id="addActivityTwitterUrl_error" >Twitter url required</div>
                            </div>
                            
                           
                            <div class="clear"></div>
                            
                            
                            
                        </div>
                        
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
        </form>
<!--Add Schedules Box End--> 

    













 
    <div id="loaderbox" style="display:none" align="center">
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
                    <div class="eventPopUpHead"><div id="loaderBoxHeading">  </div>
                
                
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                        
                        
                        
                        <div class="popupLoaderBgSec" style="display: block">

<div class="loaderImgSec"><div class="loader">Loading...</div> </div>
</div>
                            

                        
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
       



 
 
 <div id="editForm"></div>
            
@stop

@section('_scripts')
  <script type="text/javascript" >
      
      function showLoadingBox(heading){
          $('#loaderBoxHeading').text(heading);
           hideAndShow('loaderbox');
      }
      
//    if($('#loadmoreScheduleCount').text() == 10){
        var isLoadingData = true;
//    }else{
//        var isLoadingData = false;
//    }
      
      $(window).scroll(function(){
       if( isLoadingData == true){
             if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                    isLoadingData = false;
                    var limit_value = 10;
                    var offset_value = $('#loadmoreScheduleCount').text();
                    loadMoreSchedules(limit_value,offset_value);
             }
       }
    });
    
    
    function loadMoreSchedules(limit_value,offset_value){
        
        //$('#loadmoreSchedulesLoader').show();
        $('#loadmoreSchedulesLoader').css('display','block');
        
        var event_id = "{{$event_id}}";
        var data = "limit_value=" + limit_value + "&offset_value=" + offset_value + "&event_id=" + event_id;
            $.ajax({
                url: "{!! url('schedule/loadmore') !!}",
                type: "post",
                data: data
            }).done(function(result){
                //$('#loadmoreSchedulesLoader').hide();
                $('#loadmoreSchedulesLoader').css('display','none');
                var res = $.parseJSON(result);
                if(res.schedule_count > 0){
                    $('#schedulesList').append(res.html);
                    var availableScheduleCount = $('#loadmoreScheduleCount').text();
                    var totalCount = parseInt(availableScheduleCount) + parseInt(res.schedule_count);
                    $('#loadmoreScheduleCount').text(totalCount);
                    isLoadingData = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
			title : 'Error',
			text  : 'Please check the internet connection.',
                        autoclose : 'true',
                      });
               
            });
        
    }
    
      
      $(document).ready(function () {
      $(":text,textarea").focus(function() {
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
               // $('#allfields_error').hide();
        });
        
        $(":text.eventtiminigs").click(function() {
            alert();
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
               // $('#allfields_error').hide();
        });
        
        $(":file").change(function() {
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
               // $('#allfields_error').hide();
               //  $('#endDateSmall_error').hide();
        });
       });
       
function enableAllFields(){
    
   // $('#cancelButton_edit').css('display','block');
            
        $(":text.editing,:checkbox.editing,textarea.editing,:button.editing").each(function() {
                    $(this).attr("disabled",false);
            });
             $(":text.dontcheckedit").each(function() {
                    $(this).attr("disabled",false);
            });
            $(":file.editing").each(function() {
                    $(this).attr("disabled",false);
                    $('.Selector').show();
                    
                    $('#updateScheduleButton').show();
                    $('#editScheduleButton').hide();
                   // alert($(this).id);
            });
    }
      
function editSchedule(schedule_id,edit_flag){
          
         // alert(edit_flag);
          var schedulename = $('#scheduleNameDiv_'+schedule_id).text();
          var heading = '{{$event->name}}'+' - '+schedulename;
         showLoadingBox(heading);
         
          var event_id = '{{$event_id}}';
          //$(".pageLoaderBgSec").css({ 'display': "block" });
          
          $.ajax({
                            url: "{!! url('schedule/edit') !!}",
                            type: "post",
                            data: "schedule_id=" + schedule_id + "&event_id=" + event_id
                        }).done(function(result){
                            
                        var res = $.parseJSON(result); 
                        if(res.result > 0){
                                $('#editScheduleLoader').hide();
                                $('#editScheduleButton').show();
                                $('#editForm').html(res.html);
                                
                                
                                
                                showLoadingBox(heading);
                                
                                                        if(edit_flag == 0){
                                                            
                                                            
                                                        // $('#cancelButton_edit').css('display','none');
                                                        $('#updateScheduleButton').hide();
                                                        $('#editScheduleButton').show();

                                                        $(":text.editing,:checkbox.editing,textarea.editing,:button.editing").each(function() {
                                                        $(this).attr("disabled",true);
                                                        //$(this).prop("disabled",true);
                                                        
                                                        });
                                                        
                                                        $(":text.dontcheckedit").each(function() {
                                                        $(this).attr("disabled",true);
                                                        //$(this).prop("disabled",true);
                                                        
                                                        });
                                                        
                                                        $(":file.editing").each(function() {
                                                        $(this).attr("disabled",true);
                                                        $('.Selector').hide();


                                                        });
                                                        }else{
                                                         // $('#cancelButton_edit').css('display','block');
                                                       $('#updateScheduleButton').show();
                                                        $('#editScheduleButton').hide();
                                                        }
                                
                                
                                
                                
                               // $(".pageLoaderBgSec").css({ 'display': "none" });
                                hideAndShow('editSchedulesBtn');
                        }else{
                                $('#editScheduleLoader').hide();
                                $('#editScheduleButton').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : '{{trans('global.Useraddingfailed') }}',
                                  autoclose : 'true',
                                });
                        }
                        
                        })
                        .fail(function(){
                                $('#editScheduleLoader').hide();
                                    $('#editScheduleButton').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                        });
          
          
      }
      
$(document).ready(function () {
        
        $('#addScheduleForm').submit(function (e) {
            
            isMultyDay =  $("input[name='isMultiDayActive']");
                  var dd = isMultyDay.is(":checked");
            
           // alert();
            
            
            var error  = 0;
            e.preventDefault();
            var i=0;
            
            if(dd){
                $(":text.adding,:text.dontcheck,:file.adding,textarea.adding").each(function() {
                
                                if($(this).val() === ""){
                                    error = 1;
                                    i++;
                                    var errorid = this.id+'_error';
                                    $('#'+errorid).show();
                                }
                                
            });
            }else{
                
                $(":text.adding,:file.adding,textarea.adding").each(function() {
                
                                if($(this).val() === ""){
                                    error = 1;
                                    i++;
                                    var errorid = this.id+'_error';
                                    $('#'+errorid).show();
                                }
                                
            });
            }
            
          
      
      
        var count = $('.eventtimings').size();
            var indexvalue = (count/3)+1;
            
            //addArray
            
            console.log(addArray.length);
                    
                    $('#isMultiDayActive_error').html('');
                    
                   // var isMultiDayActive = $('#checkboxG2').val();
                     var isMultiDayActive = $('#checkboxG2').is(':checked');
                     
                    console.log(isMultiDayActive);
                    
                    if(isMultiDayActive == 1){
                        if(addArray.length <= 1){
                            $('#isMultiDayActive_error').html('please un check the multiday activity for single date.').show();
                           error = 1;
                            //alert('please un check the multiday activity for single dates');
                        }
                    }
            
       // return false;    
              if(error == 1){    
            // $('#addScheduleButton').show();
            // $('#addScheduleLoader').css('display','none');
             return false; 
        }
            
            
           // for (i = 1; i < indexvalue; i++) { 
                jQuery.each( addArray, function( j, i ) {
                 
                 var startdate = $('#addStartDate'+i).val();
                 var starttime = $('#addStartTime'+i).val();
                 var endtime = $('#addEndTime'+i).val();
                 
                 console.log(i);
                
                 var startdatearr = startdate.split('-');
                 var starttimearr = starttime.split(':');
                 var endtimearr = endtime.split(':');
                 
                // 0 date ,1 month ,2 year
               
//                 var Start_Date = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0']);
//                 var Start_Time = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0'],starttimearr['0'],starttimearr['1']);
//                 var End_Time = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0'],endtimearr['0'],endtimearr['1']);
                 
                  // 0 month, 1 date ,2 year
                  var Start_Date = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1']);
                 var Start_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],starttimearr['0'],starttimearr['1']);
                 var End_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],endtimearr['0'],endtimearr['1']);


                        var date = new Date();
                        var month = date.getMonth()+1;
                        var now = month + "-" + date.getDate() + "-" + date.getFullYear();
                        /*
                        if((Start_Date.getTime() < new Date(now).getTime())){
                            //console.log('past date');
                            $('#addStartDate'+i+'_error').text('Date should be future date.').show();
                            error = 1;
                        }else if((Start_Date.getTime() == new Date(now).getTime())){
                                    //console.log('same dates');
                                if(Start_Time.getTime() < new Date().getTime()){
                                    //console.log('same date but time left');
                                    $('#addStartTime'+i+'_error').text('Time should be future time.').show();
                                    error = 1;
                                }
                                if(End_Time.getTime() < new Date().getTime()){
                                    //console.log('same date but time left');
                                    $('#addEndTime'+i+'_error').text('Time should be future time.').show();
                                    error = 1;
                                }else if(End_Time.getTime() <= Start_Time.getTime()){
                                    //console.log('same date but end time should be more');
                                    $('#addEndTime'+i+'_error').text('End time should be more than start time.').show();
                                    error = 1;
                                }
                                
                        }else if( (Start_Date.getTime() > new Date(now).getTime())){
                                    //console.log('future date');
                                if(End_Time.getTime() <= Start_Time.getTime()){
                                    //console.log('future date but end time low');
                                    $('#addEndTime'+i+'_error').text('End time should be more than start time.').show();
                                    error = 1;
                                }
                        }
                        */
                       
                        if(End_Time.getTime() <= Start_Time.getTime()){
                                         $('#addEndTime'+i+'_error').text('End time should be more than start time.').show();
                                         error = 1;
                        }
                  
                   if(dd == false){
                       //alert('in');
                      // break;
                       return false;
                   }
                 
            });
            
            //return false;
   
        $('#addScheduleButton').hide();
        $('#addScheduleLoader').css('display','block');
       
        if(error == 1){    
             $('#addScheduleButton').show();
             $('#addScheduleLoader').css('display','none');
             return false; 
        }
        
      
        $('#addScheduleButton').hide();
      $('#addScheduleLoader').css('display','block');
       
       var addScheduleData = $( this ).serializeArray();
        jQuery.each( addScheduleData, function( i, val ) {
            
            //console.log(i);
            //console.log(val);
        
        });
       //var ddd = jQuery.parseJSON(addScheduleData);
       //console.log(addScheduleData);
       //return false;
       
                        $.ajax({
                            url: "{!! url('schedule/store') !!}",
                            type: "post",
                            data: addScheduleData
                        }).done(function(result){
//                            $('#addScheduleLoader').hide()
//                            $('#addScheduleButton').show();
//                             var res = $.parseJSON(result); 
//                             alert();
//                             
                        var res = $.parseJSON(result); 
                        if(res.result > 0){
                                $('#addScheduleLoader').css('display','none');
                                $('#addScheduleButton').show();
                                $('#moreDates').html('');
                                $('#addScheduleForm')['0'].reset();
                                hideAndShow('addSchedulesBtn');
                                $('#nodatafound').remove();
                                $('#schedulesList').prepend(res.html);
                        }else{
                                $('#addScheduleLoader').css('display','none');
                                $('#addScheduleButton').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : '{{trans('global.Useraddingfailed') }}',
                                  autoclose : 'true',
                                });
                        }
                        
                        })
                        .fail(function(){
                                $('#addScheduleLoader').hide();
                                    $('#addScheduleButton').show();
                                    $('#moreDates').html('');
                                    $('#addScheduleForm')['0'].reset();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                        });
       
        });
   });
      
function removeDate(id)
{
    //console.log(id);
    var removeItem = id;
   addArray = jQuery.grep(addArray, function(value) {
   return value != removeItem;
    });
    
            
            if ( typeof editArray !== "undefined" && editArray) {
            var removeItem = id;
            editArray = jQuery.grep(editArray, function(value) {
            return value != removeItem;
            });
            } 
        // editArray.pop(id); 
         
         //console.log(editArray);
         $('#dateSection'+id).remove();
         
      }
      
 function generateUUID(){
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
}
      
    function contact()
    {
            var d=document.cont;
            if(d.phone.value=="* Phone Number")
            {
                    alert("Enter Your Phone");
                    d.phone.focus();
                    return false;
            }

            if(d.comments.value=="* Comments")
            {
                    alert("Enter Your Comments");
                    d.comments.focus();
                    return false;
            }

            return true;
    }

function validatephone(xxxxx) {
	 var maintainplus = '';
 	var numval = xxxxx.value
 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
 	curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
 	xxxxx.value = maintainplus + curphonevar;
 	var maintainplus = '';
 	xxxxx.focus;
}

                           // var addArray = [];


$(document).ready(function() {
  
$('input[name="isMultiDayActive"]').change(function () {
    if (this.checked) {
       $('#moreDatesButton_add').show();
       $('#checkboxG2').val(1);
       $('#isMultiDayActive_error').html('');
       
       
       //console.log(addArray.length);
       
         if(addArray.length > 1){
           
             //show more dates div
             $('#moreDatesButton_add').show();
       $('#moreDates').show();
             
         }else{
             
             //Add first date div
             addMoreDates()
             $('#moreDates').show();
             
         }
        
       
       
    }else{
        
       $('#isMultiDayActive_error').html('');
       // addArray = [];
       $('#moreDatesButton_add').hide();
       $('#checkboxG2').val(0);
       $('#moreDates').hide();
    }
});

$('input[name="isAvailableForLiveStream"]').change(function () {
    if (this.checked) {
       $('#checkboxG1').val(1);
       
    }else{
       $('#checkboxG1').val(0);
       
    }
});

});

$(document).ready(function() {
	$('a#editSchedulesBtn').click(function() {
		
		var eventStatus = $('#editSchedulesBtn').html();
		 if(eventStatus == 'Edit'){		
		$('#schedulesForm input[type=text] ').attr("disabled",false);	
		$('#schedulesForm input[type=checkbox] ').attr("disabled",false);
		$('#schedulesForm button').attr("disabled",false);
		$('#schedulesForm .files').attr("disabled",false);
		$('#schedulesForm textarea ').attr("disabled",false);
		$('#editSchedulesBtn').html("Save");
		}
		else if(eventStatus == 'Save'){		
		$('#schedulesForm input[type=text] ').attr("disabled",true);
		$('#schedulesForm input[type=checkbox] ').attr("disabled",true);
		$('#schedulesForm button').attr("disabled",true);
		$('#schedulesForm .files').attr("disabled",true);
		$('#schedulesForm textarea ').attr("disabled",true);
		$('#editSchedulesBtn').html("Edit");
		}
		 
	});
});

document.querySelector('#fileSelect').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

$(document).ready(function()
{
	$('#addStartDate1').bootstrapMaterialDatePicker
	({
		time: false,
                format : 'MM-DD-YYYY',
                minDate: new Date()
	});
	$('#addStartTime1').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});

	$('#addEndTime1').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm'
	});
       
});

function addMoreDates(){
    
    //var addArray = [];
    
    //console.log(addArray);
    
    //$('#moreDatesButton_add').hide();
    $('#moreDatesButtonLoader_add').css('display','block');
    
    var count = $('.eventtimings').size();
    //var indexvalue = (count/3)+1;
    var indexvalue = generateUUID();
    addArray.push(indexvalue);
    console.log(addArray);
    //return false;
    var data = "indexvalue=" + indexvalue;
    
                    $.ajax({
                        url: "{!! url('schedule/moredates') !!}",
                        type: "post",
                        data: data
                    }).done(function(result){
                        var res = $.parseJSON(result);
                        $('#moreDatesButton_add').show();
                        $('#moreDatesButtonLoader_add').css('display','none');
                        $('#moreDates').append(res.html);
                        
                    })
                    .fail(function() {
                            $('#storeUserLoader').hide();
                            $('#storeUser').show();
                            modal({
                              type  : 'error',
                              title : '{{trans('global.Error') }}',
                              text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                              autoclose : 'true',
                            });
                    });
}

function uploadImage(input){
    
    //alert();
    
    var file = input.files[0];
    
    var reader = new FileReader();
    var image  = new Image();

    reader.readAsDataURL(file);  
    reader.onload = function(_file) {
        image.src    = _file.target.result;              // url.createObjectURL(file);
        image.onload = function() {
            
            var thumbnaildefault = "{{ URL::asset('images/Performer_Placeholder.png')}}";
            
           
            
            var error = 0;
            var error_msg = '';
            var w = this.width;
            var h = this.height;
            var t = file.type;                         // ext only: // file.type.split('/')[1],
            var n = file.name;
            var s = ~~(file.size/1024) +'KB';
            var size = (file.size/1024);
            var FileExtention = file.name.split('.').pop().toLowerCase();
            //alert(FileExtention);
//            console.log(w);
//              console.log(h);
//                console.log(t);
//                  console.log(n);
//                    console.log(FileExtention);
//                    console.log(size);
                    
var id = input.id;
 $('#error_msg_div_'+id).html('');
  //$('#image_'+id).attr('src',thumbnaildefault);
  $('#image_'+id).css("background", "url("+ thumbnaildefault +") no-repeat");
 

                if(w > 800){
                    error_msg = '*Width should not greater than 800px. <br/>';
                    error = 1;
                }else if(w < 500){
                    error_msg += '*Width should not lower than 500px. <br/>';
                    error = 1;
                }
                
                if(h > 800){
                    error_msg += '*Height should not greater than 800px. <br/>';
                    error = 1;
                }else if(w < 500){
                    error_msg += '*Height should not lower than 500px. <br/>';
                    error = 1;
                }
                 if(size > 300 ){
                    error_msg += '*File size should be no bigger than 300kb. <br/>';
                    error = 1;
                }
                if(FileExtention == 'jpg' || FileExtention == 'jpeg'){
                   
                }else{
                    error_msg += '*Image file should be in JPG or JPEG format. <br/>';
                    error = 1;
                    
                }
                
               
                
//                if(error == 1){
//                    $('#error_msg_div_'+id).html(error_msg);
//                    return false;
//                }
                
                
                
                
                var id = input.id;
                 if(error == 1){
                    $('#error_msg_div_'+id).html(error_msg);
                    return false;
                }
    var formData = new FormData();
    formData.append('image',file);
    $.ajax({
    url: "{!! url('user/s3upload') !!}",
    type: "post",
    data: formData,
    contentType: false,
    cache: false,
    processData:false,
    xhr: function() {
        var xhr = $.ajaxSettings.xhr();
        if (xhr.upload) {
        xhr.upload.addEventListener('progress', function(evt) {
        var percent = (evt.loaded / evt.total) * 100;
        var count = 0;
        var count = percent.toFixed();
        
        ///console.log(count);
         $("#progressdiv_"+id).fadeIn('slow');
		$("#progressdiv_"+id).text(count + '%');
		$("#progressdiv_"+id).width(count + '%');
        
        
        }, false);
        }
        return xhr;
    }
    }).done(function(result){
       $("#progressdiv_"+id).fadeOut('slow');
        $("#progressdiv_"+id).text('');
        $("#progressdiv_"+id).width('0%');
       var res = $.parseJSON(result);
       //$('#image_'+id).attr('src',res.ThumbnailPath);
       $('#image_'+id).css("background", "url("+ res.ThumbnailPath +") no-repeat");
       $('#thumbnail_'+id).val(res.ThumbnailUrl);
       $('#file_'+id).val(res.FileUrl);
    })
    .fail(function(){
        modal({
        type  : 'error',
        title : 'Error',
        text  : 'Please check the internet connection.',
        autoclose : 'true',
        });
    });
                
                
                
                
                
                
                
        }
        }
     
    
}

function deleteSchedule(scheduleId){
        
           
			modal({
				type  : 'confirm',
				title : '{{trans('global.Confirm') }}',
				text  : 'Are you sure you want delete schedule.',
				callback: function(result){ 
                                    if(result == true){
                                            $('#scheduleDiv_' + scheduleId).slideUp('slow').remove();
                                            //$('#scheduleDiv_' + scheduleId).remove();
                                                var scheduledata = $('#schedulesList').text().trim().length;
                                                if(scheduledata == 0){
                                                $('#schedulesList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                                                }
                      
                                           /// return false;
                                            
                                            var scheduledeletingData = "schedule_id=" + scheduleId;
                                            $.ajax({
                                            url: "{!! url('schedule/destroy') !!}",
                                            type: "post",
                                            data: scheduledeletingData
                                            }).done(function(result){
                                                    
                                                

                                            })
                                            .fail(function(){
                                            modal({
                                            type  : 'error',
                                            title : 'Error',
                                            text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                            autoclose : 'true',
                                            });
                                            });
                                    }
                                }
			});
		
                    
                    
    }

function socialUrl(input) {
        var url = $('#'+input.id).val();
           
   var re = /(http(s)?:\\)?([\w-]+\.)+[\w-]+[.com|.in|.org]+(\[\?%&=]*)?/
  
 if (re.test(url)) {
        if (url.indexOf("https://") != -1) {
            url = url.replace(/http:\/\/w/gi, "w");
            url = url.replace(/https:\/\/w/gi, "w");
            if(url != ''){
            $('#'+input.id).val(url);
            }
        }
        if (url.indexOf("https://") == -1) {
            if (url.indexOf("http://") != -1) {
                url = url.replace(/http:\/\/w/gi, "w");
            }
            if(url != ''){
             $('#'+input.id).val("https://" + url);
            }
        }
        
          }else{
       // alert('Please Enter Valid URL');
        $('#'+input.id+'_error').html('Enter valid URL').show();
    }
        
     }

function webUrl(input) {
    
        
        var url = $('#'+input.id).val();
        
          var re = /(http(s)?:\\)?([\w-]+\.)+[\w-]+[.com|.in|.org]+(\[\?%&=]*)?/
  
 if (re.test(url)) {
        if (url.indexOf("http://") != -1) {
            url = url.replace(/http:\/\/w/gi, "w");
            url = url.replace(/https:\/\/w/gi, "w");
            if(url != ''){
            $('#'+input.id).val(url);
            }
        }
        if (url.indexOf("http://") == -1) {
            if (url.indexOf("https://") != -1) {
                url = url.replace(/https:\/\/w/gi, "w");
            }
            if(url != ''){
            $('#'+input.id).val("http://" + url);
            }
        }
        
         }else{
       // alert('Please Enter Valid URL');
        $('#'+input.id+'_error').html('Enter valid URL').show();
    } 
}




function dd(){
    
    
    //            var stt = new Date( d + starttime );
//		stt = stt.getTime();
//		
//		var endt = new Date( d + endtime);
//		endt = endt.getTime();
//                
//                console.log(stt);
//                console.log(endt);
                
                        
                 
                 
                       // var enddate = $('#eventEndDate').val();
                       // var startdate = $('#eventStartDate').val();

//                        var startdatearr = startdate.split('-');
//                      //  var enddatearr = enddate.split('-');
//
//                        var st = startdatearr['1']+'-'+startdatearr['0']+'-'+startdatearr['2'];
                      //  var et = enddatearr['1']+'-'+enddatearr['0']+'-'+enddatearr['2'];
//
//                        var st1 = new Date(st).getTime();
//                        var et1 = new Date(et).getTime();
//
//                        if( (new Date(st1).getTime() > new Date(et1).getTime()))
//                        {
//                               $('#endDateSmall_error').show();
//                               return false;
//                        }else{
//                            $('#endDateSmall_error').hide();
//                        }
//                 
//                 console.log(startdate);
//                  console.log(starttime);
//                   console.log(endtime);
                   
                       // var st1 = new Date().getTime();
                       // var et1 = new Date(et).getTime();
}

</script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
</script>


@stop

