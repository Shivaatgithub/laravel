@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
     @include('admin._left-menu-main')
@stop


@section('_content')

     <div class="rightSec">
        	<div class="rightBoxSec">
                
                
                <div class="headingMain">{{trans('global.ParkingUpdates') }}</div>
                <div class="clear"></div>
                <div class="searchSec">
                <div class="parkingErrormessageDiv" style="color: red; font-size: 13px; margin-bottom: 10px;" id="errorMessage_parking"></div>
                <form id="storeParkingForm" class="formReset" />
                <input type="text" onkeyup="javascript:capFirst(this);" id="parking_text" placeholder="{{trans('global.EnterParkingUpdates') }}" class="searchBox" />
                 <input id="storeParking" type="submit" value="{{trans('global.POST') }}" class="seachBtn" />
                    
                 
                 <button class="seachBtn parkingLoadingButtons" style="display: none;" id="storeParkingLoader">
<div class="loader">Loading...</div>
</button>
                 
<!--                 <div style="display: none;" id="storeParkingLoader" align="center">
                        <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />
                     
                 
                     </div>-->
                <div class="clear"></div>
                </form>
                </div>
             <div style="display: none;" id="loadmoreparkingCount">{{ $parking_count }}</div>
               <div id="parkingList" class="rowBox">

              @if($parking_count>0)
            @foreach($parkings as $parking) 
            <div  class="rowSec" id="parkingInformation_{{ $parking->id }}">
                <div onclick="editParking({{ $parking->id }},0)" class="detailsSec">
                    <div class="name" id="parkingText_{{ $parking->id }}">{{ $parking->message }}</div>
                    <div class="details">
                    
                        <div id="parkingdate_{{ $parking->id }}">{{ date("M d Y - h:i:s",($offset)+($parking->last_modifed_on/1000)) }}</div>
                    </div>
                </div>
                <div class="optionSec">
                    <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            
                              <li><a onclick="editParking({{ $parking->id }},1)">Edit</a></li>
                        
                            <li><a onclick="deleteParking({{ $parking->id }})">Delete</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            @endforeach
              @else
                 
                        @include('admin.__partial_nodatafound')
                 
                    @endif

            <div class="clear"></div>
              
        </div>
                   
                <div class="clear">&nbsp;</div>
<!--                 <div align="center" id="loadmoreparkingLoader" style="display: none;">
            <img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div>-->
                
                  <a  id="loadmoreparkingLoader"  class="btnBlue loadPageLoderBg btnLoaderAdjust" style="display:none; background-color: #f7f7f7">
                            <!-- <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> -->
    <div class="loader1">Loading...</div>
            </a>
            </div>
         
            <div class="clear"></div>
        </div>
 
        <!--Edit parking Box Start-->
    <div id="editParkings" style="display:none" align="center">
        <div class="popUpSec">
        	<div class="popUpBoxSmall">
            	<div class=" headingMain popUpHead">{{trans('global.ParkingDetails') }}</div>
                <div class="formSec">
                    <div class="parkingErrormessageDiv" style="color: red; font-size: 13px;" id="errorMessageEditparking"></div>
                    <form id="editParkingForm">
                    
                      <div id="editParkingId" style="display: none;"></div>
                    <div class="rows fontBold600">
                   {{trans('global.EnterParkingUpdates') }}
                   <textarea class="directionBox" id="editparkingtext" onkeyup="javascript:capFirst(this);"> </textarea></div>
                    <div class="clear"></div>
                    <div class="cols2">
                           
                    <a onclick="hideAndShow('editParkings');" class="floatLeft btnLightGray popupDescripBtnS">{{trans('global.Cancel') }}</a>
                    </div>
                    <div class="cols2">
                 <input id="updateparkingButton"  type="submit"  value="Save" class="floatRight bgBlue popupDescripBtnS">
                 <input id='updateparkingbuttonEdit' type="button" onclick='enableAllEditFields()'  value="{{trans('global.Edit') }}" class="btnSave popupDescripBtnS floatRight">
<!--                    <div align="center" id="updateParkingLoader" style="display: none;">
                        <img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div>
                    </div>-->
<button class="seachBtn descripLoadingButtons" style="display: none;" id="updateParkingLoader">
<div class="loader">Loading...</div>
</button>
                    <div class="clear"></div>
                     
                    </form>
                	
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--Edit parking Box End--> 
    </div>
    
            
@stop

@section('_scripts')
  <script type="text/javascript" >
      
      
      
      
      //Add parking functionality
    $(document).ready(function () {
    
        $('#storeParkingForm').submit(function (e) {
             
            $('#storeParkingLoader').show();
            $('#storeParking').hide();       
            e.preventDefault();
            var error = 0;
            var parking_text = $('#parking_text').val();
            if(parking_text == ''){
                $("#errorMessage_parking").text('{{trans('global.Pleaseenterparkigupdate') }}').show();   
                var error = 1;
            }
            if(error == 1){  $('#storeParkingLoader').hide();
                                $('#storeParking').show(); return false; } 
                            
           $("#errorMessage_parking").hide();         
            var parking_text = $('#parking_text').val();
            var parkingAddingData = "parking_text=" + encodeURIComponent(parking_text);
            
                        $.ajax({
                           url: "{!! url('parking/store') !!}",
                        type: "post",
                        data: parkingAddingData
                        }).done(function(result){
                          
                        var res = $.parseJSON(result); 
                       
                        if(res.result.length > 0){
                                $('#storeParkingLoader').hide();
                                $('#storeParking').show();
                                $('#storeParkingForm')['0'].reset();
                                hideAndShow('sampleHideShow');
                                $('#nodatafound').remove();
                                $('#parkingList').prepend(res.html);
                        }else{
                                $('#storeParkingLoader').hide();
                                $('#storeParking').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : '{{trans('global.Parkingtextaddingfailed') }}',
                                 
                                });
                        }
                        
                        
                        })
                        .fail(function() {
                           
                                $('#storeParkingLoader').hide();
                                $('#storeParking').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error')}}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection')}}',
                                 
                                });
                        });
 
        });
    });
    
    //Load more functionality
      var isLoadingData = true;
    $(window).scroll(function(){
       if( isLoadingData == true){
             if($(window).scrollTop() + $(window).height() > $(document).height() - 100){
                    isLoadingData = false;
                    var limit_value = 10;
                    var offset_value = $('#loadmoreparkingCount').text();
                    loadMoreUsers(limit_value,offset_value);
                   
                   
             }
       }
    });
    
    
    function loadMoreUsers(limit_value,offset_value){
        
        $('#loadmoreparkingLoader').show();
        var data = "limit_value=" + limit_value + "&offset_value=" + offset_value;
      
            $.ajax({
                url: "{!! url('parking/loadmore') !!}",
                type: "post",
                data: data
            }).done(function(result){
                $('#loadmoreparkingLoader').hide();
                var res = $.parseJSON(result);
               
                if(res.parking_count > 0){
                    $('#parkingList').append(res.html);
                    var availableParkingCount = $('#loadmoreparkingCount').text();
                    var totalCount = parseInt(availableParkingCount) + parseInt(res.parking_count);
                    $('#loadmoreparkingCount').text(totalCount);
                    isLoadingData = true;
                }
            })
            .fail(function() {
               
                      modal({
			type  : 'error',
		        title : '{{trans('global.Error') }}',
                        text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                        autoclose : 'true',
                      });
               
            });
        
    }
    
    
    //delete User
    function deleteParking(parkingid){
          
			modal({
				type  : 'confirm',
				title : '{{trans('global.Confirm') }}',
				text  : '{{trans('global.Areyousureyouwanttodeleteparkingupdate') }}',
				callback: function(result){ 
                                    if(result == true){
                                        $('#parkingInformation_' + parkingid).slideUp('slow').remove();
                                            
                                            //$('#scheduleDiv_' + scheduleId).remove();
                                                var parkingdivdata = $('#parkingList').text().trim().length;
                                                if(parkingdivdata == 0){
                                                $('#parkingList').html('<div id="nodatafound" class="detailsSec" style="text-align:center;padding:20px 10px;font-weight: bold;" >{{trans('global.Nodatafound') }}</div>');
                                                }
 
                                            var parkingdeletingData = "parking_id=" + parkingid;
                                            $.ajax({
                                            url: "{!! url('parking/destroy') !!}",
                                            type: "post",
                                            data: parkingdeletingData
                                            }).done(function(emailValidationResult){


                                            })
                                            .fail(function(){
                                            modal({
                                            type  : 'error',
                                            title : '{{trans('global.Error') }}',
                                            text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                            autoclose : 'true',
                                            });
                                            });
                                    }
                                }
			});
		
                    
                    
    }
    
     //display edit parking form
    function editParking(parkingid,edit_flag){
      
        if(edit_flag == 0){
           
            $('#updateparkingButton').hide();
             $('#updateparkingbuttonEdit').show();              
             $("#editparkingtext").prop("disabled", true);
           
        }else{
             
                    $('#updateparkingButton').show();
                    $('#updateparkingbuttonEdit').hide();
                    enableAllEditFields();
        }
        
        
        hideAndShow('editParkings');
        var Parking_text = $('#parkingText_'+parkingid).text();       
        $('#editparkingtext').val(Parking_text);
        $('#editParkingId').text(parkingid);
    }
      function enableAllEditFields(){
         
           $("#editparkingtext").prop("disabled", false);
           $('#updateparkingButton').show();
           $('#updateparkingbuttonEdit').hide();
    }
    //update user calling
    
     $(document).ready(function () {
        $('#editParkingForm').submit(function (e) {
            
        $('#updateParkingLoader').show();
        $('#updateparkingButton').hide();
        
        e.preventDefault();
        var error = 0;
     
        var parkingid = $('#editParkingId').text();
        var parking_Tex = $('#editparkingtext').val();
        
            if(parking_Tex == ''){
                $("#errorMessageEditparking").text('{{trans('global.Pleaseenterparkigupdate') }}').show();
                
                var error = 1;
            }
         if(error == 1){    
             $('#updateParkingLoader').hide();
             $('#updateparkingButton').show(); 
             return false; 
         }     
            $("#errorMessageEditparking").hide();   
        
        var parkingUpdatingData = "parking_id=" + parkingid + "&parking_Tex="+encodeURIComponent(parking_Tex);
    
                            $.ajax({
                                url: "{!! url('parking/update') !!}",
                                type: "post",
                                data: parkingUpdatingData
                            }).done(function(result){
                                
                                 var res = $.parseJSON(result);                                 
                                if(res.result.length > 0){
                                        $('#updateParkingLoader').hide();
                                        $('#updateparkingButton').show();
                                        hideAndShow('editParkings');
                                        $('#editParkingForm')['0'].reset();
                                        window.location.href="{!! url('parking') !!}"
                                       // $('#parkingInformation_'+parkingid).html(res.html);
                                }else{
                                        $('#updateParkingLoader').hide();
                                        $('#updateparkingButton').show();
                                        modal({
                                          type  : 'info',
                                          title : '{{trans('global.Warning') }}',
                                          text  : '{{trans('global.parkingtextupdatefailed') }}',
                                          autoclose : 'true',
                                        });
                                }
                           
                            })
                            .fail(function(){
                                $('#updateParkingLoader').hide();
                                $('#updateparkingButton').show();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                            });
                                  
      });
      
    });
    
    
</script>



<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
</script>
@stop

