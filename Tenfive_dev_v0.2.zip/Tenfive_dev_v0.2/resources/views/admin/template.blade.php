@yield('header')

<body>
         @yield('_styles')

	<div class="innerPages">
   	  	
        
            @yield('_header')
        
            
             @yield('_left-menu')
        
        
            @yield('_content')
            
        
    	<div class="clear"></div>
	</div>
        
            @yield('_scripts')


</body>
</html>
