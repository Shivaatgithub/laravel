@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop


@section('_left-menu')
    @include('admin._left-menu-main')
@stop


@section('_content')
  <div class="rightSec">
        	<div class="rightBoxSec">
                
                
                <div class="boxHeading">
                     {{trans('global.PushNotification') }}
                </div>

                <div class="rowBox">
                    <div class="rowSec">
                    
                    	<div class="notificationSec">
                        <div class="gridRowsSec">
                                <div class="span10">
                                    <input type="text" placeholder="{{trans('global.EnterMessagetoUser') }}" />
                                </div>
                            </div>    
                            
                        <div class="clear"></div>
                        
                        <div align="center"><input type="button" value="{{trans('global.SendPushNotification')}}" class="notificationBtn" onclick="hideAndShow('alertNotification');" /></div>
                        </div>
                    
                    </div>
                <div class="clear"></div>
                    	<div class="notificationSec">
                        <div class="confirmationSec">
                        	<div class="confirmIcon"><img src="images/confirm-icon.png" /></div>
                            <div class="confirmMsg">{{trans('global.PushNotificationmessage')}}</div>
                        </div>    
                            
                        <div class="clear"></div>
                        
                        </div>
                <div class="clear"></div>
            </div>
            
            
            
            
            
            
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        
      <div id="alertNotification" style="display:none" align="center">
        <div class="alertPopUpSec">
        	<div class="alertPopUpBox">
            	<div class="alertPopUpHead">  {{trans('global.PushMessage') }}
                
                
                
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                    
                    	<div class="gridRowsSec">
                        
                        	<div class="messageSec">
                            	 {{trans('global.Areyousurewanttosendthispush') }}<br />
<br />

                            </div>
                            <div class="clear"></div>
                            <div class="popUpBtnSec">
                            <a onclick="hideAndShow('alertNotification');" class="btnCancel">{{trans('global.Cancel') }}</a>
                            <a href="{!! url('notificationsuccess') !!}" class="btnSave">{{trans('global.Save') }}</a>
                            
                            <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    
                    <div class="clear"></div>
                    
                        
                    </div>
                    <div class="clear"></div>
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>     
@stop

@section('_scripts')
  <script type="text/javascript" >
<!--Validations For Phone Text Box Start-->
function contact()
{
	var d=document.cont;
if(d.phone.value=="* Phone Number")
	{
		alert("Enter Your Phone");
		d.phone.focus();
		return false;
	}
	
	if(d.comments.value=="* Comments")
	{
		alert("Enter Your Comments");
		d.comments.focus();
		return false;
	}
	
	return true;
}

function validatephone(xxxxx) {
	 var maintainplus = '';
 	var numval = xxxxx.value
 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
 	curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
 	xxxxx.value = maintainplus + curphonevar;
 	var maintainplus = '';
 	xxxxx.focus;
}
<!--Validations For Phone Text Box End-->



<!--For Edit and Save Start-->
$(document).ready(function() {
	$('a#editSchedulesBtn').click(function() {
		
		var eventStatus = $('#editSchedulesBtn').html();
		 if(eventStatus == 'Edit'){		
		$('#advertisementsForm input[type=text] ').attr("disabled",false);	
		$('#advertisementsForm input[type=checkbox] ').attr("disabled",false);
		$('#advertisementsForm button').attr("disabled",false);
		$('#advertisementsForm .files').attr("disabled",false);
		$('#advertisementsForm textarea ').attr("disabled",false);
		$('#advertisementsForm select ').attr("disabled",false);
		$('#editSchedulesBtn').html("Save");
		}
		else if(eventStatus == 'Save'){		
		$('#advertisementsForm input[type=text] ').attr("disabled",true);
		$('#advertisementsForm input[type=checkbox] ').attr("disabled",true);
		$('#advertisementsForm button').attr("disabled",true);
		$('#advertisementsForm .files').attr("disabled",true);
		$('#advertisementsForm textarea ').attr("disabled",true);
		$('#advertisementsForm select ').attr("disabled",true);
		$('#editSchedulesBtn').html("Edit");
		}
		 
	});
});

</script>
@stop

