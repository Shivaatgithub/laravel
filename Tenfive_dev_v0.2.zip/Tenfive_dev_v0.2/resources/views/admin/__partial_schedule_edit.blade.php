<script>
var placeSearch, autocomplete1;
function initialize1() {
 autocomplete1 = new google.maps.places.Autocomplete(
(document.getElementById('editActivityAddress')),
      { types: ['geocode'] });
  google.maps.event.addListener(autocomplete1, 'place_changed', function() {
    fillInAddress1();
  });
}
function fillInAddress1() {
    var place = autocomplete1.getPlace();
    var lat = place.geometry.location.lat();
    var lng = place.geometry.location.lng();
    $('#editActivityLatitude').val(lat);
    $('#editActivityLongitude').val(lng);
}
function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = new google.maps.LatLng(
          position.coords.latitude, position.coords.longitude);
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
$( document ).ready(function() {
  initialize1();
});

    </script>
<form class="formReset" method="post" id="editScheduleForm">
    <div id="editSchedulesBtn" style="display:none" align="center">
        <div class="eventPopUpSec">
        	<div class="eventPopUpBox">
            	<div class="eventPopUpHead">
                    <!-- {{trans('global.NewSchedule') }} -->
                    {{$event->name or '' }} - {{$schedule->name or '' }}
                
                    <div  class="formReset formResetPopup">
                <div class="popUpBtnSec">
                    <a  id='cancelButton_edit' onclick="hideAndShow('editSchedulesBtn');" class="btnCancel">{{trans('global.Cancel') }}</a>
                
                
                <!--<a href="#"  class="btnSave">{{trans('global.Save') }}</a>-->
                <input type="submit" class="forBtnLink" value="{{trans('global.Save') }}" id="updateScheduleButton" />
                <input type="button" class="forBtnLink" onclick="enableAllFields()" value="{{trans('global.Edit') }}" id="editScheduleButton" />
<!--                <div align="center" id="addScheduleLoader" style="display: none;">
<img src="{{ URL::asset('images/loader_trans1.GIF') }}" />
            <div class="loader">Loading...</div>
        </div>-->
                
<!--            <a id="updateScheduleLoader"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor" style="display:none; background-color: #e6e6e6; float: right;">
                <div class="loader">Loading...</div>
            </a>-->
<a id="updateScheduleLoader"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor floatRight" style="display:none; background-color: #e6e6e6; margin: -2px 0px 0px 10px;
    padding: 4px 21px 4px 21px;">
                <div class="loader">Loading...</div>
            </a>
                
                
                </div>
                <div class="clear"></div>
                    </div>
                <div class="clear"></div>
                
                </div>
                
                
                <div class="bigFormSec">

                    <div class="formBoxSec">
                        
                            
                            
                    	<div class="gridRowsSec fontBold600">
                            <input type="hidden" name="event_id" value="{{ $schedule->event_id or '' }}" />
                            <input type="hidden" name="activity_id" value="{{ $schedule->id or '' }}" />
                        	<div class="span5 sl_span10">
                                    
                                    
                            	{{trans('global.ActivityName') }}
                                
                                
                                <input type="text" id="editActivityName" class="editing" onkeyup="javascript:capFirst(this);" name="activityName" placeholder="{{trans('global.ActivityName') }}" value="{{$schedule->name or '' }}"/>
                                <div class="error_msg_map" id="editActivityName_error" >Name required</div>
                                
                            </div>
                            <div class="span5 sl_span10">
                            <div class="checkBoxLiveStreamSec">
                                <input type="checkbox" value="{{ $schedule->is_live_stream or 0  }}" name="editIsAvailableForLiveStream" id="editIsAvailableForLiveStream" class="css-checkbox editing"   
                                       
                                       <?php if($schedule->is_live_stream == 1){ echo 'checked'; } ?>
                                       
                                       
                                       />
                            <label for="editIsAvailableForLiveStream" class="css-label"> {{trans('global.AvailableforLiveStream') }}</label>
                            </div>
                            </div>
                            
                            <div class="clear"></div>
                            <script>
                            var editArray = [];
                            </script>
                   <?php $i=0 ?>     
                @foreach($schedule_timings as $schedules) 
                     

                <div id="dateSection{{$schedules->id}}" class="moreDatesSub<?php  if($i == 0){ echo $i; } ?>">
                        <div class="span3 sl_span6">
                           <input type="hidden"  name='activityDateTime[{{$schedules->id}}][id]'   value="{{ $schedules->id }}">
                          Start date
                          <input type="text"  name='activityDateTime[{{$schedules->id}}][startDate]' class="eventtimingsedit  dontallowinput <?php  if($i != 0){ echo ' dontcheckedit'; } else{ echo ' editing';} ?>" id='editStartDate{{$schedules->id}}' placeholder="Start date"  
                                 value="{{ date("m-d-Y",($offset)+($schedules->date/1000)) }}">
                          <div class="error_msg_map" id="editStartDate{{$schedules->id}}_error" >Date required</div>
                          
                          
                          </div>
                          <div class="span2 sl_span4">
                          Start time
                          <input type="text"  name='activityDateTime[{{$schedules->id}}][startTime]' class="eventtimingsedit  dontallowinput <?php  if($i != 0){ echo ' dontcheckedit'; }else{echo ' editing';} ?>" id='editStartTime{{$schedules->id}}' placeholder="Start time"
                                 value="{{ date("H:i",($offset)+($schedules->start_time/1000)) }} ">
                          <div class="error_msg_map" id="editStartTime{{$schedules->id}}_error" >Start time required</div>
                          </div>
                          <div class="span3 sl_span6">
                          End time
                          <input type="text"  name='activityDateTime[{{$schedules->id}}][endTime]' class="eventtimingsedit  dontallowinput <?php  if($i != 0){ echo ' dontcheckedit'; }else{ echo ' editing';} ?>"  id='editEndTime{{$schedules->id}}' placeholder="End time" 
                                 value="{{ date("H:i",($offset)+($schedules->end_time/1000)) }} ">
                           <div class="error_msg_map" id="editEndTime{{$schedules->id}}_error" >End time required</div>
                          </div>
                          <div class="span2 sl_span4">
                          @if($i > 0)
                          <div class="scheduleDeleteBtnSec">
                          <input type="button"  onclick="removeDate({{$schedules->id}})" value="{{trans('global.Delete') }}" class="btnDelete floatRight buttonsPaddingSec editing" />
                          </div>
                          @endif    
                          </div>
                        <script>

                        $(document).ready(function()
                        {
                            
                            $('#editStartDate{{$schedules->id}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
        $('#editStartTime{{$schedules->id}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
        $('#editEndTime{{$schedules->id}}').focus(function() {
		var errorid = this.id+'_error';
                $('#'+errorid).hide();
	});
                            
                         
                            $('#editStartDate{{$schedules->id}}').bootstrapMaterialDatePicker
                        ({
                        time: false,
                minDate: new Date(),
                format : 'MM-DD-YYYY'
                        
                        });
                            $('#editStartTime{{$schedules->id}}').bootstrapMaterialDatePicker
                        ({
                            date: false,
                            shortTime: true,
                            format: 'HH:mm'
                        });
                        $('#editEndTime{{$schedules->id}}').bootstrapMaterialDatePicker
                        ({
                            date: false,
                            shortTime: true,
                            format: 'HH:mm'
                        });
                        });
                        
                        
                        editArray.push('{{$schedules->id}}');
                        
                        </script>
                        <div class="clear"></div>
                        </div>
                         <?php $i++ ?>   
                @endforeach
                            
                                                      
                          <div class="clear"></div>  
                <div id="moreDatesEdit" style="width:100%;">
                                
                                
                                
                            </div>
                            
                            
                            <div class="clear"></div>
                            <div class="span5 sl_span10">
                            <div class="checkBoxSec">
                                
                               
                                <input type="checkbox" value="{{ $schedule->is_multi_day_activity or 0  }}" name="editIsMultiDayActive" id="editIsMultiDayActive" class="css-checkbox editing" 
                                       
                                        <?php  if($schedule->is_multi_day_activity == 1){ echo 'checked'; } ?>
                                       
                                />
                                                            
                               
                                <label for="editIsMultiDayActive" class="css-label"> {{trans('global.MultiDayActivity') }}</label>
                                <div class='error_msg_map' id='editIsMultiDayActive_error'>Please un check for single day activity. </div>
                              
                            </div>
                            </div>
                            <div class="span5 sl_span10">
                            <div class="scheduleAddMoreBtnSec">
                                 
                                <input type="button" style="display: <?php  if($schedule->is_multi_day_activity == 1){ echo 'block'; }else{echo 'none'; }?>" id="moreDatesButton_edit" onclick="addMoreDatesEdit()" value="{{trans('global.Addmoredatetime') }}" class="btnAddMore floatRight buttonsPaddingSec editing" />
<!--                                  <a  id="moreDatesButtonLoader_edit"  href="{!! url('auth/login') !!}" class="btnBlue loaderBodyBgColor" style="display:none; background-color: #e6e6e6; float: right;">
                <div class="loader">Loading...</div>
            </a>-->

<!--<a  id="moreDatesButtonLoader_edit"  href="{!! url('auth/login') !!}" class="btnBlue  descripLoadingButtons" style="display:none; background-color: #e6e6e6;float:right; width: 72%;">
                <div class="loader">Loading...</div>
            </a>-->
<a  id="moreDatesButtonLoader_edit"  href="{!! url('auth/login') !!}" class="btnBlue addDateMoreLoad floatRight" style="display:none;">
                <div class="loader">Loading...</div>
            </a>
                            </div>
                            </div>
                                                        
                            <div class="clear"></div>
                            
                            <div class="span10 sl_span10">{{trans('global.Location') }}
                            
                                <input type="hidden" value="{{ $schedule->latitude or '' }}" id="editActivityLatitude" name="activityLatitude" class="editing" placeholder="{{trans('global.Address') }}" />
                                <input type="hidden" value="{{ $schedule->longitude or '' }}" id="editActivityLongitude" name="activityLongitude" class="editing" placeholder="{{trans('global.Address') }}" />
                                <input type="text" value="{{ $schedule->location or '' }}" id="editActivityAddress" name="activityAddress" class="editing" placeholder="{{trans('global.Address') }}" />
                                <div class="error_msg_map" id="editActivityAddress_error" >Address required</div>
                                
                            
                            </div>
                            <div class="span10 sl_span10">
                            {{trans('global.Description') }}<textarea id="editActivityDescription" onkeyup="javascript:capFirst(this);" name="activityDescription"  placeholder="{{trans('global.Description') }}" class="directionBox editing">{{ $schedule->description or ''}}</textarea>
                            <div class="error_msg_map" id="editActivityDescription_error" >Description required</div>
                            </div>
                            
                            <div class="clear"></div>
                            <div class="span10 sl_span10">
                            <div class="placeHolder120">
                            {{trans('global.PerformerPhoto')}}
                                <div class="logoBg">
                                    <input type="hidden" id="file_fileElem1" name="performerPhoto" value="{{ $performer->performer_photo or '' }}" >
                                    <input type="hidden" id="thumbnail_fileElem1" name="performerPhotoThumb" value="{{ $performer->performer_photo_thumb or '' }}" >
                                    
                                <input type="file" accept="image/*" id="fileElem1" class="editing" multiple onchange="uploadImage(this)">
                                <span id="fileSelect1">
                                
                                    @if($performer->performer_photo_thumb != null)
                                    
<!--                                    <img id="image_fileElem1" src="{{ trans('global.s3filepath').$performer->performer_photo_thumb }}"/>-->
                                    <div id="image_fileElem1" class="centerFocuseDiv borderLightGray placeHolderImg120" style="background-image: url('{{ trans('global.s3filepath').$performer->performer_photo_thumb }}'); background-size: cover;
    " ></div> 
                                    
                                    @else
                                    <img id="image_fileElem1" src="{{ URL::asset('images/Performer_Placeholder.png') }}"/>
                                    @endif
                                    
                                    <div class="linkSec Selector">
                                        <div class="imgSec"><img src="{{ URL::asset('images/camera-icon.png') }}" /></div><div class="containt"> {{trans('global.Upload')}}</div>
                                    </div>
                                </span>
                                <div class="progressbar" id="progressdiv_fileElem1" ></div>
                                <div  id="error_msg_div_fileElem1" style="color:red;  margin-bottom: 10px;font-size:12px;
        " ></div>
        
                                <div class="error_msg_map" id="fileElem1_error" >photo required</div>
        
                                </div>
                            </div>
                            
                            
                            <div class="widthLes120 fontBoldNormal">
                            <div class="textRed">**{{trans('global.ImageProperties')}}**</div>
                            <ol style="margin-left:15px;">
                            <li>{{trans('global.Smallestdimensionscedule')}}</li>
                            <li>{{trans('global.largestdimensioscedule')}}</li>
                            <li>{{trans('global.recomendedration')}}</li>
                            <li>{{trans('global.filesizeshouldbescedule')}}</li>
                            <li>{{trans('global.imagefileshouldbescedule')}}</li>
                            <li>{{trans('global.subjectshouldbescedule')}}</li>
                            </ol>
                            </div>
                            <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                            <div class="span5 sl_span10">{{trans('global.PerformerName')}}
                                <input type="text" name="performerName" id='editPerformerName'  onkeyup="javascript:capFirst(this);" class="editing" placeholder="{{trans('global.PerformerName')}}" value="{{ $performer->performer_name or '' }}" />
                            <div class="error_msg_map" id="editPerformerName_error" >Name required</div>
                            </div>
                            <div class="span5 sl_span10">{{trans('global.TypeofAircraft')}}
                                <input type="text" name="airCraftType"  name="editAirCraftType" class="editing" placeholder="{{trans('global.TypeofAircraft')}}" value="{{ $schedule->aircraft_type or '' }}" />
                                 <div class="error_msg_map" id="editAirCraftType_error" >Aircraft type required</div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span10 sl_span10">
                           {{trans('global.WebsiteURL')}}
                           <input type="text" id="editActivityWebUrl" name="WebUrl" onChange="webUrl(this)"  class="editing" placeholder="{{trans('global.WebsiteURL')}}"  value="{{ $schedule->website_url or '' }}"  />
                            <div class="error_msg_map" id="editActivityWebUrl_error" >Web url required</div>
                            </div>
                            <div class="span10 sl_span10">
                              {{trans('global.FacebookURL')}}
                              <input type="text" id="editActivityFbUrl" name="FbUrl" onChange="webUrl(this)" class="editing" placeholder="  {{trans('global.FacebookURL')}}"  value="{{ $schedule->facebook_url or '' }}"  />
                            <div class="error_msg_map" id="editActivityFbUrl_error" >Facebook url required</div>
                            </div>
                            <div class="span10 sl_span10">
                              {{trans('global.TwitterURL')}}
                              <input type="text" id="editActivityTwitterUrl" name="TwitterUrl"  onChange="webUrl(this)" class="editing"  placeholder="  {{trans('global.TwitterURL')}}"  value="{{ $schedule->twitter_url or '' }}"  />
                            <div class="error_msg_map" id="editActivityTwitterUrl_error" >Twitter url required</div>
                            </div>
                           
                            <div class="clear"></div>
                            
                        </div>
                        
                    <div class="clear"></div>
                    
                        
                    </div>
                    
                	
                </div>
                
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
        </form>
<script>
    
    
document.querySelector('#fileSelect1').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem1'); 
  fileInput.click();
}, false);
    
      $(document).ready(function () {
          
         
        
        $('#editScheduleForm').submit(function (e) {
            
           
                qisMultyDay =  $("input[name='editIsMultiDayActive']");
        var dd1 = qisMultyDay.is(":checked");
                  
        var error  = 0;
            
            
           // alert(dd1);
            var i=0;
            if(dd1){
            $(":text.editing,:text.dontcheckedit,textarea.editing,checkbox.editing").each(function() {
                                if($(this).val() === ""){
                                error = 1;
                                i++;
                                var errorid = this.id+'_error';
                                $('#'+errorid).show();

                                }
                        });
                    }else{
                        
            $(":text.editing,textarea.editing,checkbox.editing").each(function() {
                                if($(this).val() === ""){
                                error = 1;
                                i++;
                                var errorid = this.id+'_error';
                                $('#'+errorid).show();

                                }
                        });            
                        
                        
                    }
                    
                    
                    console.log(editArray.length);
                    
                    $('#editIsMultiDayActive_error').html('');
                    
                    var editIsMultiDayActive = $('#editIsMultiDayActive').val();
                    //console.log(isMultiDayActive);
                    
                    if(editIsMultiDayActive == 1){
                        if(editArray.length <= 1){
                            $('#editIsMultiDayActive_error').html('please un check the multiday activity for single date.').show();
                            return false;
                            //alert('please un check the multiday activity for single dates');
                        }
                    }
                    
                    
                    
           // return false;
            
                    jQuery.each( editArray, function( j, i ) {
                       // console.log(i);
                        
                        
                        
                        
                    var startdate = $('#editStartDate'+i).val();
                    var starttime = $('#editStartTime'+i).val();
                    var endtime = $('#editEndTime'+i).val();
                    var startdatearr = startdate.split('-');
                    var starttimearr = starttime.split(':');
                    var endtimearr = endtime.split(':');
                 
                 
                 
                 
                 // 0 date ,1 month ,2 year
               
// var Start_Date = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0']);
//                 var Start_Time = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0'],starttimearr['0'],starttimearr['1']);
//                 var End_Time = new Date(startdatearr['2'],startdatearr['1']-1,startdatearr['0'],endtimearr['0'],endtimearr['1']);
                 
                  // 0 month, 1 date ,2 year
                  var Start_Date = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1']);
                 var Start_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],starttimearr['0'],starttimearr['1']);
                 var End_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],endtimearr['0'],endtimearr['1']);
                 
                 
                 
                


                        var date = new Date();
                        var month = date.getMonth()+1;
                        var now = month + "-" + date.getDate() + "-" + date.getFullYear();
                        
                        /*

                        if((Start_Date.getTime() < new Date(now).getTime())){
                            //console.log('past date');
                            $('#editStartDate'+i+'_error').text('Date should be future date.').show();
                            error = 1;
                        }else if( (Start_Date.getTime() == new Date(now).getTime())){
                                    //console.log('same dates');
//                                if(Start_Time.getTime() < new Date().getTime() || End_Time.getTime() < new Date().getTime()){
//                                    //console.log('same date but time left');
//                                    $('#editStartTime'+i+'_error').text('Time should be future time.').show();
//                                    error = 1;
//                                }else if(End_Time.getTime() <= Start_Time.getTime()){
//                                    //console.log('same date but end time should be more');
//                                    $('#editEndTime'+i+'_error').text('End time should be more than start time.').show();
//                                    error = 1;
//                                }
                                
                                
                                if(Start_Time.getTime() < new Date().getTime()){
                                    //console.log('same date but time left');
                                    $('#editStartTime'+i+'_error').text('Time should be future time.').show();
                                    error = 1;
                                }
                                if(End_Time.getTime() < new Date().getTime()){
                                    //console.log('same date but time left');
                                    $('#editEndTime'+i+'_error').text('Time should be future time.').show();
                                    error = 1;
                                }else if(End_Time.getTime() <= Start_Time.getTime()){
                                    //console.log('same date but end time should be more');
                                    $('#editEndTime'+i+'_error').text('End time should be more than start time.').show();
                                    error = 1;
                                }
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        }else if( (Start_Date.getTime() > new Date(now).getTime())){
                                    //console.log('future date');
                                if(End_Time.getTime() <= Start_Time.getTime()){
                                    //console.log('future date but end time low');
                                    $('#editEndTime'+i+'_error').text('End time should be more than start time.').show();
                                    error = 1;
                                }
                        }
                        */
                       
                       if(End_Time.getTime() <= Start_Time.getTime()){
                                    $('#editEndTime'+i+'_error').text('End time should be more than start time.').show();
                                    error = 1;
                       }
                        
                        if(dd1 == false){
                                return false;
                        }
                        
                       
                        
                    });
            
                
                   
            // e.preventDefault();
            // var error  = 0;
            e.preventDefault();
            
            
     
             //console.log(editArray);
            // return false;  
      
       
       
        $('#updateScheduleButton').hide();
        $('#updateScheduleLoader').css('display','inline-block');
       //  return false; 
       
        if(error == 1){    
             $('#updateScheduleButton').show();
             $('#updateScheduleLoader').css('display','none');
             return false; 
        }
        
       
        //var scheduleId = '{{$schedule->id}}';
        
       
       var editScheduleData = $( this ).serialize();
       
                        $.ajax({
                            url: "{!! url('schedule/update') !!}",
                            type: "post",
                            data: editScheduleData
                        }).done(function(result){
//                            $('#addScheduleLoader').hide()
//                            $('#addScheduleButton').show();
//                             var res = $.parseJSON(result); 
//                             alert();
//                             
                        var res = $.parseJSON(result); 
                        if(res.result > 0){
                              $('#updateScheduleLoader').css('display','none');
                                $('#updateScheduleButton').show();
                                $('#moreDates').html('');
                                //$('#addScheduleForm')['0'].reset();
                                hideAndShow('editSchedulesBtn');
                                $('#scheduleDiv_{{$schedule->id}}').html(res.html);
                                
                        }else{
                               $('#updateScheduleLoader').css('display','none');
                                $('#updateScheduleButton').show();
                                modal({
                                  type  : 'info',
                                  title : '{{trans('global.Warning') }}',
                                  text  : '{{trans('global.Useraddingfailed') }}',
                                  autoclose : 'true',
                                });
                        }
                        
                        })
                        .fail(function(){
                                $('#updateScheduleLoader').css('display','none');
                                $('#updateScheduleButton').show();
                                    //$('#moreDates').html('');
                                    //$('#addScheduleForm')['0'].reset();
                                modal({
                                  type  : 'error',
                                  title : '{{trans('global.Error') }}',
                                  text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                                  autoclose : 'true',
                                });
                        });
       
        });
   });
    
    
    
    
    
    
    $(document).ready(function() {
$('input[name="editIsMultiDayActive"]').change(function () {
    if (this.checked) {
       
       
       $('#moreDatesButton_edit').show();
       $('#editIsMultiDayActive').val(1);
       $('#editIsMultiDayActive_error').html('');
       
       if(editArray.length > 1){
           
             //show more dates div
       $('#moreDatesButton_edit').show();
       $('#moreDatesEdit').show();
       $('.moreDatesSub').show();
             
         }else{
             
             //Add first date div
             addMoreDatesEdit()
             $('#moreDatesEdit').show();
              $('.moreDatesSub').show();
         }
       
       
       
       
       
    }else{
        
       $('#editIsMultiDayActive_error').html(''); 
       $('#moreDatesButton_edit').hide();
       $('#editIsMultiDayActive').val(0);
       $('.moreDatesSub').hide();
       $('#moreDatesEdit').hide();
      // moreDatesSub
       
       
    }
});

$('input[name="editIsAvailableForLiveStream"]').change(function () {
    if (this.checked) {
       $('#editIsAvailableForLiveStream').val(1);
       
    }else{
       $('#editIsAvailableForLiveStream').val(0);
       
    }
});

});


function addMoreDatesEdit(){
    
    //$('#moreDatesButton_edit').hide();
      $('#moreDatesButtonLoader_edit').css('display','block');
    
    var count = $('.eventtimingsedit').size();
    var indexvalue = (count/3)+1;
    var indexvalue = generateUUID();
    //return false;
    var data = "indexvalue=" + indexvalue;
    
                    $.ajax({
                        url: "{!! url('schedule/moredatesedit') !!}",
                        type: "post",
                        data: data
                    }).done(function(result){
                        $('#moreDatesButton_edit').show();
                        $('#moreDatesButtonLoader_edit').css('display','none');
                        var res = $.parseJSON(result);
                        $('#moreDatesEdit').append(res.html);
                    })
                    .fail(function() {
                            $('#storeUserLoader').hide();
                            $('#storeUser').show();
                            modal({
                              type  : 'error',
                              title : '{{trans('global.Error') }}',
                              text  : '{{trans('global.Pleasechecktheinternetconnection') }}',
                              autoclose : 'true',
                            });
                    });
}


    </script>