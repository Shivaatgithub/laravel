<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
    
<meta name="_token" content="{!! csrf_token() !!}"/>
<title>{{ $title }}</title>
<script type="text/javascript" src="{{ URL::asset('js/jquery.min-2.1.3.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/jquery.cookie.js') }}"></script>
<!--Date and Time Picker Sec-->
<link rel="stylesheet" href="{{ URL::asset('css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="https://rawgit.com/FezVrasta/bootstrap-material-design/master/dist/css/material.min.css" />
<link rel="stylesheet" href="{{ URL::asset('css/bootstrap-material-datetimepicker.css') }}" />
<link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://rawgit.com/FezVrasta/bootstrap-material-design/master/dist/js/material.min.js"></script>
<script type="text/javascript" src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
<script type="text/javascript" src="{{ URL::asset('js/bootstrap-material-datetimepicker.js') }}"></script>
<!--// Date and Time Picker Sec-->
<link href="{{ URL::asset('css/style.css') }}" rel="stylesheet" type="text/css" />
<link href="http://www.jqueryscript.net/demo/Animated-Multi-purpose-Modal-Box-Plugin-For-jQuery/css/jquery.modal.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://www.jqueryscript.net/demo/Animated-Multi-purpose-Modal-Box-Plugin-For-jQuery/js/jquery.modal.min.js"></script>

<!--// Exhibits -->
<script src="{{URL::asset('js/classie.js') }}"></script>
<script src="{{URL::asset('js/selectFx.js') }}"></script> 
<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/cs-select.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/cs-skin-border.css') }}" />


<script>
function hideAndShow(id)
{
	$('#'+id).toggle();
        $('.formReset')['0'].reset();
        $('.errorMessageDiv').hide();
        $('.popupErrorMessageDiv').hide();
        $('.popupTbox').removeClass('errorTbox');
        $('.error_msg').hide();
        $('.error_msg_map').hide();
        $('#moreDates').html('');
        
        $('#error_msg_div_fileElem').html('');
        $('#error_msg_div_fileElem1').html('');
        
        $('#errorMessage_parking').html('');
        $('#errorMessageEditparking').html('');
        
}

$(document).ready(function () {
$('.dontallowinput').keydown(function() {
  //code to not allow any changes to be made to input field
  return false;
});
});


 function capFirst(oTextBox) {

        oTextBox.value = oTextBox.value[0].toUpperCase().trim() + oTextBox.value.substring(1);
           }
</script>


<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true&libraries=places"></script>




</head>