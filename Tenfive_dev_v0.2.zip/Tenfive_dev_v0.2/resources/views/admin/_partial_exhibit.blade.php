   
@foreach($exhibits as $exhibit) 

            <div class="rowSec" id="exhibitInformation_{{ $exhibit->id }}">
<!--                <div class="detailsSec" onclick="editParking({{ $exhibit->id }})">
                    
                    <div class="name" id="{{ $exhibit->id }}">{{ $exhibit->name }}</div>

                </div>-->
                    <div class="exhibitSec" onclick="editExhibit({{ $exhibit->id }},0)">
                        <div class="exhibitImg">
                          @if($exhibit->photo_thumb =='') 
                               <img src="{{ URL::asset('images/Placeholder Exhibit.png') }}" />
                                    @endif
                                    
                                        @if($exhibit->photo_thumb !='') 
<!--                                            <div class="croppedImgSec" style="background-image:url({{trans('global.s3filepath').$exhibit->photo_thumb }});">
</div>-->
                    <div class="centerFocuseDiv placeHolderImg80" style="background-image:url({{trans('global.s3filepath').$exhibit->photo_thumb }});">
</div>       

                                    @endif
                        </div>
                        <div class="details">
                           
                            <div class="name">{{ $exhibit->name }}</div>
                                @if($exhibit->is_sponsored == 1) 
                     <div class="active">{{trans('global.Sponsored') }}</div>
                      @endif
                        </div>
                    </div>
                <div class="optionSec">
                    <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                            
                            <li><a onclick="editExhibit({{ $exhibit->id }},1);">{{trans('global.Edit') }}</a></li>
                          
                            <li><a onclick="deleteExhibit({{ $exhibit->id }})">{{trans('global.Delete') }}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
 @endforeach

