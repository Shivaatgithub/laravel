@foreach($schedules as $schedule) 
<div class="rowSec" id='scheduleDiv_{{$schedule->id }}'>
                    <a onclick="editSchedule({{ $schedule->id }},0);">
                    <div class="detailsSec">
                    	<div class="name">{{$schedule->activity_name}}</div>
                        <div class="details">
                        	<div>{{ $schedule->performer_name }}</div>
<!--                        	<div>Date - Start time - End time</div>-->
            {{ date("M d Y",($offset)+($schedule->activity_date/1000)) }} -  {{ date("g:i a",($offset)+($schedule->start_time/1000)) }} - {{ date("g:i a",($offset)+($schedule->end_time/1000)) }}
                        </div>
                    </div>
                    </a>
                    <div class="optionSec">
                    
                        <div tabindex="0" class="onclick-menu">
                        <ul class="onclick-menu-content">
                        <li><a onclick="editSchedule({{ $schedule->id }},1);">{{trans('global.Edit') }}</a></li>
                        <li><a onclick="deleteSchedule({{ $schedule->id }});">{{trans('global.Delete') }}</a></li>
                        </ul>
                        </div>

                    </div>
                    <div class="clear"></div>
                    
</div>
@endforeach