@extends('admin.template')

@section('header')
    @include('admin.header')
@stop

@section('_header')
    @include('admin._header')
@stop

@section('_left-menu')
    @include('admin._left-menu-event')
@stop


@section('_content')
<style>
    .error_msg{
        color:red;
        margin-top: -13px;
        margin-bottom: 10px;
        font-size:12px;
        display: none;
    }
    
    .error_msg_map{
        color:red;
        display: none;
        margin-bottom: 10px;
        font-size:12px;
    }
    
    .progressbar{
        color:white;
        background-color: #9a9a9a;
        font-size:12px;
        text-align: center;
    }
    
    </style>
    
    <script>
// This example displays an address form, using the autocomplete feature
// of the Google Places API to help users fill in the information.

var placeSearch, autocomplete;
var componentForm = {
//  street_number: 'short_name',
//  route: 'long_name',
//  locality: 'long_name',
//  administrative_area_level_1: 'short_name',
//  country: 'long_name',
//  postal_code: 'short_name'
  
 //street_number: 'short_name',
 // route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
 // country: 'long_name',
  postal_code: 'short_name'
  
};

function initialize() {
  // Create the autocomplete object, restricting the search
  // to geographical location types.
  autocomplete = new google.maps.places.Autocomplete(
      /** @type {HTMLInputElement} */(document.getElementById('autocomplete')),
      { types: ['geocode'] });
  // When the user selects an address from the dropdown,
  // populate the address fields in the form.
  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    fillInAddress();
  });
}

// [START region_fillform]
function fillInAddress() {
  // Get the place details from the autocomplete object.
    var place = autocomplete.getPlace();
    var lat = place.geometry.location.lat();
    var lng = place.geometry.location.lng();
    $('#eventLatitude').val(lat);
    $('#eventLongitude').val(lng);
    
    for (var component in componentForm) {
    document.getElementById(component).value = '';
    //document.getElementById(component).disabled = false;
  }
//	
//
//  // Get each component of the address from the place details
//  // and fill the corresponding field on the form.
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
      $('#'+addressType+'_error').hide();
    }
  }
}
// [END region_fillform]

// [START region_geolocation]
// Bias the autocomplete object to the user's geographical location,
// as supplied by the browser's 'navigator.geolocation' object.
function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = new google.maps.LatLng(
          position.coords.latitude, position.coords.longitude);
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
// [END region_geolocation]



$( document ).ready(function() {
  initialize();
});

    </script>
    
    
   <div class="rightSec">
        	
            <div class="addEventMainPage">
                
                <form  method="post" action="{!! url($action) !!}"  id='addEventForm'>
                    
                <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                <input type="hidden" name="is_current_event" value="{{ $event->is_current_event or '' }}">
                <input type="hidden" name="is_active" value="{{ $event->is_active or '' }}">
                
                <div class="boxHeading">
                    {{trans('global.AddEvents') }}
                    <div class="eventTopButtonsSec noMargin">
                        
                        
                        
                        
                        
                         
                        <!-- 
                        <a href="#" class="floatLeft bgWhite"> {{trans('global.Cancel') }}</a>
                        <a href="#" class="floatRight bgBlue"> {{trans('global.Save') }}</a>
                        -->
                         
                      <a  id="storeEventLoader"  href="{!! url('auth/login') !!}" class="btnBlue btnEventLoad btnLoaderAdjust" style="display:none; background-color: #e6e6e6">
                            <!-- <div   align="center"><img src="{{ URL::asset('images/loader_trans1.GIF') }}" /></div> -->
                <div class="loader">Loading...</div>
            </a>
                        
                         <input id="storeEvent"  style="display:block;" type="submit"  value="{{trans('global.Save') }}" class="btnEventSave">
                        
                         <input id="storeEventEdit"  style="display:none;" onclick="enableAllInputs();" type="button"  value="{{trans('global.Edit') }}" class="btnEventEdit">
                     
                         <a style="display: <?php if($edit_flag == 0){ echo 'none'; }else{ echo 'block'; }  ?>" href="{!! url('events') !!}" class="btnEventCancel">Cancel</a>
                      

                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                    
                    
                <div class="addEventPage">
                    
                    <div class="error_msg" id="allfields_error"> All fields required</div>
                    
                    <div class="gridRowsSec">
                        
                        
                        
                        <div class="span10 sl_span10">
                        
                            <div class="placeHolder120">
                                <input type="hidden" name="logoThumbnail" id="thumbnail_fileElem" value="{{ $event->event_logo_thumb or '' }}" />
                                <input type="hidden" name="logoFile" id="file_fileElem" value="{{ $event->event_logo or '' }}" />
                                
                                {{trans('global.EventLogo') }}
                                <div class="logoBg">
                                    <input  type="file" accept="image/*" name="eventLogo" id="fileElem" multiple onchange="uploadImage(this)">
                                <span id="fileSelect">
                                    
                                    
                 <?php if( isset($event->event_logo_fullpath)){ ?>                   
                                    
<div id="image_fileElem" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ trans('global.s3filepath').$event->event_logo_fullpath }}');"></div>
                                    
                  <?php }else{ ?>

<div id="image_fileElem" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ URL::asset('images/Logo Placeholder.png') }}');"></div>

                  <?php } ?>
                                    
                                  
                                    
                               <!-- <img id="image_fileElem" src="{{ $event->event_logo_fullpath or URL::asset('images/Logo Placeholder.png') }}" /> -->
                                    <div class="linkSec Selector">
                                        <div class="imgSec"><img  src="{{ URL::asset('images/camera-icon.png') }}" /></div><div class="containt"> {{trans('global.Upload') }}</div>
                                    </div>
                                </span>
                                    
                                   
                                    
                                    <div  class="error_msg_map" id="fileElem_error" >Please select logo</div>
                                    <div  class="progressbar"  id="progressdiv_fileElem" ></div>
                                    
                                </div>
                                
                            </div>
                            <div class="widthLes120 sl_span10">
                            <div class="eventNameField">
                                {{trans('global.EventName') }}
                                <input type="text" name="eventName" onkeyup="javascript:capFirst(this);"  value="{{ $event->name or '' }}" id="eventName"  placeholder="{{trans('global.FullName') }}" />
                                <div class="error_msg" id="eventName_error" >Name required</div>
                            </div>
                                
                            </div>
                            
                            <div class="clear"></div>
                        </div>
                             <div class="clear"></div>
                            <div class="span4 sl_span6 sl_marginLeft0">
                               {{trans('global.StartDate') }}
                               <input type="text" class="dontallowinput" name="eventStartDate"  is-open="keydown" value="{{$event->beginning_date or ''}}"  id="eventStartDate" placeholder="Start date">
                               <div class="error_msg" id="eventStartDate_error" >Start Date required</div>
                            </div>
                            <div class="span2 sl_span4">
                             {{trans('global.StartTime') }}
                            <input type="text" class="dontallowinput" name="eventTime" value="{{ $event->start_time or '' }}" id="eventTime" placeholder="Start time">
                            <div class="error_msg" id="eventTime_error" >Start time required</div>
                            </div>
                            <div class="span4 sl_span6 sl_marginLeft0">
                             {{trans('global.EndDate') }}
                            <input type="text" class="dontallowinput"  name="eventEndDate" value="{{ $event->end_date or '' }}"  id="eventEndDate" placeholder="End date">
                            <div class="error_msg" id="eventEndDate_error" >End Date required</div>
                            <div class="error_msg" id="endDateSmall_error" >End Date should not be lower than start date.</div>
                            
                            </div>
                            
                            
                            <div class="clear"></div>
                            <input type="hidden" name="eventLatitude" id="eventLatitude" value="{{ $event->latitude or '' }}" />
                            <input type="hidden" name="eventLongitude" id="eventLongitude"  value="{{ $event->longitude or '' }}" />
                            
                            <div class="span10 sl_span10">{{trans('global.Location') }}</div>
                            
                            
                            
                            
                            <div class="span4 sl_span5">
                                <input type="text" name="eventAddress"  class="eventAddress" value="{{ $event->street_address or '' }}" onFocus="geolocate()" id="autocomplete"  placeholder="{{trans('global.StreetAddress') }}" />
                                <div class="error_msg" id="autocomplete_error" >Address required</div>
                            </div>
                            <div class="span2 sl_span5">
                            <input type="text" name="eventCity" value="{{ $event->city or '' }}" id="locality" placeholder="{{trans('global.City') }}" />
                            <div class="error_msg" id="locality_error" >City required</div>
                            </div>
                            <div class="span2 sl_span5">
                            <input type="text" name="eventState" value="{{ $event->state or '' }}" id="administrative_area_level_1" placeholder="{{trans('global.State') }}" />
                            <div class="error_msg" id="administrative_area_level_1_error" >State required</div>
                            </div>
                            <div class="span2 sl_span5">
                            <input placeholder="{{trans('global.Zip') }}" value="{{ $event->zip or '' }}"  type="text" name="eventZipCode" id="postal_code" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validatephone(this);" />
                            <div class="error_msg" id="postal_code_error" >Zipcode required</div>
                            </div>
                            

                            
                            
                            
                            <div class="clear"></div>
                            
                            
                            <div class="span10 sl_span10">
                            {{trans('global.WebsiteURL') }} 
                            <input type="text" name="eventWebUrl" id="eventWebUrl" onChange="webUrl(this)"    value="{{ $event->website_url or '' }}" placeholder="{{trans('global.WebsiteURL') }}" />
                            <div class="error_msg" id="eventWebUrl_error" >Website url required</div>
                            </div>
                            <div class="span10 sl_span10">
                               {{trans('global.FacebookURL') }}
                            <input type="text" name="eventFacebookUrl" onChange="webUrl(this)" id="eventFacebookUrl" value="{{ $event->facebook_url or '' }}" placeholder="{{trans('global.FacebookURL') }}" />
                            <div class="error_msg" id="eventFacebookUrl_error" >Facebook url required</div>
                            </div>
                            <div class="span10 sl_span10">
                             {{trans('global.TwitterURL') }}
                            <input type="text" name="eventTwitterUrl" onChange="webUrl(this)" id="eventTwitterUrl" value="{{ $event->twitter_url or '' }}" placeholder="{{trans('global.TwitterURL') }}" />
                            <div class="error_msg" id="eventTwitterUrl_error" >Twitter url required</div>
                            </div>
                            
                           <div class="clear"></div>
                           
                            <div class="span6 md_span10 sl_span10">
                             {{trans('global.Directions') }}
                             <textarea  name="eventTextDirections" id="eventTextDirections" onkeyup="javascript:capFirst(this);"  placeholder="{{trans('global.TextDirections')}}" class="directionBox">{{ $event->text_direction or '' }}</textarea>
                             <div class="error_msg" id="eventTextDirections_error" >Text Directions required</div>
                            </div>
                            <div class="span2 md_span5 sl_span5">
                                <input type="hidden" name="exhibitThumbnail" id="thumbnail_fileElem1" value="{{ $event->exhibit_map_thumb or '' }}" />
                                <input type="hidden" name="exhibitFile" id="file_fileElem1" value="{{ $event->exhibit_map or '' }}" />
                            {{trans('global.ExhibitMap') }}
                                <div class="logoBg">
                                <input  type="file" accept="image/*" name="eventExhibitMap"  id="fileElem1" multiple onchange="uploadImage(this)">
                                <span id="fileSelect1">
                                    
                                    
                                    <!--<div id="image_fileElem1" class="centerFocuseDiv" style="background-image: url('{{ $event->exhibit_map_fullpath or URL::asset('images/Map Placeholder.png') }}');"></div>-->
                       <?php if( isset($event->exhibit_map_fullpath)){ ?>                   
                                    
<div id="image_fileElem1" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ trans('global.s3filepath').$event->exhibit_map_fullpath }}');"></div>
                                    
                  <?php }else{ ?>

<div id="image_fileElem1" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ URL::asset('images/Map Placeholder.png') }}');"></div>

                  <?php } ?>          






<!--<img src="{{ $event->exhibit_map_fullpath or URL::asset('images/Logo Placeholder.png') }}" />-->
                                    <div class="linkSec Selector">
                                        <div class="imgSec"><img src="{{ URL::asset('images/camera-icon.png')}}" /></div><div class="containt">  {{trans('global.Upload') }}</div>
                                    </div>
                                </span>
                                <div class="error_msg_map" id="fileElem1_error" >Exhibit map required</div>
                                <div class="progressbar" id="progressdiv_fileElem1" ></div>
                                </div>
                            </div>
                            
                            <div class="span2 md_span5 sl_span5">
                                <input type="hidden" name="parkingThumbnail" id="thumbnail_fileElem2" value="{{ $event->parking_map_thumb or '' }}" />
                                <input type="hidden" name="parkingFile" id="file_fileElem2" value="{{ $event->parking_map or '' }}" />
                               {{trans('global.ParkingMap') }}
                                <div class="logoBg">
                                <input type="file" accept="image/*"  name="eventParkingMap" id="fileElem2" multiple onchange="uploadImage(this)">
                                <span id="fileSelect2">
                                    
                                    <!--<div id="image_fileElem2" class="centerFocuseDiv" style="background-image: url('{{ $event->parking_map_fullpath or URL::asset('images/Map Placeholder.png') }}');"></div>-->

 <?php if( isset($event->parking_map_fullpath)){ ?>                   
                                    
<div id="image_fileElem2" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ trans('global.s3filepath').$event->parking_map_fullpath }}');"></div>
                                    
                  <?php }else{ ?>

<div id="image_fileElem2" class="centerFocuseDiv placeHolderImg120" style="background-image: url('{{ URL::asset('images/Map Placeholder.png') }}');"></div>

                  <?php } ?>  


<!--                                     <img id="image_fileElem2" src="{{ $event->parking_map_fullpath or URL::asset('images/Map Placeholder.png')}}" />-->
                                    <div class="linkSec Selector">
                                        <div class="imgSec"><img src="{{ URL::asset('images/camera-icon.png')}}" /></div><div class="containt">{{trans('global.Upload') }}</div>
                                    </div>
                                </span>
                                
                                <div class="error_msg_map" id="fileElem2_error" >Parking map required</div>
                                <div  class="progressbar" id="progressdiv_fileElem2" ></div>
                                
                                </div>
                            </div>
                            
                            <div class="clear"></div>
                            
                            <div class="span5 sl_span5">
                            {{trans('global.LostChildSupport') }}
                            
                            <script>
                                $(document).ready(function () {
  //called when key is pressed in textbox
  $("#eventLostChildNo,#eventEmergencyNo ").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 0 && e.which != 43 && e.which != 45 && (e.which < 48 || e.which > 57)) {
        //display error message
               //alert('error');
               return false;
    }
    
   });
});
                                </script>
                            
                            <!--<input placeholder="{{trans('global.PhoneNumber') }}"  type="text" name="eventLostChildNo" id="eventLostChildNo" onfocus="if(this.value=='') this.value='';" onblur="if(this.value=='') this.value='';"  onkeyup="validatephone(this);" value="{{ $event->lost_child_number or '' }}"  />-->
<input placeholder="{{trans('global.PhoneNumber') }}"  type="text" name="eventLostChildNo" id="eventLostChildNo"  value="{{ $event->lost_child_number or '' }}"  />                           
                            
                            <div class="error_msg" id="eventLostChildNo_error" >Lost child number required</div>
                            </div>
                            <div class="span5 sl_span5">
                            {{trans('global.EmergencyNumber') }}
<input placeholder="{{trans('global.PhoneNumber') }}" type="text"  name="eventEmergencyNo" id="eventEmergencyNo"  value="{{ $event->emergency_number or '' }}" />
                            
                            <div class="error_msg" id="eventEmergencyNo_error" >Emergency number required</div>
                            </div>
                            <div class="span10 sl_span10">
                            {{trans('global.GuestServicestextinfo') }}
                            <textarea style="height:120px;"  onkeyup="javascript:capFirst(this);" name="eventGuestServiceInfo" id="eventGuestServiceInfo"   placeholder="{{trans('global.GuestServicestextinfo') }}">{{ $event->guest_services_text or '' }}</textarea>
                            <div class="error_msg" id="eventGuestServiceInfo_error" >Service info required</div>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            <div class="clear"></div>
                            
                            
                            
                  
                            
                        </div>
                        <div class="clear"></div>
                </div>
                    
                <div class="clear"></div>
                
            </form>
                
            	</div>
              
            	<div class="clear"></div>
            
            </div>

 
        
            
@stop

@section('_scripts')
  <script type="text/javascript" >
      
        
      
    $(document).ready(function () {
        var edit_flag = '{{ $edit_flag }}';
        if(edit_flag == 0){
             $('#storeEvent').hide();
         $('#storeEventEdit').show(); 
            $(":text,:checkbox,:file, select, textarea").each(function() {
                    $(this).attr("disabled",true);
            });
            $(":file").each(function() {
                    $(this).attr("disabled",true);
                    $('.Selector').hide();
                   // alert($(this).id);
            });
        }
    });
    
    function enableAllInputs(){
        
        $('.btnEventCancel').css('display','block');
        
        $('#storeEvent').show();
        $('#storeEventEdit').hide();
        $(":text,:checkbox,:file, select, textarea").each(function() {
                    $(this).attr("disabled",false);
            });
            $(":file").each(function() {
                    $(this).attr("disabled",false);
                    $('.Selector').show();
                   // alert($(this).id);
            });
    }
        
      
      $(document).ready(function() {
          
        //$(window).keydown(function(event){
//          if(event.keyCode == 13) {
//            event.preventDefault();
//            return false;
//          }
        //});
  
  
  
  $('textarea').keypress(function(event) {
//        if (event.which == 13) {
//        event.preventDefault();
//        var s = $(this).val();
//        $(this).val(s+"\n");
//        }
        });
        
        
  
  
  
  
  
});

$(document).keypress(function (e) {
  if(e.which == 13 && e.target.nodeName != "TEXTAREA") return false;
});
      
      
function contact()
{
	var d=document.cont;
if(d.phone.value=="* Phone Number")
	{
		alert("{{trans('global.EnterYourPhone')}}");
		d.phone.focus();
		return false;
	}
	
	if(d.comments.value=="* Comments")
	{
		alert("Enter Your Comments");
		d.comments.focus();
		return false;
	}
	
	return true;
}

function validatephone(xxxxx) {
	 var maintainplus = '';
 	var numval = xxxxx.value
 	if ( numval.charAt(0)=='+' ){ var maintainplus = '+';}
 	curphonevar = numval.replace(/[\\A-Za-z!"£$%^&*+_={};:'@#~,.¦\/<>?|`¬\]\[]/g,'');
 	xxxxx.value = maintainplus + curphonevar;
 	var maintainplus = '';
 	xxxxx.focus;
}

document.querySelector('#fileSelect').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

document.querySelector('#fileSelect1').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem1');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

document.querySelector('#fileSelect2').addEventListener('click', function(e) {
  var fileInput = document.querySelector('#fileElem2');
  //click(fileInput); // Simulate the click with a custom event.
  fileInput.click(); // Or, use the native click() of the file input.
}, false);

$(document).ready(function()
{
	$('#eventStartDate').bootstrapMaterialDatePicker
	({
		time: false,
                minDate: new Date(),
                 format : 'MM-DD-YYYY'
	});
	$('#eventEndDate').bootstrapMaterialDatePicker
	({
		time: false,
                minDate: new Date(),
                 format : 'MM-DD-YYYY'
	});

	$('#eventTime').bootstrapMaterialDatePicker
	({
		date: false,
		shortTime: true,
		format: 'HH:mm',
                minTime: new Date()
	});
});

function uploadImage(input){
    var file = input.files;
    var id = input.id;
    console.log(file);
    var formData = new FormData();
    formData.append('image',file[0]);
    $.ajax({
    url: "{!! url('user/s3upload') !!}",
    type: "post",
    data: formData,
    contentType: false,
    cache: false,
    processData:false,
    xhr: function() {
        var xhr = $.ajaxSettings.xhr();
        if (xhr.upload) {
        xhr.upload.addEventListener('progress', function(evt) {
        var percent = (evt.loaded / evt.total) * 100;
        var count = 0;
        var count = percent.toFixed();
        
        ///console.log(count);
         $("#progressdiv_"+id).fadeIn('slow');
		$("#progressdiv_"+id).text(count + '%');
		$("#progressdiv_"+id).width(count + '%');
        
        
        }, false);
        }
        return xhr;
    }
    }).done(function(result){
       $("#progressdiv_"+id).fadeOut('slow');
        $("#progressdiv_"+id).text('');
        $("#progressdiv_"+id).width('0%');
       var res = $.parseJSON(result);
       //$('#image_'+id).attr('src',res.ThumbnailPath);
       $('#image_'+id).css("background", "url("+ res.ThumbnailPath +") no-repeat");
       $('#thumbnail_'+id).val(res.ThumbnailUrl);
       $('#file_'+id).val(res.FileUrl);
    })
    .fail(function(){
        modal({
        type  : 'error',
        title : 'Error',
        text  : 'Please check the internet connection.',
        autoclose : 'true',
        });
    });
}




 






$(document).ready(function () {
    
    $(":text,:checkbox, select, textarea").focus(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error').hide();
              //  }
        });
        
        $(":file").change(function() {
               // if($(this).val() === ""){
              //  error = 1;
                var errorid = this.id+'_error';
                $('#'+errorid).hide();
                $('#allfields_error').hide();
                 //$('#endDateSmall_error').show();
              //  }
        });
        
        $("#eventEndDate").change(function() {
                var enddate = $('#eventEndDate').val();
                        var startdate = $('#eventStartDate').val();

                        var startdatearr = startdate.split('-');
                        var enddatearr = enddate.split('-');

                        var st = startdatearr['1']+'-'+startdatearr['0']+'-'+startdatearr['2'];
                        var et = enddatearr['1']+'-'+enddatearr['0']+'-'+enddatearr['2'];

                        var st1 = new Date(st).getTime();
                        var et1 = new Date(et).getTime();

                        if( (new Date(st1).getTime() > new Date(et1).getTime()))
                        {
                               $('#endDateSmall_error').show();
                               return false;
                        }else{
                            $('#endDateSmall_error').hide();
                        }
        });
    
    
   // function addEvent(){
            $('#addEventForm').submit(function (e) {
                
//                alert(e.keyCode);
//                                if(e.keyCode == '13') {
//                                    alert();
//                            e.preventDefault();
//                            return false;
//                          }
//                          
//                          return false;
                          

               
                
                        var enddate = $('#eventEndDate').val();
                        var startdate = $('#eventStartDate').val();
                        var endtime = $('#eventTime').val();

                        var startdatearr = startdate.split('-');
                        var enddatearr = enddate.split('-');
                        var endtimearr = endtime.split(':');
                        
                        // 0 month, 1 date ,2 year
//                        var st = startdatearr['0']+'-'+startdatearr['1']+'-'+startdatearr['2'];
//                        var et = enddatearr['0']+'-'+enddatearr['1']+'-'+enddatearr['2'];
//                        
//                         var Start_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],starttimearr['0'],starttimearr['1']);
//
//                        var st1 = new Date(st).getTime();
//                        var et1 = new Date(et).getTime();
//
//                        if( (new Date(st1).getTime() > new Date(et1).getTime()))
//                        {
//                               $('#endDateSmall_error').show();
//                               return false;
//                        }else if((new Date(st1).getTime() == new Date(et1).getTime())){
//                            
//                            
//                        }
                        
                 var Start_Date = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1']);
                 var End_Date = new Date(enddatearr['2'],enddatearr['0']-1,enddatearr['1']);
                 var Event_Time = new Date(startdatearr['2'],startdatearr['0']-1,startdatearr['1'],endtimearr['0'],endtimearr['1']);
                        
                        
                        if(Start_Date.getTime() > End_Date.getTime())
                        {
                               $('#endDateSmall_error').show();
                               return false;
                        }
//                          time checking for same dates.
//                        if(Start_Date.getTime() == End_Date.getTime()){
//                            if(Event_Time.getTime() < new Date().getTime()){
//                                    $('#eventTime_error').text('Time should be future time.').show();
//                                    error = 1;
//                                    return false;
//                             }
//                        }
                        
                       
                        
                        
                        var error = 0;
                        var i = 0;
                        $(":text,:checkbox, select, textarea").each(function() {
                                if($(this).val() === ""){
                                error = 1;
                                i++;
                                var errorid = this.id+'_error';
                                $('#'+errorid).show();

                                }
                        });
                        
                        var eventId = '{{$event_id}}';
                        
                        if(eventId == 0){ 
                            $(":file").each(function() {
                                    if($(this).val() === ""){
                                    error = 1;
                                    i++;
                                    var errorid = this.id+'_error';
                                    $('#'+errorid).show();

                                    }
                            });
                       }

                        if(i == 18){
                            $('#allfields_error').show();
                            error = 1;
                        }
                        if(error == 1){    
                            // $('#storeEventLoader').hide();
                            // $('#storeEvent').show(); 
                             return false; 
                        }
                        
                        
                        $('#storeEventLoader').css('display','block');
                        $('#storeEvent').css('display','none');
                        
                    //    e.preventDefault();
                    return true;
            });
      
    });
    
    
    
//    function validateURL(textval) {
//  var urlregex = new RegExp(
//        "^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)");
//  return urlregex.test(textval);
//}


function socialUrl(input) {
    
    
        var url = $('#'+input.id).val();
        var url = $('#'+input.id).val();
    
   var re = /(http(s)?:\\)?([\w-]+\.)+[\w-]+[.com|.in|.org]+(\[\?%&=]*)?/
  
 if (re.test(url)) {
        if (url.indexOf("https://") != -1) {
            url = url.replace(/http:\/\/w/gi, "w");
            url = url.replace(/https:\/\/w/gi, "w");
            if(url != ''){
            $('#'+input.id).val(url);
            }
        }
        if (url.indexOf("https://") == -1) {
            if (url.indexOf("http://") != -1) {
                url = url.replace(/http:\/\/w/gi, "w");
            }
            if(url != ''){
             $('#'+input.id).val("https://" + url);
            }
        }
        
         }else{
       // alert('Please Enter Valid URL');
        $('#'+input.id+'_error').html('Enter valid URL').show();
    }
        
        
     }
//website

function webUrl(input) {
    
    var url = $('#'+input.id).val();
    
   var re = /(http(s)?:\\)?([\w-]+\.)+[\w-]+[.com|.in|.org]+(\[\?%&=]*)?/
  
 if (re.test(url)) {
        
        if (url.indexOf("http://") != -1) {
            url = url.replace(/http:\/\/w/gi, "w");
            url = url.replace(/https:\/\/w/gi, "w");
            if(url != ''){
            $('#'+input.id).val(url);
            }
        }
        if (url.indexOf("http://") == -1) {
            if (url.indexOf("https://") != -1) {
                url = url.replace(/https:\/\/w/gi, "w");
            }
            if(url != ''){
            $('#'+input.id).val("http://" + url);
            }
        }
        
    }else{
       // alert('Please Enter Valid URL');
        $('#'+input.id+'_error').html('Enter valid URL').show();
    }   
  
}





</script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
    });
</script>

@stop

