
<div id="sampleHideShow1" style="display:none" class="mobAlphaBg">
        <div class="leftBar1">
         <div class="brandName">
                   <a href="{!! url('/') !!}"><div class="logo"></div></a>
                Menu
            </div>
        <div class="closeIcon" onclick="hideAndShow('sampleHideShow1');"></div>
            <div class="clear"></div>
        	<ul>
                  
                @if($event_id == 0)    
                    
                <li class="events">
                    <a href="{!! url('create/event') !!}" class="<?php if($active == 6){ echo 'select'; } ?>">
                        <span class="icon"></span>{{trans('global.EventInfo') }}
                    </a>
                </li>
                
                @else
                <li class="events">
                    <a href="{!! url('edit/event/'.$event_id.'/0') !!}" class="<?php if($active == 6){ echo 'select'; } ?>">
                        <span class="icon"></span>{{trans('global.EventInfo') }}
                    </a>
                </li>
                
                @endif
                
                
               @if($event_id != 0)
             <li class="schedules">
                 <a href="{!! url('schedules/'.$event_id) !!}" class="<?php if($active == 7){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Schedules') }}
                 </a>
             </li>
             <li class="exhibits">
                 <a href="{!! url('exhibits/'.$event_id.'/0') !!}" class="<?php if($active == 8){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Exhibits') }}
                 </a>
             </li>
             @endif
             
            </ul>
        </div>
        <div class="closeDiv" onclick="hideAndShow('sampleHideShow1');"></div>
    	<div class="clear"></div>
        </div>
        
        <div class="leftBar">
        	<ul>
                    
                @if($event_id == 0)    
                    
            	 <li class="events">
                     <a href="{!! url('create/event') !!}" class="<?php if($active == 6){ echo 'select'; } ?>">
                         <span class="icon"></span>{{trans('global.EventInfo') }}
                     </a>
                 </li>
                 
                 @else
                 
                 <li class="events">
                     <a href="{!! url('edit/event/'.$event_id.'/0') !!}" class="<?php if($active == 6){ echo 'select'; } ?>">
                         <span class="icon"></span>{{trans('global.EventInfo') }}
                     </a>
                 </li>
                
                 @endif
                 
                 
             @if($event_id != 0) 
             <li class="schedules">
                 <a href="{!! url('schedules/'.$event_id) !!}" class="<?php if($active == 7){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Schedules') }}
                 </a>
             </li>
             <li class="exhibits">
                 <a href="{!! url('exhibits/'.$event_id.'/0') !!}" class="<?php if($active == 8){ echo 'select'; } ?>">
                     <span class="icon"></span>{{trans('global.Exhibits') }}
                 </a>
             </li>
             @endif
            </ul>
        </div>

