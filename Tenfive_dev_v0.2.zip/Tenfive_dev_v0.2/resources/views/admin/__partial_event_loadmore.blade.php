@foreach($events as $event) 
<div class="rowSec" id='event_{{ $event->id }}'>
    <a href="{!! url('edit/event/'.$event->id) !!}">
        <div class="detailsSec">

            <div class="name">{{ $event->name }} </div>
            @if($event->is_current_event == 1) 
            <div class="active">{{trans('global.CurrentEvent') }}</div>
            @endif

            <div class="details">
                <div>Address : {{ $event->street_address }}, {{ $event->city }}, {{ $event->state }}</div>
                <div> {{ date("d M Y",($offset)+($event->beginning_date/1000)) }} -  {{ date("d M Y",($offset)+($event->end_date/1000)) }}</div>
            </div>
        </div>
    </a>

    <div class="optionSec">


        <div tabindex="0" class="onclick-menu">
            <ul class="onclick-menu-content">
                
                
                
                
                @if($event->is_active == 1)
                 <li><a href="{!! url('edit/event/'.$event->id) !!}">{{trans('global.Edit') }}</a></li>
                 <li><a onclick="changeEventStatus({{ $event->id }},'0');">{{trans('global.Archive') }}</a></li>
                @endif
                
                 @if($event->is_active == 0) 
                <li><a href="{!! url('edit/event/'.$event->id) !!}">{{trans('global.Export') }}</a></li>
                @endif
                
                
                
                <li><a onclick="deleteEvent({{ $event->id }});">{{trans('global.Delete') }}</a></li>
                
                @if($event->is_current_event == 0 && $event->is_active == 1)
                <li><a onclick="makeAsCurrentEvent({{ $event->id }});">{{trans('global.MakeascurrentEvent') }}</a></li>
                @endif
                
                @if($event->is_active == 0) 
                <li><a onclick="changeEventStatus({{ $event->id }},'1');">{{trans('global.ReopenasActiveEvent') }}</a></li>
                @endif
                
                
                
                
            </ul>
        </div>


    </div>
    <div class="clear"></div>

</div>

@endforeach