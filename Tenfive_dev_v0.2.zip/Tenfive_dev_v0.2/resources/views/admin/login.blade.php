@include('admin.header')

<style>
html {
background: url("{{ URL::asset('images/login_bg1.jpg') }}") no-repeat center center fixed;
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
height:100%;
}






</style>
<body class="loginPageBg">
<div class="loginPage">
    <div class="loginOverlay">
	   <div class="loginBox">
    <div class="logo">
        <img src="{{ URL::asset('images/logo.jpg') }}" />
    </div>
    <div class="loginForm">
    
        
        <div class="form">
            
        <div class="loginErrorMsgSec ">
            <div style="color: red; font-size: 13px;" id="errorMessage" class="hideCredentialError">@if($errors->any()) {{ $errors->first('error') }} @endif </div>
        </div>
                 
            
            
            <!--{!! url('auth/login') !!}-->
        <form id="loginForm" action="{!! url('auth/login') !!}" method="post" > 
                 <input type="hidden" name="_token" value="{!! csrf_token() !!}">
        <div class="formRow">
            
            <input type="text" class="textBox" id="loginEmail" name="email" placeholder="Email" value="{{ $errors->first('email') }}" />
            
            <div id="loginEmailErrorMessage" class="errorMbox" ></div>
            
        </div>
        <div class="formRow">
            
            <input type="password" class="textBox" id="loginPassword"  name="password" value="{{ $errors->first('pass') }}" placeholder="Password" />
            
            <div id="loginPasswordErrorMessage" class="errorMbox"></div>
            
        </div>
        <div class="clear"></div>
        <div class="formRow">
            <!--<a href="{!! url('auth/login') !!}" class="btnBlue" style="display:block;">SIGN IN</a>-->
            <input type="submit" value="SIGN IN" id="loginButton" class="btnBlue" />
            
            <a  id="loginLoader"  href="{!! url('auth/login') !!}" class="btnBlue" style="display:none;">
<!--                <div   align="center">
                        <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />
                
                </div>-->
                <div class="loader">Loading...</div>
            </a>
        </div>
            
        
        <div class="formRow">
            <div class="cols2 forgotPass" align="left"><a onclick="hideAndShow('forgotPassword');">{{trans('global.ForgotPassword') }}</a></div>
            <div class="cols2 forgotPass" align="right"><a href="#">{{trans('global.NeedHelp') }}</a></div>
        </div>
        
        
        
        <div class="clear">&nbsp;</div>
        
            </form>
        
    </div>
        
        
        
    </div>
    </div>
    <div class="clear"></div>
    </div>
    </div>
    
    
    <!--Forgot Password Box Start-->
    <div id="forgotPassword" style="display:none" align="center">
        <div class="popUpSec">
         <div class="popUpBoxSmall">
             <div class=" headingMain popUpHead">{{trans('global.ResetPassword') }}</div>
                <div class="formSec">
                    <input type="hidden" name="_token" id="forgotPasswordToken" value="{!! csrf_token() !!}">
                        <div style="color: red; font-size: 13px;" id="errorMessageForgotPassword" class="errorMessageDiv"></div>
                
                        <form id="forgotPasswordForm" class="formReset">
                    <div class="rows">
                    {{trans('global.EnterYourEmailAddress') }}
                    <input type="text"  placeholder="{{trans('global.Email') }}" name="forgotEmail" id="forgotEmail" class="popupTbox" />
                    <div id="forgotEmailErrorMessage" class="errorMbox popupErrorMessageDiv" ></div>
                    </div>
                    <div class="clear"></div>
                    <div class="cols2">
                    <a onclick="hideAndShow('forgotPassword');" class="floatLeft btnLightGray linkBtn">{{trans('global.Cancel') }}</a>
                    </div>
                    <div class="cols2">
                    <!--<a href="#" class="floatRight bgBlue linkBtn">{{trans('global.Submit') }}</a>-->
                    
                    
                    
                    <input type="submit" value="{{trans('global.Submit') }}" id="forgotPasswordButton" class="floatRight bgBlue linkBtn" />

                    <a  id="forgotPasswordLoader"  href="{!! url('auth/login') !!}" class="btnBlue" style="display:none;">
                    <div   align="center">
<!--                        <img src="{{ URL::asset('images/loader_trans1.GIF') }}" />-->
                        <div class="loader">Loading...</div>
                    </div>
                    </a>
                    
                    
                    </div>
                    <div class="clear"></div>
                  
                </form>
                    

                 
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
<!--Forgot Password Box End-->
    
<script>
    
$(document).ready(function() {
    
    $('#loginEmail').keydown(function(){
        $('.hideCredentialError').hide();
        $("#loginEmailErrorMessage").text('Please enter your email address.').hide();
        $('#loginEmail').removeClass('errorTbox');
    });
    
    $('#loginPassword').keydown(function(){
        $('.hideCredentialError').hide();
        $("#loginPasswordErrorMessage").text('Please enter password.').hide();
        $('#loginPassword').removeClass('errorTbox');
    });
    
    $('#forgotEmail').keydown(function(){
        $("#forgotEmailErrorMessage").text('Please enter your email address.').hide();
        $('#forgotEmail').removeClass('errorTbox');
        $('#errorMessageForgotPassword').hide();
    });
    
    
    
    $('#loginEmail').focusout(function(){
            
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var emailaddress = $("#loginEmail").val();
//                if (emailaddress == '') {
//                    $("#loginEmailErrorMessage").text('Please enter your email address.').show();
//                    $('#loginEmail').addClass('errorTbox');
//                    var error = 1;
//                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#loginEmailErrorMessage").text('Please enter a valid email address.').show();
                    $('#loginEmail').addClass('errorTbox');
                    var error = 1;
                }
                
                
        });
        
        
        $('#forgotEmail').focusout(function(){
            
                var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                var emailaddress = $("#forgotEmail").val();
//                if (emailaddress == '') {
//                    $("#forgotEmailErrorMessage").text('Please enter your email address.').show();
//                    $('#forgotEmail').addClass('errorTbox');
//                    var error = 1;
//                } 
                if (!emailReg.test(emailaddress) && emailaddress != '') {
                    $("#forgotEmailErrorMessage").text('Please enter a valid email address.').show();
                    $('#forgotEmail').addClass('errorTbox');
                    var error = 1;
                }
                
                
        });
    
    
    
    
    
    
    
    
    
    
    //Login from validations
    $("#loginForm").submit(function(){
        var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        var emailaddressVal = $("#loginEmail").val();
        var passwordVal = $("#loginPassword").val();
        var error = 0;
        $('#loginButton').hide();
        $('#loginLoader').show();
        if(emailaddressVal == '') {
            $("#loginEmailErrorMessage").text('Please enter your email address.').show();
            $('#loginEmail').addClass('errorTbox');
            var error = 1;
        }
        if(!emailReg.test(emailaddressVal) && emailaddressVal != '' ) {
            $("#loginEmailErrorMessage").text('Please enter a valid email address.').show();
            $('#loginEmail').addClass('errorTbox');
            var error = 1;
        }
        if( passwordVal == '') {
            $("#loginPasswordErrorMessage").text('Please enter password.').show();
            $('#loginPassword').addClass('errorTbox');
            var error = 1;
        }
        if(passwordVal.length < 6 && passwordVal != '') {
            $("#loginPasswordErrorMessage").text('Password should be more than 8 characters').show();
            $('#loginPassword').addClass('errorTbox');
            var error = 1;
        }
        if(error == 1){
            $('#loginButton').show();
            $('#loginLoader').hide();
            return false;
        }else{
            return true;
        }
    });
});


// forget password
$(document).ready(function () {
     $('#forgotPasswordForm').submit(function (e) {
            e.preventDefault();
            var emailReg = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            var forgotEmail = $("#forgotEmail").val();
            var error = 0;
            $('#forgotPasswordButton').hide();
            $('#forgotPasswordLoader').show();
            if(forgotEmail == '') {
                $("#forgotEmailErrorMessage").text('Please enter your email address.').show();
                $('#forgotEmail').addClass('errorTbox');
                var error = 1;
             }
            if(!emailReg.test(forgotEmail) && forgotEmail != '') {
                $("#forgotEmailErrorMessage").text('Please enter a valid email address.').show();
                $('#forgotEmail').addClass('errorTbox');
                 var error = 1;
             }
            if(error == 1){  
                $('#forgotPasswordLoader').hide();
                $('#forgotPasswordButton').show(); 
                return false; 
            }
            
            var forgotPasswordToken = $('#forgotPasswordToken').val();
            var emailValidationData = "email=" + forgotEmail + "&token=" + forgotPasswordToken;
            
            $.ajax({
                url: "{!! url('password/email') !!}",
                type: "post",
                data: emailValidationData
            }).done(function(res){
               if(res == 1){
                   
                     $('#forgotPasswordLoader').hide();
                     $('#forgotPasswordButton').show(); 
                     $('#forgotPasswordForm')['0'].reset();
                     $('#forgotPassword').toggle();
                   
                  modal({
			type  : 'info',
			title : 'Info',
			text  : 'Please check the mail box.',
                        //autoclose : 'true',
                      }); 
                      
                      
               }else{
                   
                     $('#forgotPasswordLoader').hide();
                     $('#forgotPasswordButton').show(); 
                     $('#forgotPasswordForm')['0'].reset();
                     $("#errorMessageForgotPassword").text('The email you entered does not belong to any account.').show();
                   
               }
               
            })
            .fail(function(){
                      $('#forgotPasswordLoader').hide();
                      $('#forgotPasswordButton').show();
                      modal({
			type  : 'error',
			title : 'Error',
			text  : 'Please check the internet connection.',
                        autoclose : 'true',
                      });
               
            });
            
     });
});
</script>


<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        }
    });
</script>


    
</body>
</html>
