<div class="rowSec" id="userInformation_{{ $user->id }}">
    <div class="detailsSec">
        <div class="name" id="userName_{{ $user->id }}">{{ $user->full_name }}</div>
        <div class="details">
            <div id="userEmail_{{ $user->id }}">{{ $user->email }}</div>
        </div>
    </div>
    <div class="optionSec">
        <div tabindex="0" class="onclick-menu">
            <ul class="onclick-menu-content">
                <li><a onclick="editUser({{ $user->id }});">Edit user details</a></li>
                <li><a onclick="changePassword({{ $user->id }});">Change password</a></li>
                <li><a onclick="deleteUser({{ $user->id }})">Delete</a></li>
            </ul>
        </div>
    </div>
    <div class="clear"></div>
</div>

