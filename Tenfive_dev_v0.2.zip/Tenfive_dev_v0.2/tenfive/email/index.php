<?php
$headers = array();
$headers[] = "MIME-Version: 1.0";
$headers[] = "Content-type: text/html; charset=iso-8859-1";
$headers[] = "From: Brahma <brahma.uideveloper@gmail.com>";
$headers[] = "BCC:<brahma.uideveloper@gmail.com>,<brahma.sambhu@gmail.com>";
$headers[] = "Reply-To: Sam Brahma";
$subject="Reset Password Email";
$headers[] = 'Subject: {$subject}';
$headers[] = "X-Mailer: PHP/".phpversion();
$email='Sam Testing';
mail($to = 'brahma.uideveloper@gmail.com', $subject, $email, implode("\r\n", $headers));
?>