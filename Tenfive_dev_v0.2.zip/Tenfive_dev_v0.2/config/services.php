<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, Mandrill, and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => '',
        'secret' => '',
    ],

    'mandrill' => [
        'secret' => '5tdp1b1xZHNLjQc27dS8Kw',
    ],
    
   
/*
    'ses' => [
        'key'    => 'AKIAJQEAYFAZ4IUHBYXA',
        'secret' => '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',
        'region' => 'us-west-2',
    ],
*/	

	'ses' => [
        'key'    => 'AKIAJQEAYFAZ4IUHBYXA',
        'secret' => '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',
        'region' => 'us-east-1',
    ],

    'stripe' => [
        'model'  => App\User::class,
        'key'    => '',
        'secret' => '',
    ],

];
