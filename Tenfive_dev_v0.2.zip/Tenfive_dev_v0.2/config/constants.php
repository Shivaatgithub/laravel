<?php

return [
		
		
		'S3_url' => 'http://d237m7r0cj1qw8.cloudfront.net/',     

];
