<?php
namespace App\Classes;
 
class Common{
   
    public static function getOffsetValue(){
        $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=49.207.91.199"));
        $lat = $ip_data->geoplugin_latitude;
        $lng = $ip_data->geoplugin_longitude;
        //$url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=17.4359786,78.4481956&sensor=false';
        $url = 'https://maps.googleapis.com/maps/api/timezone/json?timestamp=0&sensor=true&location='.$lat.','.$lng.'';
        $data = file_get_contents($url);  
        $timedata = json_decode($data);
        return ($timedata->rawOffset);
    }
    
    
    public static function createThumbnail($s3file,$extension,$originalImage){
        

                 $width = imagesx($originalImage);
                 $height = imagesy($originalImage);
                if($width > $height){
                    $base = $height;
                }else{
                    $base = $width;
                }
                $new_height = 120;
                 $calculationFactor = ceil($base/$new_height);
                 $new_width = $width/$calculationFactor;
                 $new_height;
                

//                $maxwidth = 120;
//                $maxheight = 120;
//                if( $width < 640  && $height < 640)
//                {
//                $new_height = $height;
//                $new_width = $width;
//                }
//                else if ($height > $width) 
//                {   
//                $ratio = $maxheight / $height;  
//                $new_height = $maxheight;
//                $new_width = $width * $ratio; 
//                }
//                else if($height < $width)
//                {
//                $ratio = $maxwidth / $width;   
//                $new_width = $maxwidth;  
//                $new_height = $height * $ratio;   
//                }
//                else{
//                $new_width = $maxwidth;
//                $new_height = $maxheight;
//                }
//                
//                $new_width = 120;
//                $new_height = 120;
                
                $imageResized = imagecreatetruecolor($new_width, $new_height);
                imagecopyresampled($imageResized, $originalImage, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

                // Save the image in a temp file.
                $tempfilename = tempnam(__DIR__, "newImage");
                if(strtolower($extension) =="jpeg")
                {
                Imagejpeg($imageResized,$tempfilename,100);
                }
                elseif(strtolower($extension) =="jpg")
                {
                imagejpeg($imageResized,$tempfilename,100);
                }
                elseif(strtolower($extension) =="png"  )
                {
                imagejpeg($imageResized,$tempfilename,100);
                }

                return $tempfilename;
        
        
    }
    
    
    public static function imagecreatefromfile( $file_name,$file_extension ) {
    
            switch ( strtolower($file_extension)) {
                case 'jpeg':
               //return imageCreateFromJpeg($filename);
               return imagecreatefromstring(file_get_contents($file_name));
               break;
               case 'jpg':
               //return imageCreateFromJpeg($filename);
               return imagecreatefromstring(file_get_contents($file_name));
               break;
               case 'png':
               //return imageCreateFromPng($filename);
               return imagecreatefromstring(file_get_contents($file_name));
               break;
               case 'gif':
               //return imageCreateFromGif($filename);
               return imagecreatefromstring(file_get_contents($file_name));
               break;
               default:
               throw new InvalidArgumentException('File "'.$file_name.'" is not valid jpg, png or gif image.');
               break;
           }
    }
    
    
    
     function GUID()
    {
        if (function_exists('com_create_guid') === true)
        {
            return trim(com_create_guid(), '{}');
        }

        return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
    }
    
    
    function post_value_or($key, $default = Null) {
    return isset($_POST[$key]) && !empty($_POST[$key]) ? $_POST[$key] : $default;
    }
    
   
    
    
}