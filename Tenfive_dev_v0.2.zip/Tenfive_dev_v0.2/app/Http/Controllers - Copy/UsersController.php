<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Auth;
use Hash;
use DB;


class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    
    
    public function __construct()
    {
		//$this->middleware('auth');
    }
    
       
    public function index()
    {
        //parameters to sp limit_value int,offset_value int
        $users = DB::select('call getUsers(?,?)',array(10,0));
        $user_count = count($users);
        return view('admin.users',compact('users','user_count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        $email = $_POST['email'];
        $full_name = $_POST['full_name'];
        $password =  Hash::Make($_POST['password']);
        $modified_by = Auth::user()->id;
        $users = DB::select('call createUser(?,?,?,?)',array($full_name,$email,$password,$modified_by));
        $data['result'] = $users;
        $data['html'] = view('admin._partial_user',compact('users'))->__toString();
        return json_encode($data);
    }
    
    
    public function emailValidation(){
        // 1 -> email already exist, 0 -> not exist 
        $result = DB::select('call emailValidation(?,?)',array($_POST['email'],$_POST['user_id']));
       return json_encode($result['0']);
    } 
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update()
    {
        $email = $_POST['email'];
        $full_name = $_POST['full_name'];
        $user_id = $_POST['user_id'];
        $modified_by = Auth::user()->id;
        $users = DB::select('call editUser(?,?,?,?)',array($user_id,$full_name,$email,$modified_by));
        $data['result'] = $users;
        $data['html'] = view('admin._partial_user',compact('users'))->__toString();
        return json_encode($data);
        
    }
    
    
    public function updatePassword()
    {
        $password = Hash::Make($_POST['password']);
        $user_id = $_POST['user_id'];
        $modified_by = Auth::user()->id;
        $result = DB::select('call changePassword(?,?,?)',array($user_id,$password,$modified_by));
        return $result;
    }
    
    
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy()
    {
      $result = DB::select('call deleteUser(?)',array($_POST['user_id']));
        return $result;
    }
    
    
    public function loadMore()
    {
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
        $users = DB::select('call getUsers(?,?)',array($limit_value,$offset_value));
        $data['user_count'] = count($users);
        $data['html'] = view('admin._partial_user',compact('users'))->__toString();
        return json_encode($data);
    }
}
