<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Auth;
use Hash;
use DB;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    
    
    public function getLogin(Request $request){
          
        if(Auth::check()){
            return redirect('users');
        }
        else{
            return view('admin.login');
        }
            
    }
    
    
    public function postLogin(Request $request)
    {
        $email =  $_POST['email'];
        $pass = $_POST['password'];
        $dd = Auth::attempt(['email' => $email, 'password' => $pass]);
        
           		
        $data = $request->session()->all();
        if($dd){
           return redirect('users');
        }else{
            return view('admin.login');            
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function getLogout()
    {
         Auth::logout();
         return redirect('users');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
