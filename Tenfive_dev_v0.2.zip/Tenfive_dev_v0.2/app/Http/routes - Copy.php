<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
   return redirect('users');
});


Route::get('login', 'LoginController@index');
Route::get('home', 'EventsController@index');
//Route::get('users', 'UsersController@index');


Route::get('users', [
	'uses' => 'UsersController@index',
	'as' => 'users',
	'middleware' => 'auth'
]);


Route::get('createevent', 'EventsController@index');
Route::get('articles', 'ArticlesController@index');
Route::post('createArticle', 'ArticlesController@create');
Route::get('services', 'ServicesController@index');
Route::post('getAllUsers', 'ServicesController@users');
Route::get('auth/login', 'LoginController@getLogin');
Route::post('auth/login', 'LoginController@postLogin');
Route::get('auth/logout', 'LoginController@getLogout');
Route::post('user/store', 'UsersController@store');
Route::post('user/loadmore', 'UsersController@loadMore');
Route::post('user/emailValidation', 'UsersController@emailValidation');
Route::post('user/update', 'UsersController@update');
Route::post('user/updatepass', 'UsersController@updatePassword');
Route::post('user/destroy', 'UsersController@destroy');
Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
