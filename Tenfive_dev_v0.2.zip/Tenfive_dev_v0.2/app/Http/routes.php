<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
   return redirect('events');
});


Route::get('login', 'LoginController@index');
Route::get('home', 'EventsController@index');
//Route::get('users', 'UsersController@index');


Route::get('users', [
	'uses' => 'UsersController@index',
	'as' => 'users',
	'middleware' => 'auth'
]);

Route::get('events', [
	'uses' => 'EventsController@index',
	'as' => 'events',
	'middleware' => 'auth'
]);

Route::get('advertisements', [
	'uses' => 'advController@index',
	'as' => 'advertisements',
	'middleware' => 'auth'
]);

Route::get('articles', 'ArticlesController@index');
Route::post('createArticle', 'ArticlesController@create');
Route::get('services', 'ServicesController@index');
Route::post('getAllUsers', 'ServicesController@users');
Route::get('auth/login', 'LoginController@getLogin');
Route::post('auth/login', 'LoginController@postLogin');
Route::get('auth/logout', 'LoginController@getLogout');
Route::post('auth/secure', 'LoginController@postSecure');
Route::post('user/store', 'UsersController@store');


Route::get('sendnotification', 'notificationController@index');
Route::get('notificationsuccess', 'notificationController@create');


Route::post('user/loadmore', 'UsersController@loadMore');
Route::post('user/emailValidation', 'UsersController@emailValidation');
Route::post('user/update', 'UsersController@update');
Route::post('user/updatepass', 'UsersController@updatePassword');
Route::post('user/destroy', 'UsersController@destroy');
Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);

//email
Route::get('mail', 'LoginController@sendEmailReminder');

// Password reset link sending
Route::get('password/email', 'Auth\PasswordController@getEmail');
Route::post('password/email', 'Auth\PasswordController@postEmail');

// Password reset
Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
Route::post('password/reset', 'Auth\PasswordController@postReset');

//s3 bucket upload 
Route::post('user/s3upload', 'UsersController@uploadFileToS3');

//events
Route::get('create/event', 'EventsController@create');
Route::get('edit/event/{eventid}/{edit_flag}', 'EventsController@edit');
Route::post('update/event/{eventid}', 'EventsController@update');
Route::post('status/event', 'EventsController@status');
Route::post('delete/event', 'EventsController@delete');
Route::post('current/event', 'EventsController@current');
Route::post('active_events/loadmore', 'EventsController@loadMoreActiveEvents');
Route::post('archive_events/loadmore', 'EventsController@loadMoreArchiveEvents');
Route::post('store/event', 'EventsController@store');
Route::get('event/dumpdatabase', 'EventsController@dumpDatabase');

//services
Route::post('getEventActivities', 'ServicesController@getEventActivities');
Route::post('getBeaconInfo', 'ServicesController@getBeaconInfo');
Route::post('getCurrentEventInfo', 'ServicesController@getCurrentEventInfo');
Route::post('getEventExhibits', 'ServicesController@getEventExhibits');
Route::post('getParkingUpdates', 'ServicesController@getParkingUpdates');
Route::post('getActivityInfo', 'ServicesController@getActivityInfo');
Route::post('registerUserDevice', 'ServicesController@registerUserDevice');

//parking
Route::get('parking', 'ParkingController@index');
Route::post('parking/store', 'ParkingController@store');
Route::post('parking/destroy', 'ParkingController@destroy');
Route::post('parking/loadmore', 'ParkingController@loadMore');
Route::post('parking/update', 'ParkingController@update');

//exhibits
Route::get('exhibits', 'ExhibitsController@index');
Route::post('exhibits/store', 'ExhibitsController@store');
Route::post('exhibits/destroy', 'ExhibitsController@destroy');
Route::post('exhibits/loadmore/{eventid}', 'ExhibitsController@loadMore');
Route::post('exhibits/update', 'ExhibitsController@update');
Route::get('exhibits/{eventid}/{sorttype}', 'ExhibitsController@index');
Route::post('exhibits/edit', 'ExhibitsController@edit');
Route::post('exhibits/filter/{eventid}', 'ExhibitsController@filter');

//schedules
Route::get('schedules/{event_id}', 'ScheduleController@index');
Route::post('schedule/moredates', 'ScheduleController@addMoreDates');
Route::post('schedule/moredatesedit', 'ScheduleController@addMoreDatesEdit');
Route::post('schedule/store', 'ScheduleController@store');
Route::post('schedule/edit', 'ScheduleController@edit');
Route::post('schedule/update', 'ScheduleController@update');
Route::post('schedule/destroy', 'ScheduleController@destroy');
Route::post('schedule/loadmore', 'ScheduleController@loadMore');
























//services
Route::post('getAllUsers', 'ServicesController@users');
Route::post('getEventActivities', 'ServicesController@getEventActivities');
Route::post('getBeaconInfo', 'ServicesController@getBeaconInfo');
Route::post('getCurrentEventInfo', 'ServicesController@getCurrentEventInfo');
Route::post('getEventExhibits', 'ServicesController@getEventExhibits');
Route::post('getParkingUpdates', 'ServicesController@getParkingUpdates');
Route::post('getActivityInfo', 'ServicesController@getActivityInfo');
Route::post('registerUserDevice', 'ServicesController@registerUserDevice');




