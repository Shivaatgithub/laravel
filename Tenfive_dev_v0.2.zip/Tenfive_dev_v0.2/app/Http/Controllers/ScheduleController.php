<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Classes\Common;
use Auth;
use Hash;
use DB;
//use Ifsnop\Mysqldump as IMysqldump;

class ScheduleController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
        $this->MyClassInstance = new Common;
        $this->offset = $this->MyClassInstance->getOffsetValue();
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index($event_id)
    {
        
        $schedules = DB::select("call getActivities('$event_id',5,0)");
       // dd($schedules);
        $offset =  $this->offset;
        $title = 'Schedules';
        $active =  '7';
        $schdulesCount = count($schedules);
        $data = DB::select('call getEventInfo(?)', array($event_id));
        $event = $data['0'];
        //dd($event);
        return view('admin.schedules',compact('active','title','event_id','schedules','offset','schdulesCount','event'));
    }
    
    
      public function loadMore(){
        
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
        $event_id = $_POST['event_id'];
        $offset =  $this->offset;
        $schedules = DB::select('call getActivities(?,?,?)',array($event_id,$limit_value,$offset_value));
        $data['schedule_count'] = count($schedules);
        $data['html'] = view('admin.__partial_schedule_loadmore',compact('schedules','offset'))->__toString();
        return json_encode($data);
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
       // return view('admin.add-event');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        //dd($_POST);
         $is_multi_day_activity = isset($_POST['isMultiDayActive']) && !empty($_POST['isMultiDayActive']) ? $_POST['isMultiDayActive'] : 0;
        $dateTimes = $this->MyClassInstance->post_value_or('activityDateTime');
        $dateTimeString = '';
        $count = count($dateTimes);
        $i = 1;
        //dd($dateTimes);
        
        
        foreach($dateTimes as $each){
           
            if($count > $i) {
            $seperator = '$';
            }else{$seperator = '';}
            
              if($is_multi_day_activity == 0){
               $seperator = '';
            }
            
           $startDate = (strtotime(str_replace("-", "/", $each['startDate'])) - $this->offset) * 1000;
           $startTime = (strtotime(str_replace("-", "/", $each['startDate'] . '' . $each['startTime'])) - $this->offset) * 1000;
           $endTime = (strtotime(str_replace("-", "/", $each['startDate'] . '' . $each['endTime'])) - $this->offset) * 1000;
            $dateTimeString .= '{"date": "'.$startDate.'", "starttime": "'.$startTime.'","endtime": "'.$endTime.'"}'.$seperator.'';
            $i++;
            
           if($is_multi_day_activity == 0){
               break;
            }
            
        }
        
        $event_id = $this->MyClassInstance->post_value_or('event_id');
        $activity_name = addslashes($this->MyClassInstance->post_value_or('activityName'));
        $location = addslashes($this->MyClassInstance->post_value_or('activityAddress'));
        $latitude = $this->MyClassInstance->post_value_or('activityLatitude');
        $longitude = $this->MyClassInstance->post_value_or('activityLongitude');
        $description = addslashes($this->MyClassInstance->post_value_or('activityDescription'));
        $aircraft_type = addslashes($this->MyClassInstance->post_value_or('airCraftType'));
       
        $is_live_stream = isset($_POST['isAvailableForLiveStream']) && !empty($_POST['isAvailableForLiveStream']) ? $_POST['isAvailableForLiveStream'] : 0;
        $website_url = addslashes($this->MyClassInstance->post_value_or('WebUrl'));
        $facebook_url = addslashes($this->MyClassInstance->post_value_or('FbUrl'));
        $twitter_url = addslashes($this->MyClassInstance->post_value_or('TwitterUrl'));
        $modified_by = Auth::user()->id;
        $performer_name = addslashes($this->MyClassInstance->post_value_or('performerName'));
        $performer_photo = $this->MyClassInstance->post_value_or('performerPhoto');
        $performer_photo_thumb = $this->MyClassInstance->post_value_or('performerPhotoThumb');
        $multi_activity_times = $dateTimeString;
        
               
        $data = DB::select("call createActivity('$event_id','$activity_name','$location','$latitude','$longitude','$description',
                '$aircraft_type',$is_live_stream,$is_multi_day_activity,'$website_url','$facebook_url','$twitter_url',$modified_by,
                '$multi_activity_times','$performer_name','$performer_photo','$performer_photo_thumb')");
        
        $data['result'] = count($data);
        $schedule = $data['0'];
        $offset =  $this->offset;
       // dd($schedule);
        $data['html'] = view('admin.__partial_schedule',compact('schedule','offset'))->__toString();
        return json_encode($data);
        
        //dd($storeActivity);
     
        //echo $dateTimeString;
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit()
    {
               
     $isExecute = false;
     $syntax = 'call getActivityInfo(?)';
     $pdo = DB::connection()->getPdo();
     $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
     $stmt = $pdo->prepare($syntax,[\PDO::ATTR_CURSOR=>\PDO::CURSOR_SCROLL]);
     $stmt->bindValue(1, $_POST['schedule_id'], \PDO::PARAM_INT);
     $exec = $stmt->execute();
     if (!$exec) return $pdo->errorInfo();
     if ($isExecute) return $exec;
     $results = [];
     do {
         try {
             $results[] = $stmt->fetchAll(\PDO::FETCH_OBJ);
         } catch (\Exception $ex) { }
     } while ($stmt->nextRowset());
     if (1 === count($results)) return $results[0];
    
        $schedule = $results['0']['0'];
        //dd($schedule);
        $schedule_timings = $results['1'];
        $performer = $results['2']['0'];
        $offset =  $this->offset;
        
        $data1 = DB::select('call getEventInfo(?)', array($_POST['event_id']));
        $event = $data1['0'];
        
        $data['result'] = count($results);
        $data['html'] = view('admin.__partial_schedule_edit',compact('schedule','offset','schedule_timings','performer','event'))->__toString();
        return json_encode($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update()
    {
        
      $is_multi_day_activity = isset($_POST['editIsMultiDayActive']) && !empty($_POST['editIsMultiDayActive']) ? $_POST['editIsMultiDayActive'] : 0;
      ///  exit;
        
         $dateTimes = $this->MyClassInstance->post_value_or('activityDateTime');
        $dateTimeString = '';
        $count = count($dateTimes);
        $i = 1;
        foreach($dateTimes as $each){
            
            if($count > $i) {
                $seperator = '$';
            }else{
                $seperator = '';
            
            }
            if($is_multi_day_activity == 0){
                $seperator = '';
            }
            
            
            
            $id = $each['id'];
            $startDate = (strtotime(str_replace("-", "/", $each['startDate'])) - $this->offset) * 1000;
            $startTime = (strtotime(str_replace("-", "/", $each['startDate'] . '' . $each['startTime'])) - $this->offset) * 1000;
            $endTime = (strtotime(str_replace("-", "/", $each['startDate'] . '' . $each['endTime'])) - $this->offset) * 1000;
            $dateTimeString .= '{"id": "'.$id.'","date": "'.$startDate.'", "starttime": "'.$startTime.'","endtime": "'.$endTime.'"}'.$seperator.'';
            $i++;
            
            if($is_multi_day_activity == 0){
               break;
            }
            
        }
        
        $activity_id = $this->MyClassInstance->post_value_or('activity_id');
        $event_id = $this->MyClassInstance->post_value_or('event_id');
        $activity_name = addslashes($this->MyClassInstance->post_value_or('activityName'));
        $location = addslashes($this->MyClassInstance->post_value_or('activityAddress'));
        $latitude = $this->MyClassInstance->post_value_or('activityLatitude');
        $longitude = $this->MyClassInstance->post_value_or('activityLongitude');
        $description = addslashes($this->MyClassInstance->post_value_or('activityDescription'));
        $aircraft_type = addslashes($this->MyClassInstance->post_value_or('airCraftType'));
        $is_multi_day_activity = isset($_POST['editIsMultiDayActive']) && !empty($_POST['editIsMultiDayActive']) ? $_POST['editIsMultiDayActive'] : 0;
        $is_live_stream = isset($_POST['editIsAvailableForLiveStream']) && !empty($_POST['editIsAvailableForLiveStream']) ? $_POST['editIsAvailableForLiveStream'] : 0;
        $website_url = addslashes($this->MyClassInstance->post_value_or('WebUrl'));
        $facebook_url = addslashes($this->MyClassInstance->post_value_or('FbUrl'));
        $twitter_url = addslashes($this->MyClassInstance->post_value_or('TwitterUrl'));
        $modified_by = Auth::user()->id;
        $performer_name = addslashes($this->MyClassInstance->post_value_or('performerName'));
        $performer_photo = $this->MyClassInstance->post_value_or('performerPhoto');
        $performer_photo_thumb = $this->MyClassInstance->post_value_or('performerPhotoThumb');
        $multi_activity_times = $dateTimeString;
        
        
//        echo "call editActivity($activity_id,$event_id,'$activity_name','$location','$latitude','$longitude','$description',
//                '$aircraft_type',$is_live_stream,$is_multi_day_activity,'$website_url','$facebook_url','$twitter_url',$modified_by,
//                '$multi_activity_times','$performer_name','$performer_photo','$performer_photo_thumb')";
//        
//        dd($_POST);
//        exit;

        $data = DB::select("call editActivity($activity_id,$event_id,'$activity_name','$location','$latitude','$longitude','$description',
                '$aircraft_type',$is_live_stream,$is_multi_day_activity,'$website_url','$facebook_url','$twitter_url',$modified_by,
                '$multi_activity_times','$performer_name','$performer_photo','$performer_photo_thumb')");
        
        $data['result'] = count($data);
        $schedule = $data['0'];
        $offset =  $this->offset;
        $data['html'] = view('admin.__partial_schedule',compact('schedule','offset'))->__toString();
        return json_encode($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy()
    {
         $result = DB::select('call deleteActivity(?)',array($_POST['schedule_id']));
        return $result;
    }
    
    public function addMoreDates(){
        //echo "ddd";
        $indexvalue = $_POST['indexvalue'];
        $data['html'] = view('admin.__partial_more_dates',compact('indexvalue'))->__toString();
        return json_encode($data);
        
    }
    
    public function addMoreDatesEdit(){
        //echo "ddd";
        $indexvalue = $_POST['indexvalue'];
        $data['html'] = view('admin.__partial_more_dates_edit',compact('indexvalue'))->__toString();
        return json_encode($data);
        
    }
    
  
}
