<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\Http\Requests;
use App\Http\Controllers\Controller;

use Auth;
use Hash;
use DB;
use PushNotification;
use AWS;
use App;
use App\Classes\Common;

class ParkingController extends Controller
{
    
    public function __construct()
    {
		$this->middleware('auth');
                   $this->MyClassInstance = new Common;
                $this->offset = $this->MyClassInstance->getOffsetValue();
                
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {  
 
  
 //return ($timedata->rawOffset*1000);
 
        $title = 'Parking';
        $active =  '2';
          $offset = $this->offset; 
        //SP params:event_id,limit_value,offset_value
        $parkings = DB::select('call getParkings(?,?,?)',array(1,10,0)); 
        $parking_count = count($parkings);
        return view('admin.parking',compact('parkings','parking_count','active','title','offset'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
       // return view('admin.add-event');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {   
      //$deviceToken="e641bf8c9e5d3e12b6873407326c5f530c1829dc29379e83f2e25af6bc528eca";
        $parking_text =  addslashes($_POST['parking_text']);
        $created_by = Auth::user()->id;
         $offset = $this->offset; 
         
        //$parkings = DB::select('call createParking(?,?)',array($parking_text,$created_by));

        $parkings = DB::select("call createParking('$parking_text',$created_by)");
         
         
        $data['result'] = $parkings;
        $data['html'] = view('admin._partial_parking',compact('parkings','offset'))->__toString();

        
        return json_encode($data);
    }
  public function loadMore()
    {   
        $offset = $this->offset; 
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
        $parkings = DB::select('call getParkings(?,?,?)',array(1,$limit_value,$offset_value));
        $data['parking_count'] = count($parkings);
        $data['html'] = view('admin._partial_parking',compact('parkings','offset'))->__toString();
        return json_encode($data);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
   
    public function update()
    {
 $offset = $this->offset; 
 $parking_text=addslashes($_POST['parking_Tex']);
 $parking_id = $_POST['parking_id'];
 $modified_by = Auth::user()->id;
// $parkings = DB::select('call editParking(?,?,?)',array($parking_id,$parking_text,$modified_by));
  $parkings = DB::select("call editParking($parking_id,'$parking_text','$modified_by')");

 $data['result'] = $parkings;
 $data['html'] = view('admin._partial_parking',compact('parkings','offset'))->__toString();
 return json_encode($data);
        
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
 
     public function destroy()
    {
      $result = DB::select('call deleteParking(?)',array($_POST['parking_id']));
      return $result;
    }
}
