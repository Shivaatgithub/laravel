<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use Auth;
use Hash;
use DB;
use Mail;
use Cookie;
use Illuminate\Cookie\CookieJar;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    
    
    public function getLogin(Request $request){
          
        if(Auth::check()){
           // return redirect('users');
            return redirect('events');
        }
        else{
            $title = 'Login';
            return view('admin.login',compact('title'));
        }
            
    }
    
    
    public function postLogin(CookieJar $cookieJar, Request $request)
    {
        $email =  $_POST['email'];
        $pass = $_POST['password'];
        $dd = Auth::attempt(['email' => $email, 'password' => $pass]);
        
           		
        $data = $request->session()->all();
        if($dd){
          //setcookie("noTenFiveCache", 0,time()+3600);
          // Cookie::make('noTenFiveCache', '1',60);
             //$cookieJar->queue(cookie('noTenFiveCache', 1, 45000));
           // Cookie::queue(Cookie::make('noTenFiveCache', 0, 45000));
          // return redirect('users');
            return redirect('events');
        }else{
            $title = 'Login';
            return view('admin.login',compact('title'))->withErrors(['error' => 'Invalid credentials.','email' => $email, 'pass'=> $pass]);           
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function getLogout()
    {
        Auth::logout();
        //setcookie("noTenFiveCache", 1,time()+3600);
       // Cookie::queue(Cookie::make('noTenFiveCache', 1, 45000));
        //Cookie::make('noTenFiveCache', '1',60);
        return redirect('auth/login');
         
         //return redirect('auth/logoutf');
         //return redirect(\URL::previous());
    }
    
    public function logoutForm(){
         Auth::logout();
         return redirect('auth/login');
    } 

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
    

     public function sendEmailReminder(Request $request)
    {
        $user = User::find(1);
        Mail::send('admin.login', ['user' => $user,'title' => 'Mail'], function ($m) use ($user) {
            $m->to('shivakakileti89@gmail.com', 'shiva')->subject('Your Reminder!');
        });
    }
    
    
    public function postSecure()
    {
        if (\Auth::check())
            return 1;
        else
            return 0;
    }
}

