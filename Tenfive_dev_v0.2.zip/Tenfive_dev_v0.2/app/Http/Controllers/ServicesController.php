<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

//Api guard extension
use Chrisbjr\ApiGuard\Http\Controllers\ApiGuardController;

use Auth;
use Hash;
use DB; 
class ServicesController extends ApiGuardController
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
   /* public function ServicesController()
    {
    * 'getActivityInfo' => [
            'keyAuthentication' => false
        ],
        'getBeaconInfo' => [
            'keyAuthentication' => false
        ],
    $S3_Url = Config::get('constants.S3_url');
    }*/
    protected $apiMethods = [
        'users' => [
            'keyAuthentication' => true
        ],
       
        'index' => [
            'keyAuthentication' => true
        ],
       
        
        
    ];
    
    
    
    
     public function index()
    {
        return view('apiguard_check');
    }
    
    
    
    public function users()
    {
       print_r($_POST);
        //return 'hai users controller';
    }
    
     public function getEventActivities()
    {
      
       //print_r($_POST);
       //exit;
         
          $data = DB::select('call getActivities(?,?,?)',array($_POST['event_id'],$_POST['limit_value'],$_POST['offset_value']));
      
           if (count($data) > 0) {
           $arrays = json_decode(json_encode($data), true);
            foreach ($arrays as $item) {


                $items = array(
                    'activity_id' => $item['id'],
                    'activity_name' => $item['activity_name'],
                    'performer_name' => $item['performer_name'],
                    'activity_date' => $item['activity_date'],
                    'start_time' => $item['start_time'],
                    'end_time' => $item['end_time'],
                    'performer_id' => $item['performer_id'],
                    'performer_photo' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$item['performer_photo'],
                    'photo_thumb' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$item['photo_thumb'],
                    'is_live_stream' => $item['is_live_stream']);
                   
                $file_data_array[] = $items;
            }

            echo json_encode( array('status_id' => 1, 'message' => 'success', 'event_id' => $arrays[0]['event_id'], 'activites' => $file_data_array));
        } else {
            echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no activities'));
        }
          
          
          
          
      
    }
    
    
     public function getEventExhibits()
    {
      
       //print_r($_POST);
       //exit;
         
          $data = DB::select('call getExhibits(?,?,?,?)',array($_POST['event_id'],$_POST['limit_value'],$_POST['offset_value'],$_POST['sort_type']));
      
           if (count($data) > 0) {
           $arrays = json_decode(json_encode($data), true);
            
        
            foreach ($arrays as $array) {
                $items[] = array(
                    'exhibit_id' => $array['id'],
                    'exhibit_name' => $array['name'],
                    'photo' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['photo'],
                    'exhibit_description' => $array['description'],
                     'sponsor'=>array('sponsor_id' =>$array['sponsor_id'],
                    'ad_location_id' =>$array['ad_location_id'],
                    'ad_info_url' =>$array['ad_info_url'],
                    'file_path' =>'http://dev-tenfivepro.s3.amazonaws.com/'.$array['file_path'],
                    'file_type' =>$array['file_type'],
                    'sponsor_name' => '' ),
                    
                    'is_sponsored' => $array['is_sponsored'],
                    'created_on' => $array['created_on'],
                    'last_modifed_on' => $array['last_modifed_on'],
                    'created_by' => $array['created_by'],
                    'last_modified_by' => $array['last_modified_by'],
                    'photo_thumb' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['photo_thumb']
                    
                    
                    
                    );
       
            }  
        
              
            

            echo json_encode( array('status_id' => 1, 'message' => 'success','event_id' => $arrays[0]['event_id'],'exhibit_map' =>'http://dev-tenfivepro.s3.amazonaws.com/'.$arrays[0]['exhibit_map'],'exhibits'=>  $items));
        } else {
            echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no exhibits'));
        }       
          
          
          
      
    }
    
     public function getParkingUpdates()
    {
      
       //print_r($_POST);
       //exit;
         
          $data = DB::select('call getParkings(?,?,?)',array($_POST['event_id'],$_POST['limit_value'],$_POST['offset_value']));
      
           if (count($data) > 0) {
           $arrays = json_decode(json_encode($data), true);
            foreach ($arrays as $item) {


                $items = array(
                    'message' => $item['message'],
                    'created_on' => $item['created_on']
                    );
                   
                $file_data_array[] = $items;
            }

            echo json_encode( array('status_id' => 1, 'message' => 'success', 'parking_map' => $arrays[0]['parking_map'], 'parking_updates' => $file_data_array));
        } else {
            echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no parking updates'));
        }
          
          
          
          
      
    }
    
    public function getActivityInfo()
    {
      
       //print_r($_POST);
       //exit;
        
        
        
        $isExecute = false;
     $syntax = 'call getActivityInfo(?)';
     $pdo = DB::connection()->getPdo();
     $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
     $stmt = $pdo->prepare($syntax,[\PDO::ATTR_CURSOR=>\PDO::CURSOR_SCROLL]);
     $stmt->bindValue(1, $_POST['activity_id'], \PDO::PARAM_INT);
     
    //  $stmt->bindValue(1, 1, \PDO::PARAM_INT);
     $exec = $stmt->execute();
     if (!$exec) return $pdo->errorInfo();
     if ($isExecute) return $exec;
     $results = [];
     do {
         try {
             $results[] = $stmt->fetchAll(\PDO::FETCH_OBJ);
         } catch (\Exception $ex) { }
     } while ($stmt->nextRowset());
     if (1 === count($results)) return $results[0];
    
     $activity = $results['0']['0'];
   $activity_timinigs = $results['1'];
   $performer = $results['2']['0'];
   if(count($activity) >0)
   {
   $performer_array = array(
   'performer_id' => $performer->performer_id,
   'performer_name' => $performer->performer_name,
   'performer_photo_thumb' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$performer->performer_photo_thumb,
   'performer_photo' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$performer->performer_photo
   );
   
   foreach ($activity_timinigs as $time){
     $activity_timings_array[] = array('date'=>$time->date,'start_time' => $time->start_time,'end_time' => $time->end_time);
   }
      
 echo json_encode( array(
   'status' => 'success',
   'status_id' => '1',
   'event_id' => $activity->event_id,
   'activity_id' => $activity->id,
   'activity_name' => $activity->name,
   'location' => $activity->location,
   'is_live_stream' => $activity->is_live_stream,
   'activity_timings' => $activity_timings_array,
   'activity_description' => $activity->description,
   'performer' => $performer_array,
   'is_sponsored' => 0,
     'sponsor' =>'',
//   'sponsor' => array('sponsor_id' =>$activity->sponsor_id,
//                    'ad_location_id' =>$activity->ad_location_id,
//                    'ad_info_url' =>$activity->ad_info_url,
//                    'file_path' =>'http://dev-tenfivepro.s3.amazonaws.com/'.$activity->file_path,
//                    'file_type' =>$activity->file_type,
//                    'sponsor_name' => '' ),
   'aircraft_type' => $activity->aircraft_type,
   'website_url' => $activity->website_url,
   'facebook_url' => $activity->facebook_url,
   'twitter_url' => $activity->twitter_url
   ));
   
   }
    else {
          echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no activities'));
       }
   
  
         
         
     
//     if (count($results[0]) > 0) {
//           $arrays = json_decode(json_encode($results[0]), true);
//           
//           
//                $items = array(
//                    'event_id' => $item['message'],
//                    'activity_id' => $item['created_on'],
//                        
//                        'activity_name' => $item['created_on'],
//                         'location' => $item['created_on'],
//                         'is_multi_day_activity' => $item['created_on'],
//                         'is_live_stream' => $item['created_on'],
//                         'activity_description' => $item['created_on'],
//                         'is_sponsored' => $item['created_on'],
//                         'aircraft_type' => $item['created_on'],
//                         'website_url' => $item['created_on'],
//                         'facebook_url' => $item['created_on'],
//                         'twitter_url' => $item['created_on'],
//                      
//                    );
//            $arrays['0']['status_id'] =1; 
//            $arrays['0']['message'] = 'success';
//           
//        
//         exit();
//          $data = DB::select('call getActivityInfo(?)',array($_POST['activity_id']));
//      
//           if (count($data) > 0) {
//           $arrays = json_decode(json_encode($data), true);
//            foreach ($arrays as $item) {
//
//
//                $items = array(
//                    'message' => $item['message'],
//                    'created_on' => $item['created_on']
//                    );
//                   
//                $file_data_array[] = $items;
//            }
//
//            echo json_encode( array('status_id' => 1, 'message' => 'success', 'parking_map' => $arrays[0]['parking_map'], 'parking_updates' => $file_data_array));
//        } else {
//            echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no parking updates'));
//        }
//          
//          
//          
//          
//      
//    }
    }
    
    
    
    
     public function registerUserDevice(Request $Request)
     {
        $dd = $Request->input('plat_form');
         echo $dd;
         exit;
         $data = DB::select('call registerUserDevice(?,?,?)',array($_POST['device_token'],$_POST['plat_form'],$_POST['unique_id']));
          if (count($data) > 0) {
              $arrays = json_decode(json_encode($data), true);
               
               echo json_encode( array('status_id' => 1, 'message' => 'success'));
          }
 else {
     echo json_encode(array('status_id' => 0, 'message' => 'Sorry. Your device token not inserted successfully.'));
     
 }
     }
    
    
    
    
    
    
    
      public function getCurrentEventInfo()
    {
      
       //print_r($_POST);
       //exit;
          
         
          $data = DB::select('call getCurrentEventInfo()');
      
           if (count($data) > 0) {
           $arrays = json_decode(json_encode($data), true);
            
       
            foreach ($arrays as $array) {
                $items = array(
                    'event_id' => $array['id'],
                    'event_name' => $array['name'],
                    'beginning_date' => $array['beginning_date'],
                    'end_date' => $array['end_date'],
                     'location'=>array('zip' => $array['zip'],
                    'street_address' => $array['street_address'],
                    'city' => $array['city'],
            'latitude' => $array['latitude'],
            'longitude' => $array['longitude'],
                    'state' => $array['state']),
                    'start_time' => $array['start_time'],
                    'end_time' => $array['end_time'],
                    'is_current_event' => $array['is_current_event'],
                    'is_active' => $array['is_active'],
                    'parking_map' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['parking_map'],
                    'exhibit_map' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['exhibit_map'],
                    'event_logo' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['event_logo'],
                    'emergency_number' => $array['emergency_number'],
                    'lost_child_number' => $array['lost_child_number'],
                    'website_url' => $array['website_url'],
                    'facebook_url' => $array['facebook_url'],
                    'twitter_url' => $array['twitter_url'],
                    'guest_services_text' => $array['guest_services_text'],
                    'text_direction' => $array['text_direction'],
                    'created_on' => $array['created_on'],
                    'last_modifed_on' => $array['last_modifed_on'],
                     'created_by' => $array['created_by'],
                    'last_modified_by' => $array['last_modified_by'],
                        'ad_info_url' => $array['ad_info_url'],
                        'ad_location_id' => $array['ad_location_id'],
                         'file_type' => $array['file_type'],//file_type=1 video,file_type=2 image
                        'file_path' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$array['file_path']
                    
                    
                    );
       
            }  
        
              
            

            echo json_encode( array('status_id' => 1, 'message' => 'success',   'result' => $items));
        } else {
            echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no curent event'));
        }       
          
          
          
      
    }
    
     public function getBeaconInfo()
    {
     
        $data = DB::select('call getBeaconInfo(?,?,?)',array($_POST['uuid'],$_POST['max_value'],$_POST['min_value']));
         //$data = DB::select('call getBeaconInfo(12345,1,2)');
         if (count($data) > 0) {
        $arrays = json_decode(json_encode($data), true);
        
        foreach ($arrays as $item) {

           
                $items = array(
                    
                   
                    'exhibit_id' => $item['exhibit_id'],
        
        'photo' => 'http://dev-tenfivepro.s3.amazonaws.com/'.$item['photo'],
        'photo_thumb' =>'http://dev-tenfivepro.s3.amazonaws.com/'.$item['photo_thumb'],
        'exhibit_name' =>$item['name'],
        'exhibit_description'=>$item['description'],
        'is_sponsored' =>$item['is_sponsored'],
                    'sponsor'=>array('sponsor_id' =>$item['sponsor_id'],
                    'ad_location_id' =>$item['ad_location_id'],
                    'ad_info_url' =>$item['ad_info_url'],
                    'file_path' =>'http://dev-tenfivepro.s3.amazonaws.com/'.$item['file_path'],
                    'file_type' =>$item['file_type'],
                    'sponsor_name' => '' ),
         
                    );
                   
               // $file_data_array[] = $items;
            }
            
            echo json_encode( array('status_id' => 1, 'message' => 'success',   'result' => $items));
         }
        else{
             echo json_encode(array('status_id' => 0, 'message' => 'Sorry. there is no curent event'));
         }
          
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
