<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Classes\Common;
use Auth;
use Hash;
use DB;
use Ifsnop\Mysqldump as IMysqldump;



class EventsController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function __construct() {
        $this->middleware('auth');
        //$MyClass = new Common;
        //$this->offset = $MyClass->getOffsetValue();
        $this->MyClassInstance = new Common;
        $this->offset = $this->MyClassInstance->getOffsetValue();
    }

    public function index() {
        $title = 'Events';
        $active = '1';
        $offset = $this->offset;
        //limit_value  --> 10,offset_value --> 0
        $syntax = 'call getActiveEvents(?,?)';
        $pdo = DB::connection()->getPdo();
        $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
        $stmt = $pdo->prepare($syntax, [\PDO::ATTR_CURSOR => \PDO::CURSOR_SCROLL]);
        $stmt->bindValue(1, 5, \PDO::PARAM_INT);
        $stmt->bindValue(2, 0, \PDO::PARAM_INT);
        $exec = $stmt->execute();
        if (!$exec)
            return $pdo->errorInfo();
        $results = [];
        do {
            try {
                $results[] = $stmt->fetchAll(\PDO::FETCH_OBJ);
            } catch (\Exception $ex) {
                
            }
        } while ($stmt->nextRowset());
        if (1 === count($results))
            return $results[0];
        $currentEvent = $results['0'];
        $activeEvents = $results['1'];
        $archiveEvents = DB::select('call getArchiveEvents(?,?)', array(5, 0));
        $currentEventCount = count($currentEvent);
        $activeEventsCount = count($activeEvents);
        $archiveEventsCount = count($archiveEvents);
        return view('admin.events', compact('activeEvents', 'archiveEvents', 'activeEventsCount', 'archiveEventsCount', 'active', 'title', 'offset', 'currentEvent','currentEventCount'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        $edit_flag = 1;
        $event_id = 0;
        $action = 'store/event';
        $title = 'Add Event';
        $active = '6';
        return view('admin.create-event', compact('active', 'title', 'action','event_id','edit_flag'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store() {
        
        //dd($_POST);
        
        $url = "http://maps.googleapis.com/maps/api/geocode/json?address=".urlencode($_POST['eventAddress'].' '.$_POST['eventCity'].' '.$_POST['eventState'].' '.$_POST['eventZipCode']);
        $data = file_get_contents($url);
        $latlng = json_decode($data, true);

        $event_name = addslashes($_POST['eventName']);
        $street_address = addslashes($_POST['eventAddress']);
        $city = $_POST['eventCity'];
        $state = $_POST['eventState'];
        $zip = $_POST['eventZipCode'];
        $latitude = isset($latlng['results']['0']['geometry']['location']['lat']) ? $latlng['results']['0']['geometry']['location']['lat'] : 0 ; //$_POST['eventLatitude'];
        $longitude = isset($latlng['results']['0']['geometry']['location']['lng']) ? $latlng['results']['0']['geometry']['location']['lng'] : 0 ; //$_POST['eventLongitude'];
        
        
//        $beginning_date = (strtotime($_POST['eventStartDate']) - $this->offset) * 1000;
//        $end_date = (strtotime($_POST['eventEndDate']) - $this->offset) * 1000;
//        $start_time = (strtotime($_POST['eventStartDate'] . '' . $_POST['eventTime']) - $this->offset) * 1000;
//        $end_time = (strtotime($_POST['eventStartDate'] . '' . $_POST['eventTime']) - $this->offset) * 1000;
        
        
        $beginning_date = (strtotime(str_replace("-", "/", $_POST['eventStartDate'])) - $this->offset) * 1000;
        $end_date = (strtotime(str_replace("-", "/", $_POST['eventEndDate'])) - $this->offset) * 1000;
        $start_time = (strtotime(str_replace("-", "/", $_POST['eventStartDate'] . '' . $_POST['eventTime'])) - $this->offset) * 1000;
        $end_time = (strtotime(str_replace("-", "/", $_POST['eventStartDate'] . '' . $_POST['eventTime'])) - $this->offset) * 1000;
        
        
        
        
        $is_current_event = 0;
        $is_active = 1;
        $text_direction = addslashes($_POST['eventTextDirections']);
        $parking_map = $_POST['parkingFile'];
        $exhibit_map = $_POST['exhibitFile'];
        $event_logo = $_POST['logoFile'];
        $emergency_number = $_POST['eventEmergencyNo'];
        $lost_child_number = $_POST['eventLostChildNo'];
        $website_url = addslashes($_POST['eventWebUrl']);
        $facebook_url = addslashes($_POST['eventFacebookUrl']);
        $twitter_url = addslashes($_POST['eventTwitterUrl']);
        $guest_services_text = addslashes($_POST['eventGuestServiceInfo']);
        $modified_by = Auth::user()->id;
        
        $parking_map_thumb = $_POST['parkingThumbnail'];
        $exhibit_map_thumb = $_POST['exhibitThumbnail'];
        $event_logo_thumb = $_POST['logoThumbnail'];

//        $storeEvent = DB::select("call createEvent(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
//        array(
//                $event_name ,
//                $street_address,
//                $city,
//                $state,
//                $zip,
//                $latitude,
//                $longitude,
//                $beginning_date,
//                $end_date ,
//                $start_time,
//                $end_time,
//                $is_current_event,
//                $is_active ,
//                $text_direction ,
//                $parking_map,
//                $exhibit_map,
//                $event_logo,
//                $emergency_number ,
//                $lost_child_number,
//                $website_url,
//                $facebook_url,
//                $twitter_url,
//                $guest_services_text,
//                $modified_by
//        ));
//
//echo "call createEvent('$event_name','$street_address','$city','$state','$zip','$latitude','$longitude','$beginning_date','$end_date',
//                '$start_time','$end_time',$is_current_event,$is_active,'$text_direction','$parking_map','$exhibit_map','$event_logo','$emergency_number',
//                '$lost_child_number','$website_url','$facebook_url','$twitter_url','$guest_services_text','$modified_by','$parking_map_thumb','$exhibit_map_thumb','$event_logo_thumb'
//                )";
//exit;
        
        $storeEvent = DB::select("call createEvent('$event_name','$street_address','$city','$state','$zip','$latitude','$longitude','$beginning_date','$end_date',
                '$start_time','$end_time',$is_current_event,$is_active,'$text_direction','$parking_map','$exhibit_map','$event_logo','$emergency_number',
                '$lost_child_number','$website_url','$facebook_url','$twitter_url','$guest_services_text','$modified_by','$parking_map_thumb','$exhibit_map_thumb','$event_logo_thumb'
                )");

        return redirect('events');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($event_id,$edit_flag) {
        $action = 'update/event/' . $event_id;
        $title = 'Edit event';
        $active = '6';
        $data = DB::select('call getEventInfo(?)', array($event_id));
        //dd($data);
        
//        $data['0']->parking_map_fullpath = 'http://dev-tenfivepro.s3.amazonaws.com/' . $data['0']->parking_map_thumb;
//        $data['0']->exhibit_map_fullpath = 'http://dev-tenfivepro.s3.amazonaws.com/' . $data['0']->exhibit_map_thumb;
//        $data['0']->event_logo_fullpath = 'http://dev-tenfivepro.s3.amazonaws.com/' . $data['0']->event_logo_thumb;
        
        $data['0']->parking_map_fullpath = $data['0']->parking_map_thumb;
        $data['0']->exhibit_map_fullpath = $data['0']->exhibit_map_thumb;
        $data['0']->event_logo_fullpath = $data['0']->event_logo_thumb;
        
        $data['0']->beginning_date = date("m-d-Y", ($this->offset) + ($data['0']->beginning_date / 1000));
        $data['0']->end_date = date("m-d-Y", ($this->offset) + ($data['0']->end_date / 1000));
        $data['0']->start_time = date("H:i", ($this->offset) + ($data['0']->start_time / 1000));
        $event = $data['0'];
        return view('admin.create-event', compact('active', 'title', 'event_id', 'action','event','edit_flag'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id) {
        //dd($_POST);
        $url = "http://maps.googleapis.com/maps/api/geocode/json?address=".urlencode($_POST['eventAddress'].' '.$_POST['eventCity'].' '.$_POST['eventState'].' '.$_POST['eventZipCode']);
        $data = file_get_contents($url);
        $latlng = json_decode($data, true);
        
        
        
        $event_id = $id;
        $event_name = addslashes($_POST['eventName']);
        $street_address = addslashes($_POST['eventAddress']);
        $city = addslashes($_POST['eventCity']);
        $state = addslashes($_POST['eventState']);
        $zip = $_POST['eventZipCode'];
        $latitude = isset($latlng['results']['0']['geometry']['location']['lat']) ? $latlng['results']['0']['geometry']['location']['lat'] : 0 ; //$_POST['eventLatitude'];
        $longitude = isset($latlng['results']['0']['geometry']['location']['lng']) ? $latlng['results']['0']['geometry']['location']['lng'] : 0 ; //$_POST['eventLongitude'];
        
        $var = isset($var) ? $var : "default";
        
//        $beginning_date = (strtotime($_POST['eventStartDate']) - $this->offset) * 1000;
//        $end_date = (strtotime($_POST['eventEndDate']) - $this->offset) * 1000;
//        $start_time = (strtotime($_POST['eventStartDate'] . '' . $_POST['eventTime']) - $this->offset) * 1000;
//        $end_time = (strtotime($_POST['eventStartDate'] . '' . $_POST['eventTime']) - $this->offset) * 1000;
        
        $beginning_date = (strtotime(str_replace("-", "/", $_POST['eventStartDate'])) - $this->offset) * 1000;
        $end_date = (strtotime(str_replace("-", "/", $_POST['eventEndDate'])) - $this->offset) * 1000;
        $start_time = (strtotime(str_replace("-", "/", $_POST['eventStartDate'] . '' . $_POST['eventTime'])) - $this->offset) * 1000;
        $end_time = (strtotime(str_replace("-", "/", $_POST['eventStartDate'] . '' . $_POST['eventTime'])) - $this->offset) * 1000;
        
        $is_current_event = $_POST['is_current_event'];
        $is_active = $_POST['is_active'];
        $text_direction = addslashes($_POST['eventTextDirections']);
        $parking_map = $_POST['parkingFile'];
        $exhibit_map = $_POST['exhibitFile'];
        $event_logo = $_POST['logoFile'];
        $emergency_number = $_POST['eventEmergencyNo'];
        $lost_child_number = $_POST['eventLostChildNo'];
        $website_url = addslashes($_POST['eventWebUrl']);
        $facebook_url = addslashes($_POST['eventFacebookUrl']);
        $twitter_url = addslashes($_POST['eventTwitterUrl']);
        $guest_services_text = addslashes($_POST['eventGuestServiceInfo']);
        $modified_by = Auth::user()->id;
        
        $parking_map_thumb = $_POST['parkingThumbnail'];
        $exhibit_map_thumb = $_POST['exhibitThumbnail'];
        $event_logo_thumb = $_POST['logoThumbnail'];

//        $storeEvent = DB::select("call editEvent(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
//                    $event_id,
//                    $event_name,
//                    $street_address,
//                    $city,
//                    $state,
//                    $zip,
//                    $latitude,
//                    $longitude,
//                    $beginning_date,
//                    $end_date,
//                    $start_time,
//                    $end_time,
//                    $is_current_event,
//                    $is_active,
//                    $text_direction,
//                    $parking_map,
//                    $exhibit_map,
//                    $event_logo,
//                    $emergency_number,
//                    $lost_child_number,
//                    $website_url,
//                    $facebook_url,
//                    $twitter_url,
//                    $guest_services_text,
//                    $modified_by
//        ));
        
        
       
        
        $updateEvent = DB::select("call editEvent('$event_id','$event_name','$street_address','$city','$state','$zip','$latitude','$longitude','$beginning_date','$end_date',
                '$start_time','$end_time',$is_current_event,$is_active,'$text_direction','$parking_map','$exhibit_map','$event_logo','$emergency_number',
                '$lost_child_number','$website_url','$facebook_url','$twitter_url','$guest_services_text','$modified_by','$parking_map_thumb','$exhibit_map_thumb','$event_logo_thumb'
                
                )");

        
        
        return redirect('events');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

    public function delete() {
        $event_id = $_POST['event_id'];
        $result = DB::select('call deleteEvent(' . $event_id . ')');
        return 1;
    }

    public function status() {
        $event_id = $_POST['event_id'];
        $is_status = $_POST['is_status'];
        $offset = $this->offset;
        $result = DB::select('call updateEventStatus(' . $event_id . ',' . $is_status . ')');
        $event = $result['0'];
        $data['event_count'] = count($result);
        $data['html'] = view('admin.__partial_event', compact('event', 'offset'))->__toString();
        return json_encode($data);
    }

    public function current() {
        $event_id = $_POST['event_id'];
        $is_status = $_POST['is_status'];
        $offset = $this->offset;
        $result = DB::select('call updateEventCurrentStatus(' . $event_id . ',' . $is_status . ')');
        return 1;
    }
    
    public function loadMoreActiveEvents(){
        
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
        $offset = $this->offset;
        $events = DB::select("call getActiveEvents($limit_value,$offset_value)");
        $data['events_count'] = count($events);
        $data['html'] = view('admin.__partial_event_loadmore',compact('events','offset'))->__toString();
        return json_encode($data);
        
    }
    
    public function loadMoreArchiveEvents(){
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
        $offset = $this->offset;
        $events = DB::select('call getArchiveEvents(?,?)',array($limit_value,$offset_value));
        $data['events_count'] = count($events);
        $data['html'] = view('admin.__partial_event_loadmore',compact('events','offset'))->__toString();
        return json_encode($data);
    }
    
    
    public function dumpDatabase(){
        
    $dumpSettings = array(
    'compress' => 'none',
    'no-data' => false,
    'add-drop-table' => true,
    'single-transaction' => true,
    'lock-tables' => true,
    'add-locks' => true,
    'extended-insert' => false,
    'disable-keys' => true,
    'skip-triggers' => false,
    'add-drop-trigger' => true,
    'databases' => false,
    'add-drop-database' => false,
    'hex-blob' => true,
    'no-create-info' => true,
    'where' => '',
    'include-tables' => array('events','exhibits')
    );

    $dumpSettings['default-character-set'] = IMysqldump\Mysqldump::UTF8MB4;
    $dump = new IMysqldump\Mysqldump(
    "tenfivedevdb",
    "tenfivedb",
    '$t#en5$D$ev#$db',
    "tenfivedevdb.c6een2cqotsa.us-west-2.rds.amazonaws.com",
    "mysql",
    $dumpSettings);
    $filename = rand(1,11111111).".sql";
           
    $dump->start($filename);
    header('Content-Type: application/octet-stream');   
    header("Content-Transfer-Encoding: Binary"); 
    header("Content-disposition: attachment; filename=\"".$filename."\"");
        
    }
    

}
