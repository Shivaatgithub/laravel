<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Hash;
use DB;
use App\Classes\Common;
class ExhibitsController extends Controller
{
     public function __construct()
    {
		$this->middleware('auth');
               
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index($event_id,$sorttype=0)
    {
        $title = 'Exhibits';
        $active =  '8';
       $event_Id = $event_id;
       $sort_type=$sorttype;
       $exhibits = DB::select('call getExhibits(?,?,?,?)',array($event_id,10,0,$sort_type));
//dd($exhibits);
//exit;
        $exhibits_count = count($exhibits);
        
      
        return view('admin.exhibits',compact('exhibits','exhibits_count','active','title','event_id'));
 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
       // return view('admin.add-event');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {  
        $event_Id = $_POST['event_id'];
        $exhibit_name =addslashes($_POST['exhibit_name']);
        $exhibit_photo	= addslashes($_POST['exhibit_photo']);
        $exhibit_thumb	= addslashes($_POST['exhibit_thumb']);
        $description	= addslashes($_POST['description']);
        $is_sponsored	= $_POST['is_sponsored'];
        $created_by = Auth::user()->id;
        $ibeacon_uuid	= addslashes($_POST['ibeacon_uuid']);
        $ibeacon_major_value = $_POST['ibeacon_major_value'];
        $ibeacon_minor_value = $_POST['ibeacon_minor_value'];
        $ibeacon_alert_text = addslashes($_POST['ibeacon_alert_text']);
        //$modified_by = Auth::user()->id;
        
        $exhibits = DB::select("call createExhibit(
         $event_Id,'$exhibit_name',
             '$exhibit_photo','$exhibit_thumb',
             '$description',$is_sponsored,
             '$created_by','$ibeacon_uuid','$ibeacon_major_value',
             '$ibeacon_minor_value','$ibeacon_alert_text')");
        
        
//                $exhibits = DB::select("call createExhibit(?,?,?,?,?,?,?,?,?,?,?)",
//        array(
//                $event_Id ,
//                $exhibit_name,
//                $exhibit_photo,
//                $exhibit_thumb,
//                $description,
//                $is_sponsored,
//                $created_by,
//                $ibeacon_uuid,
//                $ibeacon_major_value ,
//                $ibeacon_minor_value,
//                $ibeacon_alert_text,
//              
//        ));

        
       
        $data['result'] = $exhibits;
        $data['html'] = view('admin._partial_exhibit',compact('exhibits'))->__toString();
        return json_encode($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
   

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update()
    {
        $event_Id = $_POST['event_id'];
        $exhibit_id = $_POST['exhibit_id'];
        $exhibit_name = addslashes($_POST['exhibit_name']);
        $exhibit_photo	= addslashes($_POST['exhibit_photo']);
        $exhibit_thumb	= addslashes($_POST['exhibit_thumb']);
        $description	= addslashes($_POST['description']);
        $is_sponsored	= $_POST['is_sponsored'];
        $modified_by = Auth::user()->id;      
        $ibeacon_uuid	= addslashes($_POST['ibeacon_uuid']);
        $ibeacon_major_value = $_POST['ibeacon_major_value'];
        $ibeacon_minor_value = $_POST['ibeacon_minor_value'];
        $ibeacon_alert_text = addslashes($_POST['ibeacon_alert_text']);   

         $exhibits = DB::select("call editExhibit(
        $event_Id,$exhibit_id,'$exhibit_name',
             '$exhibit_photo','$exhibit_thumb',
             '$description',$is_sponsored,
             '$modified_by','$ibeacon_uuid','$ibeacon_major_value',
             '$ibeacon_minor_value','$ibeacon_alert_text')");
         
//          $exhibits = DB::select("call editExhibit(?,?,?,?,?,?,?,?,?,?,?,?)",
//        array(
//                $event_Id ,
//                $exhibit_id,
//                $exhibit_name,
//                $exhibit_photo,
//                $exhibit_thumb,
//                $description,
//                $is_sponsored,
//                $modified_by,
//                $ibeacon_uuid,
//                $ibeacon_major_value ,
//                $ibeacon_minor_value,
//                $ibeacon_alert_text,
//              
//        ));
      
        $data['result'] = $exhibits;
        $data['html'] = view('admin._partial_exhibit',compact('exhibits'))->__toString();
        return json_encode($data);       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy()
    {
      $result = DB::select('call deleteExhibit(?)',array($_POST['exhibit_id']));     
      return $result;
    }
      public function loadMore($event_id)
     {  
        $event_Id = $event_id;
        $sort_type = $_POST['selected_value'];     
        $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];    
        $exhibits= DB::select('call getExhibits(?,?,?,?)',array($event_Id,$limit_value,$offset_value,$sort_type));
        $data['exhibits_count'] = count($exhibits); 
        $data['html'] = view('admin._partial_exhibit',compact('exhibits'))->__toString();       
        return json_encode($data);
    }
     public function edit()
    {
      $exhibits = DB::select('call getExhibitInfo(?)',array($_POST['exhibit_id']));  
      $data['exhibits_count'] = count($exhibits); 
      return json_encode($exhibits['0']);
    }
    
    
      public function filter($event_id)
     {
        $title = 'Exhibits';
        $active =  '8';
         $limit_value = $_POST['limit_value'];
        $offset_value = $_POST['offset_value'];
       $event_Id = $event_id;
       
       $sort_type = $_POST['selected_value'];    
       
       $exhibits = DB::select('call getExhibits(?,?,?,?)',array($event_id,$limit_value,$offset_value,$sort_type));
       
        $exhibits_count = count($exhibits);
        $data['exhibits_count'] = count($exhibits); 
        $data['html'] = view('admin._partial_exhibit',compact('exhibits'))->__toString();       
        return json_encode($data);
 
    }
    
}
